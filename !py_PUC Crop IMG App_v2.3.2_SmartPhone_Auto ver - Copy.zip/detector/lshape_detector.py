import cv2
import numpy as np
import os
import re
import math
import pandas as pd
from openpyxl import Workbook
from openpyxl.drawing.image import Image as ExcelImage
from openpyxl.utils import get_column_letter
from openpyxl.styles import PatternFill, Font, Border, Side, Alignment
import sys
from PIL import Image 
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QWidget, QPushButton, QLabel,
    QTextEdit, QFileDialog, QProgressBar, QMessageBox, QHBoxLayout,
    QGraphicsDropShadowEffect
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QSize
from PyQt6.QtGui import QFont, QPalette, QColor, QIcon
import rc.icons 
from PyQt6 import QtCore, QtGui, QtWidgets 
import shutil
from openpyxl import load_workbook as _load_wb
try:
    import pythoncom
    import win32com.client as win32
except Exception:
    win32 = None
    pythoncom = None

# Global cache for settings.csv
_SETTINGS_DF = None


def get_script_dir():
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    else:
        return os.path.dirname(os.path.realpath(__file__))

script_dir = get_script_dir()

def _load_settings_df():
    """Load settings.csv once and cache it."""
    global _SETTINGS_DF
    if _SETTINGS_DF is not None:
        return _SETTINGS_DF
    try:
        csv_path = os.path.join(script_dir, "settings.csv")
        if os.path.exists(csv_path):
            import pandas as pd
            _SETTINGS_DF = pd.read_csv(csv_path)
        else:
            _SETTINGS_DF = None
    except Exception:
        _SETTINGS_DF = None
    return _SETTINGS_DF


def _get_lshape_ptn_list_for_resolution(img_width, img_height):
    """
    Get the list of laboratories from the LShape_PTN_Check column (format: step01_0300NIT_R216;step01_0300NIT_G216;...).
    """
    df = _load_settings_df()
    if df is None or "LShape_PTN_Check" not in df.columns:
        return []

    candidates = df
    resolution_key = f"{img_width};{img_height}"
    if "Display_Resolution" in candidates.columns:
        res_series = candidates["Display_Resolution"].astype(str)
        mask_res = res_series == resolution_key
        if mask_res.any():
            candidates = candidates[mask_res]
        else:
            return []

    out = []
    for val in candidates["LShape_PTN_Check"].dropna().astype(str):
        for p in val.split(";"):
            p = p.strip()
            if p and p not in out:
                out.append(p)
    return out


def _extract_lshape_pattern_and_group_key(file_name, img_width, img_height):
    """
    Check if the filename contains any of the terms "PTN" in LShape_PTN_Check.
    Returns (matched_pattern, group_key) or (None, None).
    """
    if not file_name:
        return None, None
    ptn_list = _get_lshape_ptn_list_for_resolution(img_width, img_height)
    if not ptn_list:
        return None, None
    fname = str(file_name)
    for ptn in ptn_list:
        if ptn and ptn in fname:
            return ptn, ptn
    return None, None


def _get_lshape_params(img_width, img_height, file_name):
    """
    Read LShape_* parameters from settings.csv for given resolution and pattern.
    Returns dict with optional keys: sigma, r, threshold_scale.
    """
    df = _load_settings_df()
    if df is None:
        return {}

    candidates = df

    # Filter theo Display_Resolution + LShape_PTN_Check
    resolution_key = f"{img_width};{img_height}"
    if "Display_Resolution" in candidates.columns:
        res_series = candidates["Display_Resolution"].astype(str)
        mask_res = res_series == resolution_key
        if mask_res.any():
            candidates = candidates[mask_res]
        else:
            return {}

    pattern = extract_pattern(file_name, img_width, img_height) if file_name else None
    if pattern and "LShape_PTN_Check" in candidates.columns:
        ptn_series = candidates["LShape_PTN_Check"].astype(str)
        mask_ptn = ptn_series.str.contains(pattern, na=False)
        if mask_ptn.any():
            candidates = candidates[mask_ptn]

    if candidates.empty:
        return {}

    row = candidates.iloc[0]

    def _get_float(col):
        if col not in row or pd.isna(row[col]) or row[col] == "":
            return None
        try:
            return float(row[col])
        except Exception:
            return None

    params = {}
    sigma = _get_float("LShape_Gaussion_Sigma")
    var_r = _get_float("LShape_Varience_R")
    thr = _get_float("LShape_Threshold")

    if sigma is not None:
        params["sigma"] = sigma
    if var_r is not None:
        params["r"] = int(round(var_r))
    if thr is not None:
        params["threshold_scale"] = thr

    return params


def local_variance_filter(image, r):
    """
    Calculates local variance with a kernel size of 2*r+1
    """
    kernel_size = 2 * r + 1
    img_float = image.astype(np.float32)

    # Calculate mean
    mean = cv2.blur(img_float, (kernel_size, kernel_size))

    # Calculate mean of squares
    mean_sq = cv2.blur(img_float**2, (kernel_size, kernel_size))

    # Variance = E[X^2] - (E[X])^2
    variance = mean_sq - mean**2
    return variance

def detect_lshape_defects(image_path, r, threshold_scale, sigma_override=None):
    # Read image 16-bit by OpenCV
    img = cv2.imread(image_path, cv2.IMREAD_UNCHANGED | cv2.IMREAD_ANYDEPTH)
    
    if img is None:
        raise ValueError(f"Cannot read image: {image_path}")
    
    # If the image has many channels, convert it to grayscale
    if len(img.shape) == 3:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # Apply Gaussian blur with a sigma to remove noise (must come from settings.csv)
    if sigma_override is None:
        raise ValueError("LShape detection requires LShape_Gaussion_Sigma from settings.csv")
    sigma = sigma_override
    kernel_size = int(2 * np.ceil(2 * sigma) + 1)
    img = cv2.GaussianBlur(img, (kernel_size, kernel_size), sigma)
    
    # Apply variance filter
    var_img = local_variance_filter(img, r=r)

    # Normalize to 0-255 for visualization
    var_norm = cv2.normalize(var_img, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)

    # Automatic threshold based on mean
    thresh_val = np.mean(var_img) * threshold_scale

    # Binary mask
    _, mask = cv2.threshold(var_img, thresh_val, 65535, cv2.THRESH_BINARY)

    # Morphology to remove noise
    mask = cv2.morphologyEx(mask.astype(np.uint8), cv2.MORPH_OPEN, np.ones((5,5), np.uint8))

    # Find contours
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Filter out contours near image borders
    # Update: distance from left and right edges is 200 pixels; distance from top and bottom edges is 50 pixels
    filtered_contours = []
    img_height, img_width = img.shape[:2]
    
    # Set thresholds for the edges
    left_border_threshold = 260
    right_border_threshold = 260
    top_border_threshold = 40
    bottom_border_threshold = 40

    for cnt in contours:
        x, y, w, h = cv2.boundingRect(cnt)
        
        # Check if the bounding box is outside the designated boundary area
        if (x > left_border_threshold and 
            y > top_border_threshold and 
            (x + w) < (img_width - right_border_threshold) and 
            (y + h) < (img_height - bottom_border_threshold)):
            filtered_contours.append(cnt)

    contours = filtered_contours

    # Create a new mask containing only the filtered contours
    filtered_mask = np.zeros_like(mask)
    cv2.drawContours(filtered_mask, filtered_contours, -1, 65535, -1) # Draw filled white contours onto the new mask

    # Draw results
    result = cv2.normalize(img, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    result = cv2.cvtColor(result, cv2.COLOR_GRAY2BGR)

    for cnt in contours:
        x, y, w, h = cv2.boundingRect(cnt)
        cv2.rectangle(result, (x, y), (x + w, y + h), (0, 0, 255), 2)

    return result, filtered_mask, var_img

def extract_pattern(file_name, img_width=None, img_height=None):
    """Returns the LShape pattern (e.g., step01_0300NIT_B192) if the filename contains it; otherwise, None."""
    if img_width is None or img_height is None:
        return None
    ptn, _ = _extract_lshape_pattern_and_group_key(file_name, img_width, img_height)
    return ptn

def are_centers_close(bbox1, bbox2, tolerance=100):
    x1, y1, w1, h1 = bbox1
    x2, y2, w2, h2 = bbox2

    center_x1 = x1 + w1 / 2
    center_y1 = y1 + h1 / 2
    center_x2 = x2 + w2 / 2
    center_y2 = y2 + h2 / 2

    # Calculate Euclidean distance between centers
    distance = np.sqrt((center_x1 - center_x2)**2 + (center_y1 - center_y2)**2)

    # Check for bounding box overlap
    # Calculate coordinates of the corners
    left1, top1, right1, bottom1 = x1, y1, x1 + w1, y1 + h1
    left2, top2, right2, bottom2 = x2, y2, x2 + w2, y2 + h2

    # Check for overlap
    overlap_x = max(0, min(right1, right2) - max(left1, left2))
    overlap_y = max(0, min(bottom1, bottom2) - max(top1, top2))
    has_overlap = (overlap_x > 0 and overlap_y > 0)

    # Return True if centers are close ENOUGH OR there is significant overlap
    return distance <= tolerance or has_overlap

def check_for_common_lshape_defects(lshape_checker_thread, folder_path, file_names_in_group, pattern, 
                             mask_images_dir, mark_lshapes_dir, crop_lshapes_dir, 
                             r=None, threshold_scale=None):
    all_lshape_data = []  # Temporary list to store information about common lshape defect instances
    base_folder_name = os.path.basename(folder_path)  # Get base folder name
    profile_data_list = []  # Store profile data for CSV export - for ALL files
    
    for file_name in file_names_in_group:
        file_path = os.path.join(folder_path, file_name)

        img = cv2.imread(file_path, cv2.IMREAD_UNCHANGED | cv2.IMREAD_ANYDEPTH)
        if img is None:
            lshape_checker_thread.update_log.emit(f"Warning: Cannot read image {file_name}")
            continue

        if len(img.shape) == 3:
            img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        img_height, img_width = img.shape[:2]
        # Read parameters from settings.csv
        params = _get_lshape_params(img_width, img_height, file_name)
        required_keys = ("r", "threshold_scale", "sigma")
        if not all(k in params for k in required_keys):
            lshape_checker_thread.update_log.emit(
                f"Skip {file_name}: missing LShape_* settings in settings.csv (matching LShape_PTN_Check and pattern)."
            )
            continue
        cur_r = params["r"]
        cur_threshold_scale = params["threshold_scale"]
        sigma_override = params["sigma"]

        result, mask, var_img = detect_lshape_defects(
            file_path,
            r=cur_r,
            threshold_scale=cur_threshold_scale,
            sigma_override=sigma_override,
        )

        mask_img_path = os.path.join(mask_images_dir, f"{base_folder_name}_{file_name.replace('.tif', '_mask.png')}")
        cv2.imwrite(mask_img_path, mask)

        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        bboxes = [cv2.boundingRect(cnt) for cnt in contours]
        
        num_defects = len(bboxes)
        max_variance = np.max(var_img) if var_img.size > 0 else 0
        mean_variance = np.mean(var_img) if var_img.size > 0 else 0
        threshold_used = np.mean(var_img) * cur_threshold_scale if var_img.size > 0 else 0
        
        # Format defect positions (bounding boxes) for CSV
        defect_positions = ""
        if bboxes:
            # Format as: (x,y,w,h); (x,y,w,h); ...
            bbox_strings = []
            for bbox in bboxes:
                x, y, w, h = bbox
                bbox_strings.append(f"({x},{y},{w},{h})")
            defect_positions = "; ".join(bbox_strings)
        
        # Determine initial status_check
        status_check = "LShape Defect Found" if num_defects > 0 else "OK"
        # Initial status: always OK first, will be updated later if part of common defect
        status = "OK"
        
        # Save profile information for CSV for ALL files
        profile_data_list.append({
            "Folder": base_folder_name,
            "File Name": file_name,
            "Pattern": pattern if pattern else "Unknown",
            "Status_Check": status_check,  # LShape Defect Found or OK
            "Status": status,  # OK or NG (common defect indicator)
            "R Parameter": cur_r,
            "Threshold Scale": cur_threshold_scale,
            "Threshold Used": threshold_used,
            "Number of Defects": num_defects,
            "Max Variance": max_variance,
            "Mean Variance": mean_variance,
            "Defect Positions": defect_positions
        })
        
        original_img = cv2.imread(file_path, cv2.IMREAD_UNCHANGED | cv2.IMREAD_ANYDEPTH)
        if original_img is not None:
            original_img_norm = cv2.normalize(original_img, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
            if len(original_img_norm.shape) == 3:
                original_img_norm = cv2.cvtColor(original_img_norm, cv2.COLOR_BGR2GRAY)
        else:
            original_img_norm = np.zeros((100, 100), dtype=np.uint8)

        all_lshape_data.append({
            "file_name": file_name,
            "original_img": original_img_norm,
            "result_img": result,
            "mask_img": mask,
            "bboxes": bboxes,
            "var_img": var_img,
            "profile_index": len(profile_data_list) - 1  # Store index to update later
        })

    if len(all_lshape_data) < 3:
        # If not enough images to compare, no common defects, but return all profiles
        return False, None, profile_data_list

    common_lshapes_found_instances = []  # Temporary list to store common lshape defect instance information
    processed_bbox1_indices = set()  # To track bbox1s that have been processed as a reference point

    # Search for common lshape defects
    for i, data1 in enumerate(all_lshape_data):
        for bbox1_idx, bbox1 in enumerate(data1["bboxes"]):
            # Create a unique key for the current bbox1
            bbox1_key = (i, bbox1_idx, bbox1[0], bbox1[1], bbox1[2], bbox1[3])
            if bbox1_key in processed_bbox1_indices:
                continue  # Skip if this bbox1 has already been used as the main reference for a common lshape defect

            common_lshape_count = 1
            matching_images_data = [data1] 
            candidate_common_bboxes = [bbox1]  # List of bboxes forming this common lshape defect group
            matching_file_names = [data1["file_name"]]  # Track file names that have this common defect
            # To store keys of bbox2s that matched in this iteration
            matched_bbox2_keys = set()

            for j, data2 in enumerate(all_lshape_data):
                if i == j: continue  # Avoid comparing with itself
                for bbox2_idx, bbox2 in enumerate(data2["bboxes"]):
                    # Create key for bbox2
                    bbox2_key = (j, bbox2_idx, bbox2[0], bbox2[1], bbox2[2], bbox2[3])
                    
                    if are_centers_close(bbox1, bbox2, tolerance=100):
                        common_lshape_count += 1
                        matching_images_data.append(data2)
                        candidate_common_bboxes.append(bbox2)
                        matching_file_names.append(data2["file_name"])
                        # Mark bbox1 and bbox2 as processed as part of a common lshape defect
                        processed_bbox1_indices.add(bbox1_key)
                        matched_bbox2_keys.add(bbox2_key)  # Store matched bbox2s
                        break  # Only need one matching bbox in this image
            
            # CHỈ xử lý khi có ít nhất 3 file có defect trùng nhau
            if common_lshape_count >= 3:
                # Add all matched bbox2s to the processed list
                processed_bbox1_indices.update(matched_bbox2_keys)

                # Calculate common center for the current common lshape defect cluster
                all_centers_x_current_cluster = [b[0] + b[2] / 2 for b in candidate_common_bboxes]
                all_centers_y_current_cluster = [b[1] + b[3] / 2 for b in candidate_common_bboxes]

                avg_center_x_current_cluster = int(np.mean(all_centers_x_current_cluster))
                avg_center_y_current_cluster = int(np.mean(all_centers_y_current_cluster))

                # Find the position with the highest variance in the common lshape defect region across all matching images
                max_variance_val_current_cluster = -1
                best_center_x_current_cluster, best_center_y_current_cluster = avg_center_x_current_cluster, avg_center_y_current_cluster

                for data in matching_images_data:
                    for bbox in data["bboxes"]:
                        if are_centers_close(bbox1, bbox, tolerance=100):  # Check if this bbox belongs to the same common lshape defect
                            x, y, w, h = bbox
                            sub_var_img = data["var_img"][y:y+h, x:x+w]
                            if sub_var_img.size > 0:
                                max_idx = np.unravel_index(np.argmax(sub_var_img, axis=None), sub_var_img.shape)
                                current_max_variance = sub_var_img[max_idx]
                                
                                if current_max_variance > max_variance_val_current_cluster:
                                    max_variance_val_current_cluster = current_max_variance
                                    best_center_x_current_cluster = x + max_idx[1]
                                    best_center_y_current_cluster = y + max_idx[0]
                
                # Define bounding box for this common lshape defect instance
                x_common_instance = max(0, best_center_x_current_cluster - 200)
                y_common_instance = max(0, best_center_y_current_cluster - 200)
                w_common_instance = 300 
                h_common_instance = 300 

                # Determine the sharpest image for this defect instance based on largest MASK area among matched bboxes
                best_img_idx_for_instance = None
                best_mask_area_for_instance = -1
                for j, data2 in enumerate(all_lshape_data):
                    mask_img_j = data2["mask_img"]
                    for bbox2 in data2["bboxes"]:
                        if are_centers_close(bbox1, bbox2, tolerance=100):
                            x2, y2, w2, h2 = bbox2
                            sub_mask = mask_img_j[y2:y2+h2, x2:x2+w2]
                            # Count white pixels (mask is 0/255 or 0/65535 but we drew 65535 then converted to uint8 earlier)
                            mask_area = int(np.count_nonzero(sub_mask))
                            if mask_area > best_mask_area_for_instance:
                                best_mask_area_for_instance = mask_area
                                best_img_idx_for_instance = j

                # Store information about this common lshape defect instance
                common_lshapes_found_instances.append({
                    "bbox": (x_common_instance, y_common_instance, w_common_instance, h_common_instance),
                    "center": (best_center_x_current_cluster, best_center_y_current_cluster),
                    "best_img_idx": best_img_idx_for_instance,
                    "best_mask_area": best_mask_area_for_instance,
                    "matching_file_names": matching_file_names  # Store list of files with this common defect
                })

    # --- End of loop for detecting common lshape defect instances ---

    final_aggregated_common_lshapes = []
    # Logic to aggregate common_lshapes_found_instances if they are too close
    merge_tolerance = 100  # Threshold to merge nearby lshape defects (pixels)

    for instance in common_lshapes_found_instances:
        current_bbox = instance["bbox"]
        merged = False
        for i, merged_bbox in enumerate(final_aggregated_common_lshapes):
            # Check if current_bbox is close enough to merge with merged_bbox
            if are_centers_close(current_bbox, merged_bbox, tolerance=merge_tolerance):
                # Merge bounding boxes
                mx1, my1, mw1, mh1 = merged_bbox
                ix1, iy1, iw1, ih1 = current_bbox

                new_x1 = min(mx1, ix1)
                new_y1 = min(my1, iy1)
                new_x2 = max(mx1 + mw1, ix1 + iw1)
                new_y2 = max(my1 + mh1, iy1 + ih1)

                final_aggregated_common_lshapes[i] = (new_x1, new_y1, new_x2 - new_x1, new_y2 - new_y1)
                merged = True
                break
        if not merged:
            final_aggregated_common_lshapes.append(current_bbox)

    if final_aggregated_common_lshapes:
        # Tạo set chứa tất cả các file có common defect (đã được xác nhận có ít nhất 3 file)
        all_files_with_common_defects = set()
        
        # Duyệt qua từng common defect instance đã được xác nhận
        for instance in common_lshapes_found_instances:
            if "matching_file_names" in instance:
                # Chỉ thêm các file trong nhóm có từ 3 file trở lên
                if len(instance["matching_file_names"]) >= 3:
                    for fname in instance["matching_file_names"]:
                        all_files_with_common_defects.add(fname)
        
        # Cập nhật Status cho các file có common defect
        for data in all_lshape_data:
            if data["file_name"] in all_files_with_common_defects:
                profile_data_list[data["profile_index"]]["Status"] = "NG"
                # Ensure Status_Check is "LShape Defect Found"
                profile_data_list[data["profile_index"]]["Status_Check"] = "LShape Defect Found"
            else:
                # Giữ nguyên Status = OK cho các file không có common defect
                profile_data_list[data["profile_index"]]["Status"] = "OK"
        
        # Log thông tin chi tiết
        lshape_checker_thread.update_log.emit(f"Found {len(final_aggregated_common_lshapes)} aggregated common LShape defects for pattern {pattern} in folder {os.path.basename(folder_path)}")
        lshape_checker_thread.update_log.emit(f"Files marked as NG: {len(all_files_with_common_defects)} out of {len(all_lshape_data)} total files")
        
        # Chọn ảnh đậm nhất cho Excel report (giữ nguyên logic cũ)
        selected_img_idx = 0
        selected_area = -1
        for instance in common_lshapes_found_instances:
            if instance.get("best_mask_area", -1) > selected_area and instance.get("best_img_idx") is not None:
                selected_area = instance["best_mask_area"]
                selected_img_idx = instance["best_img_idx"]

        base_original_img = all_lshape_data[selected_img_idx]["original_img"]
        img_height, img_width = base_original_img.shape[:2]

        # Create a single result image marking all common lshape defects
        result_with_all_common_lshapes = cv2.cvtColor(base_original_img, cv2.COLOR_GRAY2BGR)
        
        for idx, (x, y, w, h) in enumerate(final_aggregated_common_lshapes):
            cv2.rectangle(result_with_all_common_lshapes, (x, y), (x + w, y + h), (0, 0, 255), 2)
            # Add sequence number to bounding box
            text = str(idx + 1)
            font = cv2.FONT_HERSHEY_SIMPLEX
            font_scale = 1
            font_thickness = 2
            text_size = cv2.getTextSize(text, font, font_scale, font_thickness)[0]
            # Place number at top-left corner, outside the bounding box
            text_x = x - 5 - text_size[0]  # Shift left by 5 pixels and subtract text width
            text_y = y - 5  # Shift up by 5 pixels
            # Ensure number is not cut off outside the image
            text_x = max(0, text_x)
            text_y = max(text_size[1], text_y)  # Ensure text_y is at least text height to avoid being cut off at the top
            cv2.putText(result_with_all_common_lshapes, text, (text_x, text_y), font, font_scale, (0, 0, 255), font_thickness, cv2.LINE_AA)

        # Create unique file name for the aggregated result image
        aggregated_result_img_path = os.path.join(mark_lshapes_dir, f"{base_folder_name}_{pattern}_all_common_lshapes_result.png")
        cv2.imwrite(aggregated_result_img_path, result_with_all_common_lshapes)

        # Create individual cropped images for each common lshape defect
        individual_cropped_image_paths = []
        for idx, (x, y, w, h) in enumerate(final_aggregated_common_lshapes):
            # Add padding for each individual cropped image
            padding_individual_crop = 200 
            # Use center of bbox for cropping
            center_x = x + w // 2
            center_y = y + h // 2

            crop_x_start = max(0, center_x - padding_individual_crop)
            crop_y_start = max(0, center_y - padding_individual_crop)
            crop_x_end = min(img_width, center_x + padding_individual_crop)
            crop_y_end = min(img_height, center_y + padding_individual_crop)

            cropped_individual_img = base_original_img[crop_y_start:crop_y_end, crop_x_start:crop_x_end]
            
            individual_cropped_img_path = os.path.join(crop_lshapes_dir, f"{base_folder_name}_{pattern}_common_lshape_{idx+1}_cropped.png")
            cv2.imwrite(individual_cropped_img_path, cropped_individual_img)
            individual_cropped_image_paths.append(individual_cropped_img_path)

        # Return report entries for Excel
        report_entries = []
        for cropped_path in individual_cropped_image_paths:
            report_entries.append({
                "result_img_path": aggregated_result_img_path,
                "cropped_img_path": cropped_path,
            })
        return True, report_entries, profile_data_list
    else:
        # Nếu không có common defect, tất cả file đều Status = OK
        for data in all_lshape_data:
            profile_data_list[data["profile_index"]]["Status"] = "OK"
        
        return False, None, profile_data_list

def generate_excel_report(lshape_checker_thread, output_dir, reports, all_profile_data):
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "LShape Defect Report"
    # Prepare Summary workbook and sheet
    # Use summary_output_folder if provided, otherwise use parent of output_dir
    output_base = lshape_checker_thread.summary_output_folder if hasattr(lshape_checker_thread, 'summary_output_folder') and lshape_checker_thread.summary_output_folder else os.path.dirname(output_dir)
    summary_path = os.path.join(output_base, "Analysis_Report.xlsx")
    if os.path.exists(summary_path):
        summary_wb = _load_wb(summary_path)
    else:
        summary_wb = Workbook()
        summary_wb.active.title = "Summary"
    if "LShape Defect Report" in summary_wb.sheetnames:
        summary_ws = summary_wb["LShape Defect Report"]
        summary_wb.remove(summary_ws)
        summary_ws = summary_wb.create_sheet("LShape Defect Report")
    else:
        summary_ws = summary_wb.create_sheet("LShape Defect Report")

    # Determine the maximum number of cropped images to create dynamic column headers
    max_cropped_images = 0
    for report_entry in reports:
        if "Cropped_Images" in report_entry and report_entry["Cropped_Images"] is not None:
            max_cropped_images = max(max_cropped_images, len(report_entry["Cropped_Images"]))

    # Add headers with yellow background and bold font
    headers = ["Folder", "PTN", "Status", "Original Image with Mark"]
    for i in range(max_cropped_images):
        headers.append(f"Cropped Image {i+1}")
    sheet.append(headers)
    summary_ws.append(headers)

    header_fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
    header_font = Font(bold=True)
    border_style = Border(left=Side(style="thin"), right=Side(style="thin"), top=Side(style="thin"), bottom=Side(style="thin"))

    for col in range(1, len(headers) + 1):
        cell = sheet.cell(row=1, column=col)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = border_style
        scell = summary_ws.cell(row=1, column=col)
        scell.fill = header_fill
        scell.font = header_font
        scell.alignment = Alignment(horizontal="center", vertical="center")
        scell.border = border_style

    # Set fixed column widths
    sheet.column_dimensions['A'].width = 25
    sheet.column_dimensions['B'].width = 20
    sheet.column_dimensions['C'].width = 25
    sheet.column_dimensions['D'].width = 45
    summary_ws.column_dimensions['A'].width = 25
    summary_ws.column_dimensions['B'].width = 20
    summary_ws.column_dimensions['C'].width = 25
    summary_ws.column_dimensions['D'].width = 45

    # Alternating background colors for rows with the same folder name
    colors = ["D9EAD3", "C9DAF8"]
    current_color_index = 0
    prev_folder = None

    def calc_status_height(text):
        clean_text = (text or "").strip()
        if not clean_text:
            return 20
        approx_chars_per_line = 28
        lines = max(1, math.ceil(len(clean_text) / approx_chars_per_line))
        return lines * 18 + 4

    def adjust_status_cells(main_row, summary_row, status_text):
        desired_height = calc_status_height(status_text)
        for target_ws, row in ((sheet, main_row), (summary_ws, summary_row)):
            cell = target_ws.cell(row=row, column=3)
            cell.alignment = Alignment(horizontal="center", vertical="center", wrapText=True)
            current_height = target_ws.row_dimensions[row].height if target_ws.row_dimensions[row].height is not None else 0
            if desired_height > current_height:
                target_ws.row_dimensions[row].height = desired_height

    # Separate reports into two groups: with errors and without errors
    # Display folders with errors first (on top), then folders without errors
    reports_with_errors = []
    reports_without_errors = []
    
    for report_entry in reports:
        status = report_entry.get("Status", "")
        if status == "LShape Defect Found":
            reports_with_errors.append(report_entry)
        else:
            reports_without_errors.append(report_entry)
    
    # Combine: errors first, then no errors
    sorted_reports = reports_with_errors + reports_without_errors
    
    for row_idx, report_entry in enumerate(sorted_reports, start=2):
        folder = report_entry.get("Folder", "-")
        ptn = report_entry.get("Pattern", "-")
        status = report_entry.get("Status", "LShape Found")
        result_img_path = report_entry.get("Result_Image")
        cropped_images_paths = report_entry.get("Cropped_Images")

        if folder != prev_folder:
            current_color_index = (current_color_index + 1) % 2
            prev_folder = folder
        row_fill = PatternFill(start_color=colors[current_color_index], end_color=colors[current_color_index], fill_type="solid")

        row_data = [folder, ptn, status]
        sheet.append(row_data)
        current_excel_row = sheet.max_row
        summary_ws.append(row_data)
        current_summary_row = summary_ws.max_row

        for col in range(1, len(row_data) + 1):
            cell = sheet.cell(row=current_excel_row, column=col)
            cell.alignment = Alignment(horizontal="center", vertical="center")
            cell.fill = row_fill
            cell.border = border_style
            scell = summary_ws.cell(row=current_summary_row, column=col)
            scell.alignment = Alignment(horizontal="center", vertical="center")
            scell.fill = row_fill
            scell.border = border_style

        adjust_status_cells(current_excel_row, current_summary_row, status)

        # Insert aggregated result image into column D
        if result_img_path and os.path.exists(result_img_path):
            with Image.open(result_img_path) as img_result_pil:
                w, h = img_result_pil.size
            scaled_w = int(w * lshape_checker_thread.IMAGE_SCALE_FACTOR)
            scaled_h = int(h * lshape_checker_thread.IMAGE_SCALE_FACTOR)

            img_result = ExcelImage(result_img_path)
            img_result.width = scaled_w
            img_result.height = scaled_h
            sheet.add_image(img_result, f'D{current_excel_row}')
            img_result2 = ExcelImage(result_img_path)
            img_result2.width = scaled_w
            img_result2.height = scaled_h
            summary_ws.add_image(img_result2, f'D{current_summary_row}')

            current_row_height = sheet.row_dimensions[current_excel_row].height if sheet.row_dimensions[current_excel_row].height is not None else 0
            new_row_height = int(scaled_h * 0.75) + 2
            sheet.row_dimensions[current_excel_row].height = max(current_row_height, new_row_height)
            s_current_row_height = summary_ws.row_dimensions[current_summary_row].height if summary_ws.row_dimensions[current_summary_row].height is not None else 0
            s_new_row_height = int(scaled_h * 0.75) + 2
            summary_ws.row_dimensions[current_summary_row].height = max(s_current_row_height, s_new_row_height)
            
            current_col_width = sheet.column_dimensions['D'].width if sheet.column_dimensions['D'].width is not None else 0
            new_col_width = int(scaled_w / 7) + 2
            sheet.column_dimensions['D'].width = max(current_col_width, new_col_width)
            s_current_col_width = summary_ws.column_dimensions['D'].width if summary_ws.column_dimensions['D'].width is not None else 0
            s_new_col_width = int(scaled_w / 7) + 2
            summary_ws.column_dimensions['D'].width = max(s_current_col_width, s_new_col_width)

        # Insert individual cropped images into dynamic columns starting from column E
        if cropped_images_paths:
            for i, cropped_path in enumerate(cropped_images_paths):
                current_col_idx = 4 + i
                current_col_letter = get_column_letter(current_col_idx + 1)

                if cropped_path and os.path.exists(cropped_path):
                    with Image.open(cropped_path) as img_cropped_pil:
                        crop_width, crop_height = img_cropped_pil.size
                    
                    img_cropped = ExcelImage(cropped_path)
                    max_crop_size = 200
                    crop_ratio = min(max_crop_size / crop_width, max_crop_size / crop_height)
                    img_cropped.width = int(crop_width * crop_ratio)
                    img_cropped.height = int(crop_height * crop_ratio)
                    
                    sheet.add_image(img_cropped, f'{current_col_letter}{current_excel_row}')
                    img_cropped2 = ExcelImage(cropped_path)
                    img_cropped2.width = int(crop_width * crop_ratio)
                    img_cropped2.height = int(crop_height * crop_ratio)
                    summary_ws.add_image(img_cropped2, f'{current_col_letter}{current_summary_row}')

                    current_row_height = sheet.row_dimensions[current_excel_row].height if sheet.row_dimensions[current_excel_row].height is not None else 0
                    new_row_height = int(img_cropped.height * 0.75) + 2
                    sheet.row_dimensions[current_excel_row].height = max(current_row_height, new_row_height)
                    s_current_row_height = summary_ws.row_dimensions[current_summary_row].height if summary_ws.row_dimensions[current_summary_row].height is not None else 0
                    s_new_row_height = int(img_cropped.height * 0.75) + 2
                    summary_ws.row_dimensions[current_summary_row].height = max(s_current_row_height, s_new_row_height)

                    current_col_width = sheet.column_dimensions[current_col_letter].width if sheet.column_dimensions[current_col_letter].width is not None else 0
                    new_col_width = int(img_cropped.width / 7) + 2
                    sheet.column_dimensions[current_col_letter].width = max(current_col_width, new_col_width)
                    s_current_col_width = summary_ws.column_dimensions[current_col_letter].width if summary_ws.column_dimensions[current_col_letter].width is not None else 0
                    s_new_col_width = int(img_cropped.width / 7) + 2
                    summary_ws.column_dimensions[current_col_letter].width = max(s_current_col_width, s_new_col_width)

    excel_file_path = os.path.join(output_dir, "LShape_Defect_Report.xlsx")
    workbook.save(excel_file_path)
    summary_wb.save(summary_path)
    
    # Create a CSV file containing profile details for ALL files
    if all_profile_data:
        csv_file_path = os.path.join(output_dir, "LShape_Profile_Details.csv")
        df = pd.DataFrame(all_profile_data)
        
        # Arrange columns for easier readability
        column_order = [
            "Folder", "File Name", "Pattern", "Status_Check", "Status",
            "R Parameter", "Threshold Scale", "Threshold Used",
            "Number of Defects", "Max Variance", "Mean Variance", "Defect Positions"
        ]
        # Only retain the columns present in the DataFrame
        available_columns = [col for col in column_order if col in df.columns]
        df = df[available_columns]
        
        # Sort by Folder, then Status (NG first, then OK), then Status_Check, then File Name
        if 'Status' in df.columns:
            df['Status_Order'] = df['Status'].map({'NG': 0, 'OK': 1})
            if 'Status_Check' in df.columns:
                df['Status_Check_Order'] = df['Status_Check'].map({'LShape Defect Found': 0, 'OK': 1})
                df = df.sort_values(by=["Folder", "Status_Order", "Status_Check_Order", "File Name"])
                df = df.drop(['Status_Order', 'Status_Check_Order'], axis=1)
            else:
                df = df.sort_values(by=["Folder", "Status_Order", "File Name"])
                df = df.drop('Status_Order', axis=1)
        else:
            df = df.sort_values(by=["Folder", "File Name"])
        
        # Save file CSV
        df.to_csv(csv_file_path, index=False, encoding='utf-8-sig')
        lshape_checker_thread.update_log.emit(f"Profile details CSV saved (all files): {csv_file_path}")
        
        # Print statistics
        total_files = len(df)
        ng_files = len(df[df['Status'] == 'NG']) if 'Status' in df.columns else 0
        ok_files = total_files - ng_files
        defect_found_files = len(df[df['Status_Check'] == 'LShape Defect Found']) if 'Status_Check' in df.columns else 0
        
        lshape_checker_thread.update_log.emit(f"CSV Statistics: Total={total_files}, NG={ng_files}, OK={ok_files}, LShape Defect Found={defect_found_files}")
    
    try:
        lshape_checker_thread.update_log.emit(f"Summary updated: {summary_path} -> 'LShape Defect Report'")
    except Exception:
        pass


# New class for running analysis in the background thread
class LShapeCheckerThread(QThread):
    update_progress = pyqtSignal(int)
    update_log = pyqtSignal(str)
    finished = pyqtSignal(list)

    ANALYSIS_RESULTS_FOLDER = "LShape_Analysis_Results"
    IMAGE_SCALE_FACTOR = 0.18  # Set constant here

    def __init__(self, root_folder, summary_output_folder=None):
        super().__init__()
        self.root_folder = root_folder
        self.summary_output_folder = summary_output_folder  # Folder for Analysis_Report.xlsx
        self.analysis_output_folder = os.path.join(self.root_folder, self.ANALYSIS_RESULTS_FOLDER)
        self.mask_images_dir = os.path.join(self.analysis_output_folder, "mask_images")
        self.mark_lshapes_dir = os.path.join(self.analysis_output_folder, "mark_lshapes")
        self.crop_lshapes_dir = os.path.join(self.analysis_output_folder, "crop_lshapes")
        
        os.makedirs(self.analysis_output_folder, exist_ok=True)
        os.makedirs(self.mask_images_dir, exist_ok=True)
        os.makedirs(self.mark_lshapes_dir, exist_ok=True)
        os.makedirs(self.crop_lshapes_dir, exist_ok=True)
        self.temp_files_to_delete = []  # Initialize list for temporary files
        self.all_profile_data = []  # Store all profile data for CSV export (ALL files)

    def _prepare_folder_for_analysis(self, folder_path, folder_name):
        # Get a list of TIFF files directly in the folder
        initial_image_paths = [os.path.join(folder_path, fname) 
                               for fname in os.listdir(folder_path) 
                               if fname.lower().endswith('.tif') and '_ori.tif' not in fname.lower()]

        if initial_image_paths:  # If TIFF images are found directly in the folder (excluding _ori.tif)
            self.update_log.emit(f"Found {len(initial_image_paths)} TIFF images directly in {folder_name}.")
            return initial_image_paths

        # If no direct TIFF images, search subfolders and copy them to the root folder
        self.update_log.emit(f"No TIFF images found directly in {folder_name}. Searching subfolders and copying...")
        copied_image_paths = []
        for root, _, files in os.walk(folder_path):
            if root == folder_path:  # Skip the root folder itself
                continue
            
            # Filter files for .tif and exclude _ori.tif
            filtered_files = [f for f in files if f.lower().endswith('.tif') and '_ori.tif' not in f.lower()]
            
            if filtered_files:  # If any relevant TIFF files found in subfolder
                parent_subfolder_name = os.path.basename(root)
                self.update_log.emit(f"  Found {len(filtered_files)} TIFF images in subfolder: {parent_subfolder_name}")

                for file in filtered_files:
                    original_path = os.path.join(root, file)
                    
                    # Create new name: Parent_Subfolder_Name_Original_File_Name.tif
                    new_file_name = f"{parent_subfolder_name}_{file}"
                    destination_path = os.path.join(folder_path, new_file_name)
                    
                    shutil.copy2(original_path, destination_path)
                    copied_image_paths.append(destination_path)
                    self.temp_files_to_delete.append(destination_path)  # Add to deletion list
                    self.update_log.emit(f"Copied '{os.path.basename(original_path)}' to '{new_file_name}' in {folder_name} for analysis.")

        return copied_image_paths

    def save_lshape_image(self, img_path, lshape_pos, folder_name, ptn):
        try:
            img = Image.open(img_path)
            img_array = np.array(img)

            x, y = lshape_pos
            crop_size = 50
            left = max(0, x - crop_size // 2)
            top = max(0, y - crop_size // 2)
            right = min(img_array.shape[1], x + crop_size // 2)
            bottom = min(img_array.shape[0], y + crop_size // 2)

            cropped_img = img.crop((left, top, right, bottom))
            
            if cropped_img.mode in ('I;16', 'I'):
                array = np.array(cropped_img, dtype=np.float32)
                array -= array.min()
                array /= array.max()
                array *= 255.0
                array = array.astype(np.uint8)
                cropped_img = Image.fromarray(array, mode='L')

            output_path = os.path.join(self.crop_lshapes_dir, f"{folder_name}_{ptn}_lshape_crop.jpg")
            cropped_img.save(output_path, 'JPEG', quality=95)
            self.update_log.emit(f"Cropped image saved at: {output_path}")
            return output_path
        except Exception as e:
            self.update_log.emit(f"Error saving cropped image: {str(e)}")
            return None

    def save_marked_image(self, img_path, lshape_pos, folder_name, ptn):
        try:
            img = Image.open(img_path)
            img_array = np.array(img)
            
            if img_array.dtype == np.uint16:
                array = np.array(img, dtype=np.float32)
                array -= array.min()
                array /= array.max()
                array *= 255.0
                array = array.astype(np.uint8)
                img = Image.fromarray(array, mode='L')
            
            img_rgb = img.convert('RGB')
            img_array = np.array(img_rgb)
            
            x, y = lshape_pos
            size = 30
            color = [255, 0, 0]
            
            for i in range(-size, size + 1):
                for j in range(-size, size + 1):
                    if (abs(i) >= size-3 or abs(j) >= size-3) and \
                       0 <= x + i < img_array.shape[1] and 0 <= y + j < img_array.shape[0]:
                        img_array[y + j, x + i] = color
            
            marked_img = Image.fromarray(img_array)
            
            output_path = os.path.join(self.mark_lshapes_dir, f"{folder_name}_{ptn}_marked.jpg")
            marked_img.save(output_path, 'JPEG', quality=95)
            self.update_log.emit(f"Marked image saved at: {output_path}")
            
            new_width = int(marked_img.width * self.IMAGE_SCALE_FACTOR)
            new_height = int(marked_img.height * self.IMAGE_SCALE_FACTOR)
            scaled_marked_img = marked_img.resize((new_width, new_height), Image.Resampling.LANCZOS)
            scaled_output_path = os.path.join(self.mark_lshapes_dir, f"{folder_name}_{ptn}_marked_scaled.jpg")
            scaled_marked_img.save(scaled_output_path, 'JPEG', quality=95)
            self.update_log.emit(f"Scaled marked image saved at: {scaled_output_path}")
            
            return output_path, scaled_output_path, marked_img.size
        except Exception as e:
            self.update_log.emit(f"Error saving marked image: {str(e)}")
            return None, None, None

    def run(self):
        try:
            grouped_reports = []
            # Exclude analysis results folders when exporting report
            excluded_folders = ["Hiaa_Analysis_Results", "Bubble_Analysis_Results", "Hotpixel_Analysis_Results", "Dust_Analysis_Results",
                               "LShape_Analysis_Results", "CCD_Analysis_Results", "Top_Edge_Analysis_Results"]
            # Get a list of subfolders in the root folder
            folders = [f for f in os.listdir(self.root_folder) 
                      if os.path.isdir(os.path.join(self.root_folder, f)) 
                      and f not in excluded_folders]
            total_folders = len(folders)

            if total_folders == 0:
                # Still create CSV if profile data is available
                if self.all_profile_data:
                    self._save_csv_only()
                self.finished.emit([])
                return

            for idx, folder_name in enumerate(folders):
                folder_path = os.path.join(self.root_folder, folder_name)
                
                self.update_progress.emit(int((idx + 1) / total_folders * 100))
                self.update_log.emit(f"Checking folder: {folder_name}...")

                # Prepare images for analysis: copy from subfolders if necessary
                image_paths_for_analysis = self._prepare_folder_for_analysis(folder_path, folder_name)
                
                # Skip if no TIFF images are found after preparation (including filtering by PTN)
                if not image_paths_for_analysis:
                    self.update_log.emit(f"No relevant TIFF images found in folder: {folder_name} for analysis.")
                    grouped_reports.append({
                        "Folder": folder_name,
                        "Pattern": "-",
                        "Status": "No valid TIFF images available for checking",
                        "Result_Image": None,
                        "Cropped_Images": []
                    })
                    continue

                # Determine resolution once per folder (assumption: same resolution within a camera folder)
                folder_img_w = None
                folder_img_h = None
                for _p in image_paths_for_analysis:
                    _img = cv2.imread(_p, cv2.IMREAD_UNCHANGED | cv2.IMREAD_ANYDEPTH)
                    if _img is not None:
                        folder_img_h, folder_img_w = _img.shape[:2]
                        break

                grouped_files_by_position = {}
                for img_path in image_paths_for_analysis:
                    file_name = os.path.basename(img_path)
                    if file_name.lower().endswith(".tif"):
                        pattern, group_key = _extract_lshape_pattern_and_group_key(file_name, folder_img_w, folder_img_h)
                        if pattern and group_key:
                            if group_key not in grouped_files_by_position:
                                grouped_files_by_position[group_key] = []
                            grouped_files_by_position[group_key].append(file_name)

                if not grouped_files_by_position:
                    grouped_reports.append({
                        "Folder": folder_name,
                        "Pattern": "-",
                        "Status": "No valid pattern found (requires pattern in LShape_PTN_Check)",
                        "Result_Image": None,
                        "Cropped_Images": []
                    })
                    continue

                for group_key, file_names_in_group in grouped_files_by_position.items():
                    lshape_found_in_group, report_entries, profile_data_list = check_for_common_lshape_defects(
                        self,
                        folder_path, file_names_in_group, group_key,
                        self.mask_images_dir, self.mark_lshapes_dir, self.crop_lshapes_dir
                    )
                    
                    # Save ALL profile data (both OK and Defect Found)
                    self.all_profile_data.extend(profile_data_list)
                    
                    if lshape_found_in_group:
                        cropped_list = [entry["cropped_img_path"] for entry in (report_entries or []) if entry.get("cropped_img_path")]
                        result_image = report_entries[0]["result_img_path"] if report_entries else None
                        grouped_reports.append({
                            "Folder": folder_name,
                            "Pattern": group_key,
                            "Status": "LShape Defect Found",
                            "Result_Image": result_image,
                            "Cropped_Images": cropped_list
                        })
                    else:
                        grouped_reports.append({
                            "Folder": folder_name,
                            "Pattern": group_key,
                            "Status": "No LShape defects detected",
                            "Result_Image": None,
                            "Cropped_Images": []
                        })
            
            if grouped_reports:
                generate_excel_report(self, self.analysis_output_folder, grouped_reports, self.all_profile_data)
                self.update_log.emit("Analysis complete! Excel report and CSV file generated with all files.")
                
                lshape_folders = list(set(report['Folder'] for report in grouped_reports if report.get("Status") == "LShape Defect Found"))
                self.finished.emit(lshape_folders)
            else:
                # Still create CSV if profile data is available
                if self.all_profile_data:
                    self._save_csv_only()
                
                self.update_log.emit("Analysis complete! No folders processed, but CSV file generated with all checked files.")
                self.finished.emit([])

        except Exception as e:
            self.update_log.emit(f"Error: {type(e).__name__} - {str(e)}")
            self.finished.emit([])
        finally:
            # Clean up temporary copied files
            if self.temp_files_to_delete:
                self.update_log.emit("Cleaning up temporary files...")
                for temp_file in self.temp_files_to_delete:
                    if os.path.exists(temp_file):
                        try:
                            os.remove(temp_file)
                            self.update_log.emit(f"Deleted temporary file: {os.path.basename(temp_file)}")
                        except Exception as e:
                            self.update_log.emit(f"Error deleting temporary file {os.path.basename(temp_file)}: {str(e)}")
                self.temp_files_to_delete.clear()
    
    def _save_csv_only(self):
        """Save CSV only when there's no Excel report"""
        if self.all_profile_data:
            csv_file_path = os.path.join(self.analysis_output_folder, "LShape_Profile_Details.csv")
            df = pd.DataFrame(self.all_profile_data)
            
            # Arrange columns
            column_order = [
                "Folder", "File Name", "Pattern", "Status_Check", "Status",
                "R Parameter", "Threshold Scale", "Threshold Used",
                "Number of Defects", "Max Variance", "Mean Variance", "Defect Positions"
            ]
            available_columns = [col for col in column_order if col in df.columns]
            df = df[available_columns]
            
            # Sort
            if 'Status' in df.columns:
                df['Status_Order'] = df['Status'].map({'NG': 0, 'OK': 1})
                if 'Status_Check' in df.columns:
                    df['Status_Check_Order'] = df['Status_Check'].map({'LShape Defect Found': 0, 'OK': 1})
                    df = df.sort_values(by=["Folder", "Status_Order", "Status_Check_Order", "File Name"])
                    df = df.drop(['Status_Order', 'Status_Check_Order'], axis=1)
                else:
                    df = df.sort_values(by=["Folder", "Status_Order", "File Name"])
                    df = df.drop('Status_Order', axis=1)
            else:
                df = df.sort_values(by=["Folder", "File Name"])
            
            df.to_csv(csv_file_path, index=False, encoding='utf-8-sig')
            self.update_log.emit(f"Profile details CSV saved: {csv_file_path}")
            
            # Print statistics
            total_files = len(df)
            ng_files = len(df[df['Status'] == 'NG']) if 'Status' in df.columns else 0
            ok_files = total_files - ng_files
            self.update_log.emit(f"CSV Statistics: Total={total_files}, NG={ng_files}, OK={ok_files}")