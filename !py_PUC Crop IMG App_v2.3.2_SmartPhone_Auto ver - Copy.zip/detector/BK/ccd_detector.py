import os
import sys
import math
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from PIL import Image, ImageDraw
from PyQt6.QtCore import QThread, pyqtSignal
import openpyxl
from openpyxl.drawing.image import Image as ExcelImage
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment, PatternFill, Border, Side, Font
import re
import shutil
from openpyxl import load_workbook as _load_wb
try:
    import pythoncom
    import win32com.client as win32
except Exception:
    win32 = None
    pythoncom = None

# Global cache for settings.csv
_SETTINGS_DF = None


def get_script_dir():
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    else:
        return os.path.dirname(os.path.realpath(__file__))

script_dir = get_script_dir()

def _load_settings_df():
    """Load settings.csv once and cache it."""
    global _SETTINGS_DF
    if _SETTINGS_DF is not None:
        return _SETTINGS_DF
    try:
        csv_path = os.path.join(script_dir, "settings.csv")
        if os.path.exists(csv_path):
            import pandas as pd
            _SETTINGS_DF = pd.read_csv(csv_path)
        else:
            _SETTINGS_DF = None
    except Exception:
        _SETTINGS_DF = None
    return _SETTINGS_DF

BOUNDING_BOX_PADDING = 18

# Scale factors for images and plots in Excel (0.0 to 1.0)
IMAGE_SCALE_FACTOR = 0.18

class CCDChecker(QThread):
    # Signals to update progress and log
    update_progress = pyqtSignal(int)
    update_log = pyqtSignal(str)
    finished = pyqtSignal(list)

    # Thresholds per PTN color are now fully driven by settings.csv (CCD_Threshold_* columns)
    _THRESHOLDS = {}

    def __init__(self, root_folder, summary_output_folder=None):
        super().__init__()
        self.root_folder = root_folder
        self.summary_output_folder = summary_output_folder  # Folder for Analysis_Report.xlsx
        self.temp_files_to_delete = []
        self.all_profile_data = []  # Store all profile data for CSV export

    def _get_ccd_config_for_image(self, img_width, img_height, filename):
        """
        Read CCD_* config (offset mapping and thresholds) from settings.csv for given resolution and pattern.
        Returns dict:
          {
            "offset": int or None,
            "thresholds": {
               'B': {'horizontal': {'slope': ..., 'deviation': ...}, 'vertical': {...}},
               'G': {...},
               'R': {...}
            }
          }
        """
        df = _load_settings_df()
        cfg = {"offset": None, "thresholds": {}}
        if df is None:
            return cfg

        resolution_key = f"{img_width};{img_height}"
        candidates = df

        # It is MANDATORY to match Display_Resolution in the CSV file.
        # If there are no matching lines, then consider this image as having no configuration.
        if "Display_Resolution" in candidates.columns:
            res_series = candidates["Display_Resolution"].astype(str)
            mask_res = res_series == resolution_key
            if mask_res.any():
                candidates = candidates[mask_res]
            else:
                return cfg

        # Filter by CCD_PTN_Check using filename pattern, if PTN is configured.
        # If PTN is not listed in CCD_PTN_Check for that line, then there is no configuration for this image.
        ptn = self.extract_ptn_from_filename(filename)
        if ptn and "CCD_PTN_Check" in candidates.columns:
            ptn_series = candidates["CCD_PTN_Check"].astype(str)
            mask_ptn = ptn_series.str.contains(ptn, na=False)
            if mask_ptn.any():
                candidates = candidates[mask_ptn]
            else:
                return cfg

        if candidates.empty:
            return cfg

        row = candidates.iloc[0]

        def _get_float(col):
            if col not in row or pd.isna(row[col]) or row[col] == "":
                return None
            try:
                return float(row[col])
            except Exception:
                return None

        # Offset mapping
        off = _get_float("CCD_Offset_Mapping") if "CCD_Offset_Mapping" in row else None
        if off is not None:
            cfg["offset"] = int(round(off))

        # Thresholds per color – must come entirely from settings.csv
        color_map = {'B': 'B', 'G': 'G', 'R': 'R'}
        for col_key, color in color_map.items():
            h_slope = _get_float(f"CCD_Threshold_{col_key}_H_Slope")
            v_slope = _get_float(f"CCD_Threshold_{col_key}_V_Slope")
            h_dev = _get_float(f"CCD_Threshold_{col_key}_H_Deviation")
            v_dev = _get_float(f"CCD_Threshold_{col_key}_V_Deviation")

            if any(v is not None for v in (h_slope, v_slope, h_dev, v_dev)):
                cfg["thresholds"][color] = {
                    "horizontal": {
                        "slope": h_slope,
                        "deviation": h_dev,
                    },
                    "vertical": {
                        "slope": v_slope,
                        "deviation": v_dev,
                    },
                }

        return cfg

    def _get_ccd_ptn_list(self):
        """
        Get the list of laboratories from the CCD_PTN_Check column (format: step01_0300NIT_R216;step01_0300NIT_G216;...).
        """
        df = _load_settings_df()
        if df is None or "CCD_PTN_Check" not in df.columns:
            return []
        out = []
        for val in df["CCD_PTN_Check"].dropna().astype(str):
            for p in val.split(";"):
                p = p.strip()
                if p and p not in out:
                    out.append(p)
        return out

    def _extract_ccd_pattern_from_filename(self, filename):
        """
        Get the CCD pattern from the filename based on the CCD_PTN_Check column in settings.csv.
        Only files containing one of the CCD_PTN_Check values ​​(split according to ;) are considered valid.
        """
        if not filename:
            return None
        fname = str(filename)
        for ptn in self._get_ccd_ptn_list():
            if ptn and ptn in fname:
                return ptn
        return None

    def _get_ptn_color(self, ptn_code):
        """Extracts the color (B, G, R) from a PTN"""
        if not ptn_code:
            return None
        
        # Find the colored character B/G/R that precedes any 3-digit string.
        match = re.search(r'([BGR])\d{3}', ptn_code, re.IGNORECASE)
        if match:
            return match.group(1).upper()
        return None

    def _is_valid_step_file(self, filename):
        return True

    def _has_valid_ptn_number(self, filename):
        """
        Chỉ chấp nhận file nếu tên có chứa một pattern nằm trong cột CCD_PTN_Check.
        """
        return self._extract_ccd_pattern_from_filename(filename) is not None

    def _describe_missing_image_reason(self, stats):
        """Generate human-readable reason when no valid TIFF images are available"""
        if not stats.get("has_any_tiff"):
            return "No TIFF images found in folder"
        if not stats.get("has_valid_step"):
            return "No matching TIFF images with expected naming pattern found"
        if not stats.get("has_valid_ptn"):
            return "No images whose filename matches any CCD_PTN_Check pattern in settings.csv"
        return "No eligible TIFF images for checking"

    def run(self):
        try:
            import matplotlib
            matplotlib.use('Agg') # Use non-interactive backend for Matplotlib
            
            # Get all subfolders
            folders = self.get_subfolders_with_tiff_images(self.root_folder)
            if not folders:
                self.update_log.emit("No folders with TIFF images found!")
                self.finished.emit([])
                return

            self.update_log.emit(f"Found {len(folders)} folders to process")
            all_results = {}
            all_ccd_folders = {}
            all_best_images = {}
            folder_status_notes = []
            all_processed_folders = set()  # Track all folders that have been checked
            
            total_folders = len(folders)
            processed_folders = 0
            
            for folder_path in folders:
                folder_name = os.path.basename(folder_path)
                all_processed_folders.add(folder_name)  # Track this folder as processed
                self.update_log.emit(f"Processing folder: {folder_name}")
                
                # Check if folder exists and is accessible
                if not os.path.exists(folder_path) or not os.path.isdir(folder_path):
                    folder_status_notes.append({
                        "folder": folder_name,
                        "ptn": "-",
                        "status": "Folder not accessible or does not exist",
                        "details": ""
                    })
                    processed_folders += 1
                    progress = int((processed_folders / total_folders) * 100)
                    self.update_progress.emit(progress)
                    continue
                
                # Process images in this folder
                try:
                    images, image_stats = self.read_tiff_images(folder_path)
                except Exception as e:
                    folder_status_notes.append({
                        "folder": folder_name,
                        "ptn": "-",
                        "status": f"Error reading folder: {str(e)}",
                        "details": ""
                    })
                    processed_folders += 1
                    progress = int((processed_folders / total_folders) * 100)
                    self.update_progress.emit(progress)
                    continue
                
                if not images:
                    reason = self._describe_missing_image_reason(image_stats)
                    folder_status_notes.append({
                        "folder": folder_name,
                        "ptn": "-",
                        "status": reason,
                        "details": ""
                    })
                    self.update_log.emit(f"No TIFF images found in {folder_name}!")
                    processed_folders += 1
                    progress = int((processed_folders / total_folders) * 100)
                    self.update_progress.emit(progress)
                    continue
                
                results, ccd_folders, best_images, processed_images = self.process_all_images(images, folder_path)
                
                # Collect results
                all_results.update(results)
                all_ccd_folders.update(ccd_folders)
                all_best_images.update(best_images)

                # Always add folder to notes if it doesn't have CCD or best images
                if folder_name not in best_images:
                    note_status = "No valid CCD images after filtering (no CCD_PTN_Check match)" if processed_images == 0 else "No CCD detected"
                    detail = "" if processed_images == 0 else f"Processed {processed_images} valid images"
                    folder_status_notes.append({
                        "folder": folder_name,
                        "ptn": "-",
                        "status": note_status,
                        "details": detail
                    })
                
                processed_folders += 1
                progress = int((processed_folders / total_folders) * 100)
                self.update_progress.emit(progress)
            
            # Export results to Excel - pass all processed folders to ensure all are included
            self.update_log.emit(f"Total folders processed: {len(all_processed_folders)}")
            self.update_log.emit(f"Folders with CCD: {len(all_best_images)}")
            self.update_log.emit(f"Folders in status notes: {len(folder_status_notes)}")
            excel_report_path, folders_with_ccd = self.export_to_excel(
                all_results, all_ccd_folders, all_best_images, self.root_folder, folder_status_notes, all_processed_folders
            )
            
            self.update_progress.emit(100)
            self.finished.emit(folders_with_ccd)
            
        except Exception as e:
            self.update_log.emit(f"Error: {str(e)}")
            self.finished.emit([])

    def get_subfolders_with_tiff_images(self, root_folder):
        """Get all immediate subfolders of root_folder (excluding analysis results folders).
        Include ALL folders so that folders without images can also be reported."""
        folders_to_process = []
        # Skip analysis results folders when exporting report
        excluded_folders = ["Hiaa_Analysis_Results", "Bubble_Analysis_Results", "Hotpixel_Analysis_Results", "Dust_Analysis_Results",
                               "LShape_Analysis_Results", "CCD_Analysis_Results", "Top_Edge_Analysis_Results"]
        
        for item in os.listdir(root_folder):
            path = os.path.join(root_folder, item)
            if os.path.isdir(path):
                # Skip analysis results folders
                if os.path.basename(path) in excluded_folders:
                    continue
                
                # Include ALL folders (not just those with TIFF images)
                # This ensures folders without images are also processed and reported
                folders_to_process.append(path)
        
        return folders_to_process

    def _has_relevant_tiff_images_in_folder(self, folder_path):
        """Helper to check if a folder directly contains relevant TIFF images or its immediate subfolders do."""
        # Check direct level
        for file in os.listdir(folder_path):
            if (file.lower().endswith(('.tif', '.tiff')) and 
                self._has_valid_ptn_number(file) and 
                self._is_valid_step_file(file) and 
                '_ori.tif' not in file.lower()):
                return True
        
        # If no direct TIFFs, check one level deeper into immediate subfolders
        excluded_folders = ["Hiaa_Analysis_Results", "Bubble_Analysis_Results", "Hotpixel_Analysis_Results", "Dust_Analysis_Results",
                               "LShape_Analysis_Results", "CCD_Analysis_Results", "Top_Edge_Analysis_Results"]
        for item in os.listdir(folder_path):
            subfolder_path = os.path.join(folder_path, item)
            if os.path.isdir(subfolder_path) and os.path.basename(subfolder_path) not in excluded_folders:
                for file in os.listdir(subfolder_path):
                    if (file.lower().endswith(('.tif', '.tiff')) and 
                        self._has_valid_ptn_number(file) and 
                        self._is_valid_step_file(file) and 
                        '_ori.tif' not in file.lower()):
                        return True
                        
        return False

    def _extract_ptn_from_subfolder_name(self, subfolder_name):
        """Extracts the PTN prefix from a subfolder name"""
        match = re.match(r'([A-Z0-9]+)_.*', subfolder_name)
        if match:
            return match.group(1)
        return None

    def read_tiff_images(self, folder_path):
        """Read all 16-bit TIFF images in the folder that contain valid PTN numbers and step patterns, handling nested images.

        Returns (images, stats) describing why images might be missing.
        """
        tiff_files = []
        has_any_tiff = False
        has_valid_step = False
        has_valid_ptn = False

        for file in os.listdir(folder_path):
            file_lower = file.lower()
            if file_lower.endswith(('.tif', '.tiff')):
                if '_ori.tif' in file_lower:
                    has_any_tiff = True
                    continue

                has_any_tiff = True
                valid_step = self._is_valid_step_file(file)
                valid_ptn = self._has_valid_ptn_number(file)
                has_valid_step = has_valid_step or valid_step
                has_valid_ptn = has_valid_ptn or valid_ptn

                if valid_step and valid_ptn:
                    tiff_files.append(os.path.join(folder_path, file))
        
        # If no TIFF files are found directly, check one level deeper and copy them out
        if not tiff_files:
            self.update_log.emit(f"No direct TIFF images found in {os.path.basename(folder_path)}. Checking subfolders...")
            for item in os.listdir(folder_path):
                subfolder_path = os.path.join(folder_path, item)
                if os.path.isdir(subfolder_path):
                    for file in os.listdir(subfolder_path):
                        file_lower = file.lower()
                        if file_lower.endswith(('.tif', '.tiff')):
                            if '_ori.tif' in file_lower:
                                has_any_tiff = True
                                continue

                            has_any_tiff = True
                            valid_step = self._is_valid_step_file(file)
                            valid_ptn = self._has_valid_ptn_number(file)
                            has_valid_step = has_valid_step or valid_step
                            has_valid_ptn = has_valid_ptn or valid_ptn

                            if valid_step and valid_ptn:
                                original_nested_file_path = os.path.join(subfolder_path, file)
                                
                                # Remove '_imgY_Crop' from filename if present
                                cleaned_filename = file.replace('_imgY_Crop', '')
                                
                                # Extract PTN from subfolder name and prepend it to the filename
                                ptn_prefix = self._extract_ptn_from_subfolder_name(os.path.basename(subfolder_path))
                                if ptn_prefix:
                                    new_filename = f"{ptn_prefix}_{cleaned_filename}"
                                else:
                                    new_filename = cleaned_filename
                                    
                                destination_path = os.path.join(folder_path, new_filename)
                                
                                try:
                                    # Copy the file to the current folder_path
                                    shutil.copy2(original_nested_file_path, destination_path)
                                    tiff_files.append(destination_path) # Add the copied file to our list
                                    self.temp_files_to_delete.append(destination_path) # Mark for deletion
                                    self.update_log.emit(f"Copied and renamed nested TIFF: {original_nested_file_path} -> {destination_path}")
                                except Exception as e:
                                    self.update_log.emit(f"Error copying file {original_nested_file_path}: {e}")
        
        images = {}
        self.update_log.emit(f"Found {len(tiff_files)} relevant TIFF images in {os.path.basename(folder_path)}. Reading...")
        for file_path in tiff_files:
            try:
                img = Image.open(file_path)
                img_array = np.array(img)
                relative_path = os.path.relpath(file_path, self.root_folder)
                images[relative_path] = {
                    'array': img_array,
                    'full_path': file_path,
                    'folder': os.path.basename(os.path.dirname(relative_path)),
                    'filename': os.path.basename(file_path)
                }
            except Exception as e:
                self.update_log.emit(f"Error reading {file_path}: {e}")
        self.update_log.emit(f"Finished reading {len(images)} images from {os.path.basename(folder_path)}.")
        stats = {
            "has_any_tiff": has_any_tiff,
            "has_valid_step": has_valid_step,
            "has_valid_ptn": has_valid_ptn
        }
        return images, stats

    def process_all_images(self, images, folder_path):
        """Process all images in a single folder and return results"""
        results = {}
        folder_ccd_status = {}  # Track CCD status by folder and PTN
        
        total_images = len(images)
        processed_images = 0
        folder_name = os.path.basename(folder_path)
        
        for img_rel_path, img_info in images.items():
            img_name = img_info['filename']
            
            # Extract PTN from filename
            ptn = self.extract_ptn_from_filename(img_name)
            if ptn is None:
                self.update_log.emit(f"Skipping image (no valid PTN found): {img_rel_path}")
                continue
            
            image = img_info['array']

            # Extract PTN color
            ptn_color = self._get_ptn_color(ptn)
            if ptn_color is None:
                self.update_log.emit(f"Skipping image (unknown PTN color): {img_rel_path}")
                continue

            height, width = image.shape[:2]
            resolution_key = f"{width};{height}"

            # Load CCD config (offset + thresholds) from settings.csv
            cfg = self._get_ccd_config_for_image(width, height, img_name)
            if cfg.get("offset") is None:
                self.update_log.emit(
                    f"Skipping image (missing CCD_Offset_Mapping): {img_rel_path} for resolution {resolution_key}"
                )
                continue
            if not cfg.get("thresholds") or ptn_color not in cfg["thresholds"]:
                self.update_log.emit(
                    f"Skipping image (missing CCD_Threshold_* for color {ptn_color}): {img_rel_path} for resolution {resolution_key}"
                )
                continue

            # Update in-memory thresholds map for this PTN color (used by slope/severity functions)
            self._THRESHOLDS[ptn_color] = cfg["thresholds"][ptn_color]

            processed_images += 1
            self.update_log.emit(f"Processing image {processed_images}/{total_images} in {folder_name}: {img_name}")
            
            # Save original image path
            original_image_path = img_info['full_path']
            
            # Create subfolder CCD Analysis Results in the root folder
            ccd_analysis_results_folder = os.path.join(self.root_folder, "CCD_Analysis_Results")
            os.makedirs(ccd_analysis_results_folder, exist_ok=True)

            # Divide image (offset already validated above)
            division_info = self.divide_image(image)
            center_y = division_info['horizontal_line']
            vertical_lines = division_info['vertical_lines']
            
            # Calculate horizontal line data (4x3 = 12 intervals)
            horizontal_data_result = self.calculate_horizontal_data(image, center_y, vertical_lines, ptn_color)
            
            # Calculate data for 3 vertical lines (3 lines x 2x3 = 18 intervals)
            vertical_data_all_result = {}
            for i, vertical_line in enumerate(vertical_lines):
                vertical_data_result = self.calculate_vertical_data(image, vertical_line, center_y, ptn_color)
                for key, value in vertical_data_result.items():
                    vertical_data_all_result[f'line_{i+1}_{key}'] = value
            
            all_error_coords_for_marking = [] # đánh dấu trên ảnh
            all_error_data_for_cropping = [] # tìm max slope và crop
            horizontal_errors = 0
            vertical_errors = 0
            
            # Calculate max slope from ALL slopes (before filtering errors)
            # Collect ALL slopes from horizontal and vertical data BEFORE processing errors
            all_slopes_list = []
            
            # First pass: Collect all slopes from horizontal data
            for key, data_obj in horizontal_data_result.items():
                if isinstance(data_obj, dict) and 'slopes' in data_obj:
                    slopes = data_obj['slopes']
                    # Collect all slopes, even if empty or all zeros
                    if isinstance(slopes, (list, np.ndarray)):
                        # Convert to list if numpy array
                        if isinstance(slopes, np.ndarray):
                            slopes = slopes.tolist()
                        # Filter out any None or invalid values, but keep zeros and small values
                        valid_slopes = []
                        for s in slopes:
                            if s is None:
                                continue
                            if isinstance(s, float) and (np.isnan(s) or np.isinf(s)):
                                continue
                            try:
                                valid_slopes.append(float(s))
                            except (ValueError, TypeError):
                                continue
                        if valid_slopes:
                            all_slopes_list.extend(valid_slopes)
                            if len(valid_slopes) > 0:
                                max_in_segment = max(valid_slopes)
                                self.update_log.emit(f"[{img_name}] Collected {len(valid_slopes)} slopes from horizontal {key}, max in segment: {max_in_segment:.6f}")

            # First pass: Collect all slopes from vertical data
            for key, data_obj in vertical_data_all_result.items():
                if isinstance(data_obj, dict) and 'slopes' in data_obj:
                    slopes = data_obj['slopes']
                    # Collect all slopes, even if empty or all zeros
                    if isinstance(slopes, (list, np.ndarray)):
                        # Convert to list if numpy array
                        if isinstance(slopes, np.ndarray):
                            slopes = slopes.tolist()
                        # Filter out any None or invalid values, but keep zeros and small values
                        valid_slopes = []
                        for s in slopes:
                            if s is None:
                                continue
                            if isinstance(s, float) and (np.isnan(s) or np.isinf(s)):
                                continue
                            try:
                                valid_slopes.append(float(s))
                            except (ValueError, TypeError):
                                continue
                        if valid_slopes:
                            all_slopes_list.extend(valid_slopes)
                            if len(valid_slopes) > 0:
                                max_in_segment = max(valid_slopes)
                                self.update_log.emit(f"[{img_name}] Collected {len(valid_slopes)} slopes from vertical {key}, max in segment: {max_in_segment:.6f}")
            
            # Calculate max slope from all slopes (actual max, regardless of threshold)
            if all_slopes_list:
                max_slope_actual = max(all_slopes_list)
                min_slope_actual = min(all_slopes_list)
                avg_slope_actual = np.mean(all_slopes_list)
                # Show some sample slopes to debug
                sorted_slopes = sorted(all_slopes_list, reverse=True)
                top_5_slopes = sorted_slopes[:5] if len(sorted_slopes) >= 5 else sorted_slopes
                self.update_log.emit(f"[{img_name}] Max slope (all): {max_slope_actual:.6f}, Min: {min_slope_actual:.6f}, Avg: {avg_slope_actual:.6f}, Total slopes: {len(all_slopes_list)}, Top 5: {[f'{s:.6f}' for s in top_5_slopes]}")
            else:
                max_slope_actual = 0.0
                self.update_log.emit(f"[{img_name}] Warning: No slopes found, max_slope_actual set to 0.0")
            
            # Second pass: Collect error coordinates and slope values from horizontal data
            for key, data_obj in horizontal_data_result.items():
                if isinstance(data_obj, dict) and 'slopes' in data_obj:
                    for idx, slope_val in enumerate(data_obj['slopes']):
                        if idx < len(data_obj.get('errors', [])):
                            error_coord = data_obj['errors'][idx]
                            all_error_coords_for_marking.append(error_coord)
                            all_error_data_for_cropping.append((error_coord, slope_val))
                            horizontal_errors += 1 # Increment horizontal_errors
                    horizontal_data_result[key] = data_obj['slopes'] # Keep only slopes for final result

            # Second pass: Collect error coordinates and slope values from vertical data
            for key, data_obj in vertical_data_all_result.items():
                if isinstance(data_obj, dict) and 'slopes' in data_obj:
                    for idx, slope_val in enumerate(data_obj['slopes']):
                        if idx < len(data_obj.get('errors', [])):
                            error_coord = data_obj['errors'][idx]
                            all_error_coords_for_marking.append(error_coord)
                            all_error_data_for_cropping.append((error_coord, slope_val))
                            vertical_errors += 1 # Increment vertical_errors
                    vertical_data_all_result[key] = data_obj['slopes'] # Keep only slopes for final result
            
            # Calculate error severity
            severity_score = self.calculate_error_severity(horizontal_data_result, vertical_data_all_result, ptn_color)
            
            self.update_log.emit(f"[{img_name}] Total errors detected: {len(all_error_coords_for_marking)}")
            self.update_log.emit(f"[{img_name}] Horizontal errors: {horizontal_errors}, Vertical errors: {vertical_errors}")
            self.update_log.emit(f"[{img_name}] Severity score: {severity_score:.6f}")
            
            cropped_error_path = None
            if all_error_data_for_cropping: # Nếu có lỗi, tạo ảnh crop
                height, width = image.shape
                cropped_error_path = self.save_cropped_error_region(
                    original_image_path, 
                    all_error_data_for_cropping, 
                    ccd_analysis_results_folder,
                    img_name,
                    height, width
                )

            if all_error_coords_for_marking:
                self.update_log.emit(f"[{img_name}] First error coordinates: {all_error_coords_for_marking[0]}")
                
                # Update folder CCD status - now organized by PTN
                if folder_name not in folder_ccd_status:
                    folder_ccd_status[folder_name] = {}
                
                # Use PTN as the key instead of grouping all values together
                if ptn not in folder_ccd_status[folder_name]:
                    folder_ccd_status[folder_name][ptn] = {
                        'count': 0, 
                        'images': [],
                        'error_regions': self.get_error_regions(all_error_coords_for_marking)
                    }
                
                folder_ccd_status[folder_name][ptn]['count'] += 1
                folder_ccd_status[folder_name][ptn]['images'].append({
                    'path': img_rel_path,
                    'severity': severity_score,
                    'error_regions': self.get_error_regions(all_error_coords_for_marking),
                    'ptn': ptn 
                })

            # Extract resolution information
            img_height, img_width = image.shape[:2]
            resolution = f"{img_width}x{img_height}"
            
            # Save profile information for CSV
            # Format error coordinates for CSV
            error_positions = ""
            if all_error_coords_for_marking:
                # Format as: (x1,y1)-(x2,y2); (x1,y1)-(x2,y2); ...
                coord_strings = []
                for coord_pair in all_error_coords_for_marking:
                    if len(coord_pair) == 2:
                        (x1, y1), (x2, y2) = coord_pair
                        coord_strings.append(f"({x1},{y1})-({x2},{y2})")
                error_positions = "; ".join(coord_strings)
            
            self.all_profile_data.append({
                "Folder": folder_name,
                "File Name": img_name,
                "Pattern": ptn if ptn else "Unknown",
                "Resolution": resolution,
                "Model": "CSV",
                "PTN Color": ptn_color if ptn_color else "Unknown",
                "Slope Threshold": self._THRESHOLDS[ptn_color]['horizontal']['slope'] if ptn_color in self._THRESHOLDS else "",
                "Deviation Threshold": self._THRESHOLDS[ptn_color]['horizontal']['deviation'] if ptn_color in self._THRESHOLDS else "",
                "Horizontal Errors": horizontal_errors,
                "Vertical Errors": vertical_errors,
                "Total Errors": len(all_error_coords_for_marking),
                "Severity Score": severity_score,
                "Max Slope": float(max_slope_actual) if max_slope_actual is not None else 0.0,  # Actual max slope from all slopes (regardless of threshold) - ensure it's a float
                "Has CCD": "Yes" if len(all_error_coords_for_marking) > 0 else "No",
                "Error Positions": error_positions,
                "Status": "CCD Detected" if len(all_error_coords_for_marking) > 0 else "OK"
            })
            
            # Combine data and error coordinates
            results[img_rel_path] = {
                'horizontal_data': horizontal_data_result,
                'vertical_data': vertical_data_all_result,
                'error_coords': all_error_coords_for_marking,
                'original_path': original_image_path,
                'folder': folder_name,
                'ptn': ptn,
                'has_ccd': len(all_error_coords_for_marking) > 0,
                'horizontal_errors': horizontal_errors,
                'vertical_errors': vertical_errors,
                'severity_score': severity_score,
                'error_regions': self.get_error_regions(all_error_coords_for_marking),
                'cropped_error_path': cropped_error_path # Add cropped image path to results
            }
        
        # Determine which folders have CCD issues (ít nhất 3 ảnh cùng PTN có CCD tại vị trí tương tự)
        ccd_folders = {}
        best_images = {}  # Track the best image for each PTN in each folder
        
        for folder_name, ptn_data in folder_ccd_status.items():
            for ptn, data in ptn_data.items():
                if data['count'] >= 3:  # Cần ít nhất 3 ảnh cùng PTN
                    # Check if at least 3 images have similar error regions
                    similar_error_count = 0
                    image_list = data['images']
                    
                    # Kiểm tra từng cặp ảnh để tìm vùng lỗi tương tự
                    for i in range(len(image_list)):
                        for j in range(i + 1, len(image_list)):
                            if self.check_similar_error_regions(image_list[i]['error_regions'], image_list[j]['error_regions']):
                                similar_error_count += 1
                                if similar_error_count >= 2:  # Chỉ cần 2 cặp tương đương với 3 ảnh
                                    break
                        if similar_error_count >= 2:
                            break
                    
                    if similar_error_count >= 2:  # Ít nhất 2 cặp có lỗi tương tự
                        if folder_name not in ccd_folders:
                            ccd_folders[folder_name] = []
                            best_images[folder_name] = {}
                        
                        # Tìm ảnh có severity cao nhất trong PTN này
                        max_severity = -1
                        best_image_path = None
                        for img_info in data['images']:
                            if img_info['severity'] > max_severity:
                                max_severity = img_info['severity']
                                best_image_path = img_info['path']
                        
                        ccd_folders[folder_name].append(ptn)
                        best_images[folder_name][ptn] = best_image_path
                        self.update_log.emit(f"CCD detected in folder '{folder_name}' for PTN '{ptn}' with {data['count']} images")
                        self.update_log.emit(f"Best image: {best_image_path} with severity {max_severity:.6f}")
                        self.update_log.emit(f"Similar error regions found in {similar_error_count} image pairs")
        
        return results, ccd_folders, best_images, processed_images

    def divide_image(self, image):
        """Divide image into 8 parts using special lines"""
        height, width = image.shape

        # Offset must come from settings.csv; assume already validated in process_all_images
        ccd_cfg = self._get_ccd_config_for_image(width, height, "")
        if ccd_cfg.get("offset") is None:
            raise ValueError("CCD_Offset_Mapping is missing for this resolution; skip image.")
        offset = ccd_cfg["offset"]
        
        # Find center and ±offset lines
        center_x = width // 2
        center_y = height // 2
        
        line1_x = center_x - offset
        line2_x = center_x
        line3_x = center_x + offset
        
        return {
            'horizontal_line': center_y,
            'vertical_lines': [line1_x, line2_x, line3_x]
        }

    def divide_interval_into_three(self, start, end):
        """Divide an interval into three equal sub-intervals"""
        interval_length = end - start
        sub_interval_length = interval_length / 3
        
        sub_intervals = [
            (start, start + sub_interval_length),
            (start + sub_interval_length, start + 2 * sub_interval_length),
            (start + 2 * sub_interval_length, end)
        ]
        
        return sub_intervals

    def calculate_slope_for_region(self, region_data, is_horizontal=True, ptn_color=None):
        """Calculate data slope for a region and return error positions"""
        if is_horizontal:
            # For horizontal line: calculate average by row
            averages = np.mean(region_data, axis=1)
        else:
            # For vertical line: calculate average by column
            averages = np.mean(region_data, axis=0)
        
        slopes = []
        error_indices = []
        
        # Get the appropriate thresholds strictly from settings.csv-backed map
        if not (ptn_color and ptn_color in self._THRESHOLDS):
            raise ValueError("Missing CCD_Threshold_* config for PTN color; skip image.")

        direction_key = 'horizontal' if is_horizontal else 'vertical'
        if direction_key not in self._THRESHOLDS[ptn_color]:
            raise ValueError(f"Missing CCD_Threshold_* for direction {direction_key}; skip image.")

        dir_cfg = self._THRESHOLDS[ptn_color][direction_key]
        if dir_cfg.get('slope') is None or dir_cfg.get('deviation') is None:
            raise ValueError(f"Incomplete CCD_Threshold_* (slope/deviation) for color {ptn_color}, direction {direction_key}; skip image.")

        slope_threshold = dir_cfg['slope']
        deviation_threshold = dir_cfg['deviation']

        for j in range(len(averages) - 5):
            avg_first_3 = np.mean(averages[j:j+3])
            avg_next_3 = np.mean(averages[j+3:j+6])
            avg_all_6 = np.mean(averages[j:j+6])
            
            if avg_all_6 > 0:
                slope = abs(avg_first_3 - avg_next_3) / avg_all_6
            else:
                slope = 0
            slopes.append(slope)
        
        # Calculate average of all slopes in this region
        if slopes:
            avg_slope_region = np.mean(slopes)
            
            # Check for errors using the new condition
            for j, slope_val in enumerate(slopes):
                # Condition 1: slope value is above threshold
                condition1 = slope_val > slope_threshold
                
                # Condition 2: (slope_val - avg_slope_region) / avg_slope_region > deviation_threshold
                condition2 = False
                if avg_slope_region > 0:
                    relative_deviation = (slope_val - avg_slope_region) / avg_slope_region
                    condition2 = relative_deviation > deviation_threshold
                
                # Both conditions must be met for error detection
                if condition1 and condition2:
                    error_indices.append(j)
                    self.update_log.emit(f"Error detected at index {j}: slope={slope_val:.6f}, "
                                    f"avg_region={avg_slope_region:.6f}, "
                                    f"relative_deviation={relative_deviation:.2f}")
        
        return slopes, error_indices


    def calculate_horizontal_data(self, image, center_y, vertical_lines, ptn_color):
        """Calculate data for horizontal line divided into 3 sub-intervals"""
        height, width = image.shape
        horizontal_data = {}
        
        # Get 41 rows around the horizontal line (20 above + 1 at line + 20 below)
        start_row = max(0, center_y - 20)
        end_row = min(height, center_y + 21)
        horizontal_region = image[start_row:end_row, :]
        
        # Divide into 4 large horizontal segments based on vertical lines
        large_intervals = [
            (0, vertical_lines[0]),
            (vertical_lines[0], vertical_lines[1]),
            (vertical_lines[1], vertical_lines[2]),
            (vertical_lines[2], width)
        ]
        
        for i, (start_col, end_col) in enumerate(large_intervals):
            # Divide each large interval into 3 sub-intervals
            sub_intervals = self.divide_interval_into_three(start_col, end_col)
            
            for j, (sub_start, sub_end) in enumerate(sub_intervals):
                segment_key = f'horizontal_segment_{i+1}_sub_{j+1}'
                
                # Skip error detection for horizontal_segment_1_sub_1
                skip_error_detection = (segment_key == 'horizontal_segment_1_sub_1')
                
                # Get the part of horizontal region corresponding to this sub-interval
                sub_region = horizontal_region[:, int(sub_start):int(sub_end)]
                
                # Calculate data slope for this sub-interval
                slopes, error_indices = self.calculate_slope_for_region(sub_region, is_horizontal=True, ptn_color=ptn_color)
                
                horizontal_data[segment_key] = {
                    'slopes': slopes,
                    'errors': []
                }
                
                # Skip error coordinate conversion for horizontal_segment_1_sub_1
                if skip_error_detection:
                    self.update_log.emit(f"Skipping error detection for {segment_key}")
                    continue
                
                # Convert error indices to actual pixel coordinates (only for non-skipped segments)
                for error_idx in error_indices:
                    # Pixel y position (row) in original image
                    pixel_y_center = start_row + error_idx
                    original_pixel_y_start = max(0, pixel_y_center - 2)
                    original_pixel_y_end = min(height, pixel_y_center + 3)
                    
                    # Pixel x position (column) in original image - entire sub-interval
                    original_pixel_x_start = int(sub_start)
                    original_pixel_x_end = int(sub_end)
                    
                    # Apply padding
                    padded_pixel_x_start = max(0, original_pixel_x_start - BOUNDING_BOX_PADDING)
                    padded_pixel_x_end = min(width, original_pixel_x_end + BOUNDING_BOX_PADDING)
                    padded_pixel_y_start = max(0, original_pixel_y_start - BOUNDING_BOX_PADDING)
                    padded_pixel_y_end = min(height, original_pixel_y_end + BOUNDING_BOX_PADDING)
                    
                    horizontal_data[segment_key]['errors'].append(
                        ((padded_pixel_x_start, padded_pixel_y_start), (padded_pixel_x_end, padded_pixel_y_end))
                    )
        
        return horizontal_data

    def calculate_vertical_data(self, image, vertical_line, center_y, ptn_color):
        """Calculate data for a vertical line divided into 3 sub-intervals"""
        height, width = image.shape
        vertical_data = {}
        
        # Get 41 columns around the vertical line (20 left + 1 at line + 20 right)
        start_col = max(0, vertical_line - 20)
        end_col = min(width, vertical_line + 21)
        vertical_region = image[:, start_col:end_col]
        
        # Divide into 2 large vertical segments based on horizontal line
        large_intervals = [
            (0, center_y),
            (center_y, height)
        ]
        
        for i, (start_row, end_row) in enumerate(large_intervals):
            # Divide each large interval into 3 sub-intervals
            sub_intervals = self.divide_interval_into_three(start_row, end_row)
            
            for j, (sub_start, sub_end) in enumerate(sub_intervals):
                # Get the part of vertical region corresponding to this sub-interval
                sub_region = vertical_region[int(sub_start):int(sub_end), :]
                
                # Calculate data slope for this sub-interval
                slopes, error_indices = self.calculate_slope_for_region(sub_region, is_horizontal=False, ptn_color=ptn_color)
                
                vertical_data[f'vertical_segment_{i+1}_sub_{j+1}'] = {
                    'slopes': slopes,
                    'errors': []
                }
                
                # Convert error indices to actual pixel coordinates
                for error_idx in error_indices:
                    # Pixel x position (column) in original image
                    pixel_x_center = start_col + error_idx
                    original_pixel_x_start = max(0, pixel_x_center - 2)
                    original_pixel_x_end = min(width, pixel_x_center + 3)
                    
                    # Pixel y position (row) in original image - entire sub-interval
                    original_pixel_y_start = int(sub_start)
                    original_pixel_y_end = int(sub_end)
                    
                    # Apply padding
                    padded_pixel_x_start = max(0, original_pixel_x_start - BOUNDING_BOX_PADDING)
                    padded_pixel_x_end = min(width, original_pixel_x_end + BOUNDING_BOX_PADDING)
                    padded_pixel_y_start = max(0, original_pixel_y_start - BOUNDING_BOX_PADDING)
                    padded_pixel_y_end = min(height, original_pixel_y_end + BOUNDING_BOX_PADDING)
                    
                    vertical_data[f'vertical_segment_{i+1}_sub_{j+1}']['errors'].append(
                        ((padded_pixel_x_start, padded_pixel_y_start), (padded_pixel_x_end, padded_pixel_y_end))
                    )
        
        return vertical_data

    def mark_image_with_errors(self, original_image_path, error_coords_list, output_folder, img_name):
        """Mark error regions on the original image and save"""
        try:
            img = Image.open(original_image_path)
            # Convert 16-bit image to 8-bit grayscale or RGB for drawing
            if img.mode == 'I;16':
                img_array = np.array(img, dtype=np.float32)
                img_array -= img_array.min()
                img_array /= img_array.max()
                img_array *= 255.0
                img = Image.fromarray(img_array.astype(np.uint8), mode='L').convert('RGB')
            elif img.mode == 'L':  # 8-bit Grayscale
                img = img.convert('RGB')
            
            draw = ImageDraw.Draw(img)
            
            for (x1, y1), (x2, y2) in error_coords_list:
                # Draw red rectangle around error region with 3-pixel width
                draw.rectangle([(x1, y1), (x2, y2)], outline="red", width=3)
            
            if not os.path.exists(output_folder):
                os.makedirs(output_folder)
            
            marked_image_path = os.path.join(output_folder, f"{os.path.splitext(img_name)[0]}_marked.jpg")
            # Save with high quality
            img.save(marked_image_path, quality=95)
            self.update_log.emit(f"Saved marked image: {marked_image_path}")
            
            # Create a scaled version for Excel with high quality
            new_width = int(img.width * IMAGE_SCALE_FACTOR)
            new_height = int(img.height * IMAGE_SCALE_FACTOR)
            
            # Use high-quality resampling
            scaled_img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)
            scaled_image_path = os.path.join(output_folder, f"{os.path.splitext(img_name)[0]}_marked_scaled.jpg")
            # Save with maximum quality
            scaled_img.save(scaled_image_path, quality=100, optimize=True)
            self.temp_files_to_delete.append(scaled_image_path) # Thêm vào danh sách xóa
            
            return marked_image_path, scaled_image_path, img.size
        except Exception as e:
            self.update_log.emit(f"Error marking image {original_image_path}: {e}")
            return None, None, None

    def save_cropped_error_region(self, original_image_path, all_error_data_for_cropping, output_folder, img_name, height, width):
        """Save a cropped image of the region with the highest slope within the error regions"""
        try:
            img = Image.open(original_image_path)
            if img.mode == 'I;16':
                img_array = np.array(img, dtype=np.float32)
                img_array -= img_array.min()
                img_array /= img_array.max()
                img_array *= 255.0
                img = Image.fromarray(img_array.astype(np.uint8), mode='L').convert('RGB')
            elif img.mode == 'L':
                img = img.convert('RGB')
            
            if not all_error_data_for_cropping:
                return None

            # Find the highest slope and its corresponding coordinates
            max_slope_value = -1
            best_error_coord = None
            
            for (error_coord, slope_val) in all_error_data_for_cropping:
                if slope_val > max_slope_value:
                    max_slope_value = slope_val
                    best_error_coord = error_coord

            if best_error_coord is None:
                return None
            
            ((x1, y1), (x2, y2)) = best_error_coord
            
            # Calculate crop region around the error
            crop_center_x = (x1 + x2) // 2
            crop_center_y = (y1 + y2) // 2
            crop_width = 400  
            crop_height = 200 

            left = max(0, crop_center_x - crop_width // 2)
            top = max(0, crop_center_y - crop_height // 2)
            right = min(width, crop_center_x + crop_width // 2)
            bottom = min(height, crop_center_y + crop_height // 2)
            
            cropped_img = img.crop((left, top, right, bottom))
            
            # Create subfolder for cropped images
            crop_output_folder = os.path.join(output_folder, "Cropped_Errors")
            os.makedirs(crop_output_folder, exist_ok=True)
            
            cropped_image_path = os.path.join(crop_output_folder, f"{os.path.splitext(img_name)[0]}_crop_max_slope.jpg")
            cropped_img.save(cropped_image_path, quality=90) # Save with high quality
            self.update_log.emit(f"Saved cropped error image: {cropped_image_path}")
            return cropped_image_path
        except Exception as e:
            self.update_log.emit(f"Error saving cropped error image {original_image_path}: {e}")
            return None

    def extract_ptn_from_filename(self, filename):
        """
        Get the laboratory from the filename based on the list in the CCD_PTN_Check column of settings.csv.
        If no value matches, return None.
        """
        return self._extract_ccd_pattern_from_filename(filename)

    def calculate_error_severity(self, horizontal_data, vertical_data, ptn_color=None):
        """Calculate error severity based on slope values with new condition"""
        severity_score = 0
        
        # Get the appropriate thresholds for severity calculation (must come from settings.csv)
        if not (ptn_color and ptn_color in self._THRESHOLDS):
            raise ValueError("Missing CCD_Threshold_* config for PTN color when calculating severity; skip image.")

        if 'horizontal' not in self._THRESHOLDS[ptn_color] or 'vertical' not in self._THRESHOLDS[ptn_color]:
            raise ValueError("Missing horizontal/vertical CCD_Threshold_* config for severity; skip image.")

        h_cfg = self._THRESHOLDS[ptn_color]['horizontal']
        v_cfg = self._THRESHOLDS[ptn_color]['vertical']
        if h_cfg.get('slope') is None or h_cfg.get('deviation') is None:
            raise ValueError("Incomplete horizontal CCD_Threshold_* for severity; skip image.")
        if v_cfg.get('slope') is None or v_cfg.get('deviation') is None:
            raise ValueError("Incomplete vertical CCD_Threshold_* for severity; skip image.")

        horizontal_slope_threshold = h_cfg['slope']
        horizontal_deviation_threshold = h_cfg['deviation']
        vertical_slope_threshold = v_cfg['slope']
        vertical_deviation_threshold = v_cfg['deviation']

        # Calculate severity from horizontal data (skip horizontal_segment_1_sub_1)
        for key, slopes in horizontal_data.items():
            # Skip severity calculation for horizontal_segment_1_sub_1
            if key == 'horizontal_segment_1_sub_1':
                continue
                
            if len(slopes) > 0:
                avg_slope = np.mean(slopes)
                
                for slope_val in slopes:
                    # Apply new condition: (slope_val - avg_slope) / avg_slope > deviation_threshold
                    if avg_slope > 0 and slope_val > horizontal_slope_threshold:
                        relative_deviation = (slope_val - avg_slope) / avg_slope
                        if relative_deviation > horizontal_deviation_threshold:
                            severity_score += slope_val
        
        # Calculate severity from vertical data (all vertical segments are processed)
        for key, slopes in vertical_data.items():
            if len(slopes) > 0:
                avg_slope = np.mean(slopes)
                
                for slope_val in slopes:
                    # Apply new condition: (slope_val - avg_slope) / avg_slope > deviation_threshold
                    if avg_slope > 0 and slope_val > vertical_slope_threshold:
                        relative_deviation = (slope_val - avg_slope) / avg_slope
                        if relative_deviation > vertical_deviation_threshold:
                            severity_score += slope_val
        
        return severity_score

    def get_error_regions(self, error_coords):
        """Extract error regions from coordinates"""
        regions = []
        for (x1, y1), (x2, y2) in error_coords:
            regions.append({
                'x1': x1,
                'y1': y1,
                'x2': x2,
                'y2': y2,
                'center_x': (x1 + x2) / 2,
                'center_y': (y1 + y2) / 2
            })
        return regions

    def check_similar_error_regions(self, regions1, regions2, tolerance=40):
        """Check if two sets of error regions are similar within tolerance"""
        if len(regions1) == 0 or len(regions2) == 0:
            return False
        
        # Check if at least one region in each set is similar
        for region1 in regions1:
            for region2 in regions2:
                # Check if centers are within tolerance distance
                distance = np.sqrt((region1['center_x'] - region2['center_x'])**2 + 
                                  (region1['center_y'] - region2['center_y'])**2)
                if distance <= tolerance:
                    return True
        
        return False

    def create_selective_plot_image(self, img_name, horizontal_data, vertical_data, horizontal_errors, vertical_errors, output_folder, ptn_color=None):
        """Create a selective plot image based on which direction has errors with threshold line."""
        
        # Get thresholds for plotting directly from settings-backed map
        horizontal_plot_threshold = None
        vertical_plot_threshold = None

        if ptn_color and ptn_color in self._THRESHOLDS:
            if 'horizontal' in self._THRESHOLDS[ptn_color]:
                horizontal_plot_threshold = self._THRESHOLDS[ptn_color]['horizontal']['slope']
            if 'vertical' in self._THRESHOLDS[ptn_color]:
                vertical_plot_threshold = self._THRESHOLDS[ptn_color]['vertical']['slope']
        
        # Determine which plot to create
        if horizontal_errors > 0 and vertical_errors > 0:
            # Both directions have errors - create both plots
            plt.figure(figsize=(10, 8), dpi=150)
            
            # Horizontal plot
            plt.subplot(2, 1, 1)
            colors = plt.cm.tab20(np.linspace(0, 1, len(horizontal_data)))
            for (key, values), color in zip(horizontal_data.items(), colors):
                plt.plot(values, label=key, color=color, linewidth=1.5)
            
            # Add threshold line
            plt.axhline(y=horizontal_plot_threshold, color='r', linestyle='--', linewidth=1, 
                       label=f'Threshold ({horizontal_plot_threshold:.4f})')
            
            plt.title(f'{img_name} - Horizontal Data Slope (12 sub-intervals)')
            plt.xlabel('Position Index')
            plt.ylabel('Slope Value')
            plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
            plt.grid(True, alpha=0.3)
            
            # Vertical plot
            plt.subplot(2, 1, 2)
            colors = plt.cm.tab20(np.linspace(0, 1, len(vertical_data)))
            for (key, values), color in zip(vertical_data.items(), colors):
                plt.plot(values, label=key, color=color, linewidth=1.5)
            
            # Add threshold line
            plt.axhline(y=vertical_plot_threshold, color='r', linestyle='--', linewidth=1, 
                       label=f'Threshold ({vertical_plot_threshold:.4f})')
            
            plt.title(f'{img_name} - Vertical Data Slope (18 sub-intervals)')
            plt.xlabel('Position Index')
            plt.ylabel('Slope Value')
            plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
            plt.grid(True, alpha=0.3)
            
            plt.tight_layout()
            
        elif horizontal_errors > 0:
            # Only horizontal errors - create horizontal plot only
            plt.figure(figsize=(10, 4), dpi=150)
            
            colors = plt.cm.tab20(np.linspace(0, 1, len(horizontal_data)))
            for (key, values), color in zip(horizontal_data.items(), colors):
                plt.plot(values, label=key, color=color, linewidth=1.5)
            
            # Add threshold line
            plt.axhline(y=horizontal_plot_threshold, color='r', linestyle='--', linewidth=1, 
                       label=f'Threshold ({horizontal_plot_threshold:.4f})')
            
            plt.title(f'{img_name} - Horizontal Data Slope (12 sub-intervals)')
            plt.xlabel('Position Index')
            plt.ylabel('Slope Value')
            plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
            plt.grid(True, alpha=0.3)
            
        elif vertical_errors > 0:
            # Only vertical errors - create vertical plot only
            plt.figure(figsize=(10, 4), dpi=150)
            
            colors = plt.cm.tab20(np.linspace(0, 1, len(vertical_data)))
            for (key, values), color in zip(vertical_data.items(), colors):
                plt.plot(values, label=key, color=color, linewidth=1.5)
            
            # Add threshold line
            plt.axhline(y=vertical_plot_threshold, color='r', linestyle='--', linewidth=1, 
                       label=f'Threshold ({vertical_plot_threshold:.4f})')
            
            plt.title(f'{img_name} - Vertical Data Slope (18 sub-intervals)')
            plt.xlabel('Position Index')
            plt.ylabel('Slope Value')
            plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
            plt.grid(True, alpha=0.3)
        
        else:
            # No errors - no plot needed
            return None, None
        
        # Create subfolder for plots
        plots_output_folder = output_folder
        os.makedirs(plots_output_folder, exist_ok=True)
        
        # Save plot with high quality (removed quality parameter for PNG)
        plot_filename = os.path.join(plots_output_folder, f"{os.path.splitext(img_name)[0]}_selective_plot.png")
        plt.savefig(plot_filename, dpi=300, bbox_inches='tight')
        plt.close()
        self.update_log.emit(f"Saved selective plot: {plot_filename}")
        
        # Create a scaled version for Excel with high quality
        plot_img = Image.open(plot_filename)
        new_width = int(plot_img.width * IMAGE_SCALE_FACTOR)
        new_height = int(plot_img.height * IMAGE_SCALE_FACTOR)
        
        # Use high-quality resampling
        scaled_plot = plot_img.resize((new_width, new_height), Image.Resampling.LANCZOS)
        scaled_plot_path = os.path.join(plots_output_folder, f"{os.path.splitext(img_name)[0]}_selective_plot_scaled.png")
        # Save with maximum quality
        scaled_plot.save(scaled_plot_path, optimize=True)
        self.temp_files_to_delete.append(scaled_plot_path) # Thêm file scaled plot vào danh sách xóa
        
        plot_img.close()
        scaled_plot.close()
        
        return plot_filename, scaled_plot_path

    def export_to_excel(self, results, ccd_folders, best_images, folder_path, folder_notes=None, all_processed_folders=None):
        """Export results to Excel file with only the best image for each PTN"""
        output_folder = os.path.join(folder_path, "CCD_Analysis_Results")
        if not os.path.exists(output_folder):
            os.makedirs(output_folder)
        
        # Create Excel workbook
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "CCD Analysis Report"
        # Prepare Summary workbook and sheet
        # Use summary_output_folder if provided, otherwise use root_folder
        output_base = self.summary_output_folder if self.summary_output_folder else self.root_folder
        summary_path = os.path.join(output_base, "Analysis_Report.xlsx")
        if os.path.exists(summary_path):
            summary_wb = _load_wb(summary_path)
        else:
            from openpyxl import Workbook as _WB
            summary_wb = _WB()
            summary_wb.active.title = "Summary"
        if "CCD Analysis Report" in summary_wb.sheetnames:
            s_ws = summary_wb["CCD Analysis Report"]
            summary_wb.remove(s_ws)
            s_ws = summary_wb.create_sheet("CCD Analysis Report")
        else:
            s_ws = summary_wb.create_sheet("CCD Analysis Report")
        
        # Set column headers
        headers = [
            "Folder with CCD", 
            "Detected PTN", 
            "CCD Coordinates", 
            "CCD Status", 
            "Marked Image", 
            "Cropped Error Image", 
            "Plot" # Changed from "Severity Score"
        ]
        
        # Header background color
        header_fill_color = "D9E1F2" # Light blue/grey

        # Font for headers
        header_font = Font(size=12, bold=True, color="333333") # Lớn hơn, đậm hơn
        
        # Border style
        thin_border = Border(left=Side(style='thin'), 
                             right=Side(style='thin'), 
                             top=Side(style='thin'), 
                             bottom=Side(style='thin'))

        for col_idx, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            cell.alignment = Alignment(horizontal='center', vertical='center')
            cell.fill = PatternFill(start_color=header_fill_color, end_color=header_fill_color, fill_type="solid")
            cell.font = header_font # Áp dụng font cho header
            cell.border = thin_border # Kẻ bảng cho header
            ws.column_dimensions[get_column_letter(col_idx)].width = 20
            scell = s_ws.cell(row=1, column=col_idx, value=header)
            scell.alignment = Alignment(horizontal='center', vertical='center')
            scell.fill = PatternFill(start_color=header_fill_color, end_color=header_fill_color, fill_type="solid")
            scell.font = header_font
            scell.border = thin_border
            s_ws.column_dimensions[get_column_letter(col_idx)].width = 20
        
        # Process each image result
        row_idx = 2
        
        # Create subfolders for marked images and cropped errors
        marked_images_folder = os.path.join(output_folder, "Marked_Images")
        cropped_errors_folder = os.path.join(output_folder, "Cropped_Errors") 
        plots_output_folder = os.path.join(output_folder, "Plots") # Thêm dòng này
        os.makedirs(marked_images_folder, exist_ok=True)
        os.makedirs(cropped_errors_folder, exist_ok=True) 
        os.makedirs(plots_output_folder, exist_ok=True) # Thêm dòng này
        
        # Track which folders have CCD issues
        folders_with_ccd = set()

        # Colors for alternating folder rows (sáng hơn)
        background_colors = ["E0E0E0", "F8F8F8", "D0E0F8", "F8F0E0"]
        folder_color_map = {}
        color_index = 0

        def calc_status_height(text):
            clean_text = (text or "").strip()
            if not clean_text:
                return 20
            approx_chars_per_line = 30
            lines = max(1, math.ceil(len(clean_text) / approx_chars_per_line))
            return lines * 18 + 4

        def adjust_status_cells(row_number, status_text, target_ws=ws, summary_ws=s_ws, column_index=4):
            desired_height = calc_status_height(status_text)
            for board in (target_ws, summary_ws):
                cell = board.cell(row=row_number, column=column_index)
                cell.alignment = Alignment(horizontal='center', vertical='center', wrapText=True)
                current_height = board.row_dimensions[row_number].height if board.row_dimensions[row_number].height is not None else 0
                if desired_height > current_height:
                    board.row_dimensions[row_number].height = desired_height
        
        # Only process the best image for each PTN in each folder
        for folder_name, ptn_best_images in best_images.items():
            if folder_name not in folder_color_map:
                folder_color_map[folder_name] = background_colors[color_index % len(background_colors)]
                color_index += 1

            current_folder_fill = PatternFill(start_color=folder_color_map[folder_name], end_color=folder_color_map[folder_name], fill_type="solid")

            for ptn, best_image_path in ptn_best_images.items():
                if best_image_path in results:
                    data = results[best_image_path]
                    img_name = os.path.basename(best_image_path)
                    
                    folders_with_ccd.add(folder_name)
                    
                    # Column 1: Folder with CCD
                    cell_col1 = ws.cell(row=row_idx, column=1, value=folder_name)
                    cell_col1.alignment = Alignment(horizontal='center', vertical='center')
                    cell_col1.fill = current_folder_fill
                    cell_col1.border = thin_border # Kẻ bảng
                    s_cell_col1 = s_ws.cell(row=row_idx, column=1, value=folder_name)
                    s_cell_col1.alignment = Alignment(horizontal='center', vertical='center')
                    s_cell_col1.fill = current_folder_fill
                    s_cell_col1.border = thin_border
                    
                    # Column 2: Detected PTN
                    cell_col2 = ws.cell(row=row_idx, column=2, value=ptn)
                    cell_col2.alignment = Alignment(horizontal='center', vertical='center')
                    cell_col2.fill = current_folder_fill
                    cell_col2.border = thin_border # Kẻ bảng
                    s_cell_col2 = s_ws.cell(row=row_idx, column=2, value=ptn)
                    s_cell_col2.alignment = Alignment(horizontal='center', vertical='center')
                    s_cell_col2.fill = current_folder_fill
                    s_cell_col2.border = thin_border
                    
                    # Column 3: CCD Coordinates
                    error_coords = data['error_coords']
                    coord_text = "\n".join([f"({start_x},{start_y})-({end_x},{end_y})" for (start_x, start_y), (end_x, end_y) in error_coords[:5]]) # Hiển thị tọa độ chi tiết
                    if len(error_coords) > 5:
                        coord_text += f"\n... and {len(error_coords) - 5} more"
                    cell_col3 = ws.cell(row=row_idx, column=3, value=coord_text)
                    cell_col3.alignment = Alignment(horizontal='center', vertical='center', wrapText=True)
                    cell_col3.fill = current_folder_fill
                    cell_col3.border = thin_border # Kẻ bảng
                    ws.row_dimensions[row_idx].height = 120  # Adjust row height for coordinates
                    s_cell_col3 = s_ws.cell(row=row_idx, column=3, value=coord_text)
                    s_cell_col3.alignment = Alignment(horizontal='center', vertical='center', wrapText=True)
                    s_cell_col3.fill = current_folder_fill
                    s_cell_col3.border = thin_border
                    s_ws.row_dimensions[row_idx].height = 120
                    
                    # Column 4: CCD Status
                    status = "CCD Detected"
                    cell_col4 = ws.cell(row=row_idx, column=4, value=status)
                    cell_col4.alignment = Alignment(horizontal='center', vertical='center', wrapText=True)
                    cell_col4.fill = current_folder_fill
                    cell_col4.border = thin_border # Kẻ bảng
                    s_cell_col4 = s_ws.cell(row=row_idx, column=4, value=status)
                    s_cell_col4.alignment = Alignment(horizontal='center', vertical='center', wrapText=True)
                    s_cell_col4.fill = current_folder_fill
                    s_cell_col4.border = thin_border
                    adjust_status_cells(row_idx, status)
                    
                    # Column 5: Marked Image (scaled)
                    marked_image_path, scaled_image_path, img_size = self.mark_image_with_errors(
                        data['original_path'], error_coords, marked_images_folder, img_name
                    )
                    
                    if scaled_image_path and os.path.exists(scaled_image_path):
                        try:
                            excel_img = ExcelImage(scaled_image_path)
                            # Read the actual size of the image after scaling to maintain aspect ratio
                            with Image.open(scaled_image_path) as scaled_pil_img:
                                excel_img.width = scaled_pil_img.width
                                excel_img.height = scaled_pil_img.height
                            
                            # Adjust row height and column width based on image size
                            current_row_height = ws.row_dimensions[row_idx].height if ws.row_dimensions[row_idx].height is not None else 0
                            new_row_height = int(excel_img.height / 1.33) + 2 # 1.33 pixel = 1 point
                            ws.row_dimensions[row_idx].height = max(current_row_height, new_row_height)
                            
                            current_col_width = ws.column_dimensions['E'].width if ws.column_dimensions['E'].width is not None else 0
                            new_col_width = int(excel_img.width / 7) + 2 # 7 pixel = 1 unit
                            ws.column_dimensions['E'].width = max(current_col_width, new_col_width)
                            
                            excel_img.anchor = f'E{row_idx}'
                            ws.add_image(excel_img)
                            excel_img2 = ExcelImage(scaled_image_path)
                            with Image.open(scaled_image_path) as scaled_pil_img:
                                excel_img2.width = scaled_pil_img.width
                                excel_img2.height = scaled_pil_img.height
                            # Mirror row height/width for summary
                            s_current_row_height = s_ws.row_dimensions[row_idx].height if s_ws.row_dimensions[row_idx].height is not None else 0
                            s_new_row_height = int(excel_img2.height / 1.33) + 2
                            s_ws.row_dimensions[row_idx].height = max(s_current_row_height, s_new_row_height)
                            s_current_col_width = s_ws.column_dimensions['E'].width if s_ws.column_dimensions['E'].width is not None else 0
                            s_new_col_width = int(excel_img2.width / 7) + 2
                            s_ws.column_dimensions['E'].width = max(s_current_col_width, s_new_col_width)
                            excel_img2.anchor = f'E{row_idx}'
                            s_ws.add_image(excel_img2)
                        except Exception as e:  
                            self.update_log.emit(f"Error adding marked image to Excel: {e}")
                            cell_col5 = ws.cell(row=row_idx, column=5, value=f"Error: {str(e)}")
                            cell_col5.alignment = Alignment(horizontal='center', vertical='center')
                            cell_col5.fill = current_folder_fill
                            cell_col5.border = thin_border 
                    else:
                        cell_col5 = ws.cell(row=row_idx, column=5, value="No marked image available")
                        cell_col5.alignment = Alignment(horizontal='center', vertical='center')
                        cell_col5.fill = current_folder_fill
                        cell_col5.border = thin_border
                        s_cell_col5 = s_ws.cell(row=row_idx, column=5, value="No marked image available")
                        s_cell_col5.alignment = Alignment(horizontal='center', vertical='center')
                        s_cell_col5.fill = current_folder_fill
                        s_cell_col5.border = thin_border
                    
                    # Create charts
                    plot_path, scaled_plot_path = self.create_selective_plot_image(
                        img_name, data['horizontal_data'], data['vertical_data'], 
                        data['horizontal_errors'], data['vertical_errors'], plots_output_folder, ptn_color=self._get_ptn_color(data['ptn'])
                    )

                    # Column 6: Cropped Error Image
                    cropped_error_path = data['cropped_error_path']
                    if cropped_error_path and os.path.exists(cropped_error_path):
                        try:
                            excel_cropped_img = ExcelImage(cropped_error_path)
                            excel_cropped_img.width = 300
                            excel_cropped_img.height = 150
                            
                            # Adjust row height and column width
                            # Use slightly larger values ​​to allow for padding around the image
                            current_row_height = ws.row_dimensions[row_idx].height if ws.row_dimensions[row_idx].height is not None else 0
                            new_row_height = int(excel_cropped_img.height / 1.33) + 2 # 1.33 pixel = 1 point
                            ws.row_dimensions[row_idx].height = max(current_row_height, new_row_height)
                            
                            current_col_width = ws.column_dimensions['F'].width if ws.column_dimensions['F'].width is not None else 0
                            new_col_width = int(excel_cropped_img.width / 7) + 2 # 7 pixel = 1 unit
                            ws.column_dimensions['F'].width = max(current_col_width, new_col_width)

                            excel_cropped_img.anchor = f'F{row_idx}'
                            ws.add_image(excel_cropped_img)
                            excel_cropped_img2 = ExcelImage(cropped_error_path)
                            excel_cropped_img2.width = 300
                            excel_cropped_img2.height = 150
                            s_current_row_height = s_ws.row_dimensions[row_idx].height if s_ws.row_dimensions[row_idx].height is not None else 0
                            s_new_row_height = int(excel_cropped_img2.height / 1.33) + 2
                            s_ws.row_dimensions[row_idx].height = max(s_current_row_height, s_new_row_height)
                            s_current_col_width = s_ws.column_dimensions['F'].width if s_ws.column_dimensions['F'].width is not None else 0
                            s_new_col_width = int(excel_cropped_img2.width / 7) + 2
                            s_ws.column_dimensions['F'].width = max(s_current_col_width, s_new_col_width)
                            excel_cropped_img2.anchor = f'F{row_idx}'
                            s_ws.add_image(excel_cropped_img2)
                        except Exception as e:
                            self.update_log.emit(f"Error adding cropped image to Excel: {e}")
                            cell_col6 = ws.cell(row=row_idx, column=6, value=f"Error: {str(e)}")
                            cell_col6.alignment = Alignment(horizontal='center', vertical='center')
                            cell_col6.fill = current_folder_fill
                            cell_col6.border = thin_border
                    else:
                        cell_col6 = ws.cell(row=row_idx, column=6, value="No cropped image available")
                        cell_col6.alignment = Alignment(horizontal='center', vertical='center')
                        cell_col6.fill = current_folder_fill
                        cell_col6.border = thin_border
                        s_cell_col6 = s_ws.cell(row=row_idx, column=6, value="No cropped image available")
                        s_cell_col6.alignment = Alignment(horizontal='center', vertical='center')
                        s_cell_col6.fill = current_folder_fill
                        s_cell_col6.border = thin_border

                    # Column 7: Plot
                    if scaled_plot_path and os.path.exists(scaled_plot_path):
                        try:
                            excel_plot_img = ExcelImage(scaled_plot_path)
                            # Read the actual size of the image after scaling to maintain aspect ratio
                            with Image.open(scaled_plot_path) as scaled_pil_plot_img:
                                excel_plot_img.width = scaled_pil_plot_img.width
                                excel_plot_img.height = scaled_pil_plot_img.height
                            
                            # Adjust row height and column width based on image size
                            current_row_height = ws.row_dimensions[row_idx].height if ws.row_dimensions[row_idx].height is not None else 0
                            new_row_height = int(excel_plot_img.height / 1.33) + 2 # 1.33 pixel = 1 point
                            ws.row_dimensions[row_idx].height = max(current_row_height, new_row_height)
                            
                            current_col_width = ws.column_dimensions['G'].width if ws.column_dimensions['G'].width is not None else 0
                            new_col_width = int(excel_plot_img.width / 7) + 2 # 7 pixel = 1 unit
                            ws.column_dimensions['G'].width = max(current_col_width, new_col_width)
                            
                            excel_plot_img.anchor = f'G{row_idx}'
                            ws.add_image(excel_plot_img)
                            excel_plot_img2 = ExcelImage(scaled_plot_path)
                            with Image.open(scaled_plot_path) as scaled_pil_plot_img:
                                excel_plot_img2.width = scaled_pil_plot_img.width
                                excel_plot_img2.height = scaled_pil_plot_img.height
                            s_current_row_height = s_ws.row_dimensions[row_idx].height if s_ws.row_dimensions[row_idx].height is not None else 0
                            s_new_row_height = int(excel_plot_img2.height / 1.33) + 2
                            s_ws.row_dimensions[row_idx].height = max(s_current_row_height, s_new_row_height)
                            s_current_col_width = s_ws.column_dimensions['G'].width if s_ws.column_dimensions['G'].width is not None else 0
                            s_new_col_width = int(excel_plot_img2.width / 7) + 2
                            s_ws.column_dimensions['G'].width = max(s_current_col_width, s_new_col_width)
                            excel_plot_img2.anchor = f'G{row_idx}'
                            s_ws.add_image(excel_plot_img2)
                        except Exception as e:
                            self.update_log.emit(f"Error adding plot image to Excel: {e}")
                            cell_col7 = ws.cell(row=row_idx, column=7, value=f"Error: {str(e)}")
                            cell_col7.alignment = Alignment(horizontal='center', vertical='center')
                            cell_col7.fill = current_folder_fill
                            cell_col7.border = thin_border
                    else:
                        cell_col7 = ws.cell(row=row_idx, column=7, value="No plot available")
                        cell_col7.alignment = Alignment(horizontal='center', vertical='center')
                        cell_col7.fill = current_folder_fill
                        cell_col7.border = thin_border
                        s_cell_col7 = s_ws.cell(row=row_idx, column=7, value="No plot available")
                        s_cell_col7.alignment = Alignment(horizontal='center', vertical='center')
                        s_cell_col7.fill = current_folder_fill
                        s_cell_col7.border = thin_border
                    
                    row_idx += 1
        
        # Ensure all processed folders are included in the report
        # Track folders already included (those with CCD in best_images or in folder_notes)
        folders_in_report = set()
        
        # Add folders from best_images (folders with CCD)
        for folder_name in best_images.keys():
            folders_in_report.add(folder_name)
        
        # Add folders from folder_notes
        folder_notes = folder_notes or []
        for note in folder_notes:
            folder = note.get("folder", "-")
            if folder and folder != "-":
                folders_in_report.add(folder)
        
        # Add any missing folders that were processed but not yet in report
        if all_processed_folders:
            missing_folders = all_processed_folders - folders_in_report
            if missing_folders:
                self.update_log.emit(f"Adding {len(missing_folders)} missing folders to report: {', '.join(missing_folders)}")
                for folder_name in missing_folders:
                    folder_notes.append({
                        "folder": folder_name,
                        "ptn": "-",
                        "status": "Processed but no valid data",
                        "details": ""
                    })
        
        if folder_notes:
            note_fill = PatternFill(start_color="FFF2CC", end_color="FFF2CC", fill_type="solid")
            note_font = Font(italic=True)
            for note in folder_notes:
                note_row = row_idx
                folder = note.get("folder", "-")
                ptn = note.get("ptn", "-")
                details = note.get("details", "")
                status = note.get("status", "No CCD detected")

                cell1 = ws.cell(row=note_row, column=1, value=folder)
                cell1.alignment = Alignment(horizontal='center', vertical='center')
                cell1.fill = note_fill
                cell1.border = thin_border
                cell1.font = note_font
                s_cell1 = s_ws.cell(row=note_row, column=1, value=folder)
                s_cell1.alignment = Alignment(horizontal='center', vertical='center')
                s_cell1.fill = note_fill
                s_cell1.border = thin_border
                s_cell1.font = note_font

                cell2 = ws.cell(row=note_row, column=2, value=ptn)
                cell2.alignment = Alignment(horizontal='center', vertical='center')
                cell2.fill = note_fill
                cell2.border = thin_border
                cell2.font = note_font
                s_cell2 = s_ws.cell(row=note_row, column=2, value=ptn)
                s_cell2.alignment = Alignment(horizontal='center', vertical='center')
                s_cell2.fill = note_fill
                s_cell2.border = thin_border
                s_cell2.font = note_font

                cell3 = ws.cell(row=note_row, column=3, value=details)
                cell3.alignment = Alignment(horizontal='center', vertical='center', wrapText=True)
                cell3.fill = note_fill
                cell3.border = thin_border
                cell3.font = note_font
                s_cell3 = s_ws.cell(row=note_row, column=3, value=details)
                s_cell3.alignment = Alignment(horizontal='center', vertical='center', wrapText=True)
                s_cell3.fill = note_fill
                s_cell3.border = thin_border
                s_cell3.font = note_font

                cell4 = ws.cell(row=note_row, column=4, value=status)
                cell4.alignment = Alignment(horizontal='center', vertical='center', wrapText=True)
                cell4.fill = note_fill
                cell4.border = thin_border
                cell4.font = note_font
                s_cell4 = s_ws.cell(row=note_row, column=4, value=status)
                s_cell4.alignment = Alignment(horizontal='center', vertical='center', wrapText=True)
                s_cell4.fill = note_fill
                s_cell4.border = thin_border
                s_cell4.font = note_font
                adjust_status_cells(note_row, status)

                for col_idx in range(5, 8):
                    ws_cell = ws.cell(row=note_row, column=col_idx, value="N/A")
                    ws_cell.alignment = Alignment(horizontal='center', vertical='center')
                    ws_cell.fill = note_fill
                    ws_cell.border = thin_border
                    ws_cell.font = note_font
                    s_cell = s_ws.cell(row=note_row, column=col_idx, value="N/A")
                    s_cell.alignment = Alignment(horizontal='center', vertical='center')
                    s_cell.fill = note_fill
                    s_cell.border = thin_border
                    s_cell.font = note_font

                note_min_height = 45
                for board in (ws, s_ws):
                    current_height = board.row_dimensions[note_row].height if board.row_dimensions[note_row].height is not None else 0
                    if note_min_height > current_height:
                        board.row_dimensions[note_row].height = note_min_height
                row_idx += 1

        # Adjust column widths for text columns (final adjustment)
        ws.column_dimensions['A'].width = 25  # Folder
        ws.column_dimensions['B'].width = 20  # PTN
        ws.column_dimensions['C'].width = 20  # Coordinates
        ws.column_dimensions['D'].width = 15  # Status
        # ws.column_dimensions['G'].width = 15  # Removed Severity Score column
        
        # Save Excel file
        excel_filename = os.path.join(output_folder, "CCD_Analysis_Report.xlsx")
        try:
            wb.save(excel_filename)
            # Save summary workbook simultaneously
            summary_wb.save(summary_path)
            self.update_log.emit(f"Saved Excel report: {excel_filename}")
            try:
                self.update_log.emit(f"Summary updated: {summary_path} -> 'CCD Analysis Report'")
            except Exception:
                pass
        except Exception as e:
            self.update_log.emit(f"Error saving Excel file: {e}")
            # Try saving without images if there's an error
            excel_filename = os.path.join(output_folder, "CCD_Analysis_Report_No_Images.xlsx")
            wb.save(excel_filename)
            self.update_log.emit(f"Saved Excel report without images: {excel_filename}")
        
        # Delete temporary files after saving Excel
        for temp_file in self.temp_files_to_delete:
            if os.path.exists(temp_file):
                os.remove(temp_file)
                self.update_log.emit(f"Deleted temporary file: {temp_file}")
        self.temp_files_to_delete.clear() # Delete the list after deleting the file
        
        # Create a CSV file containing profile details
        if self.all_profile_data:
            csv_file_path = os.path.join(output_folder, "CCD_Profile_Details.csv")
            df = pd.DataFrame(self.all_profile_data)
            
            # Arrange columns for easier readability
            column_order = [
                "Folder", "File Name", "Pattern", "Resolution", "Status",
                "Model", "PTN Color", "Slope Threshold", "Deviation Threshold",
                "Horizontal Errors", "Vertical Errors", "Total Errors",
                "Severity Score", "Max Slope", "Has CCD", "Error Positions"
            ]
            # Only retain the columns present in the DataFrame
            available_columns = [col for col in column_order if col in df.columns]
            df = df[available_columns]
            
            # Sort by Folder and File Name
            df = df.sort_values(by=["Folder", "File Name"])
            
            # Save file CSV
            df.to_csv(csv_file_path, index=False, encoding='utf-8-sig')
            self.update_log.emit(f"Profile details CSV saved: {csv_file_path}")
            self.update_log.emit(f"Total records in CSV: {len(df)}")
        
        return excel_filename, list(folders_with_ccd)
