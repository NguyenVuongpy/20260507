import cv2
import numpy as np
import os
import re
import math
import pandas as pd
from openpyxl import Workbook
from openpyxl.drawing.image import Image as ExcelImage
from openpyxl.utils import get_column_letter
from openpyxl.styles import PatternFill, Font, Border, Side, Alignment
import sys
from PIL import Image 
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QWidget, QPushButton, QLabel,
    QTextEdit, QFileDialog, QProgressBar, QMessageBox, QHBoxLayout,
    QGraphicsDropShadowEffect
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QSize
from PyQt6.QtGui import QFont, QPalette, QColor, QIcon
import rc.icons 
from PyQt6 import QtCore, QtGui, QtWidgets 
import shutil
from openpyxl import load_workbook as _load_wb
try:
    import pythoncom
    import win32com.client as win32
except Exception:
    win32 = None
    pythoncom = None

# Global cache for settings.csv
_SETTINGS_DF = None


def get_script_dir():
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    else:
        return os.path.dirname(os.path.realpath(__file__))

script_dir = get_script_dir()

def _load_settings_df():
    """Load settings.csv once and cache it."""
    global _SETTINGS_DF
    if _SETTINGS_DF is not None:
        return _SETTINGS_DF
    try:
        csv_path = os.path.join(script_dir, "settings.csv")
        if os.path.exists(csv_path):
            import pandas as pd
            _SETTINGS_DF = pd.read_csv(csv_path)
        else:
            _SETTINGS_DF = None
    except Exception:
        _SETTINGS_DF = None
    return _SETTINGS_DF


def local_variance_filter(image, r):
    """
    Calculates local variance with a kernel size of 2*r+1
    """
    kernel_size = 2 * r + 1
    img_float = image.astype(np.float32)

    # Calculate mean
    mean = cv2.blur(img_float, (kernel_size, kernel_size))

    # Calculate mean of squares
    mean_sq = cv2.blur(img_float**2, (kernel_size, kernel_size))

    # Variance = E[X^2] - (E[X])^2
    variance = mean_sq - mean**2
    return variance


def create_rounded_rectangle_mask(img_shape, corner_radius=280, border_skip=70):
    """
    Create mask for rounded rectangle shape
    Keeps only pixels that are inside the rounded rectangle area
    Excludes the 4 rounded corners (pixels outside the corner circles)
    
    Args:
        img_shape: (height, width) of the image
        corner_radius: radius of the rounded corner in pixels
        border_skip: number of pixels to skip at the edges
    
    Returns:
        mask: binary mask (1 for regions to keep, 0 for regions to exclude)
    """
    h, w = img_shape[:2]
    
    # Initialize mask with zeros (exclude all by default)
    mask = np.zeros((h, w), dtype=np.uint8)
    
    # Define the main rectangle area (including corner areas)
    rect_top = border_skip
    rect_bottom = h - border_skip
    rect_left = border_skip
    rect_right = w - border_skip
    
    # First, keep the entire rectangle area from border_skip to edges
    # This includes the corners which will be filtered later
    mask[rect_top:rect_bottom, rect_left:rect_right] = 1
    
    # Define the corner circle centers
    # Top-left corner: center at (rect_left + corner_radius, rect_top + corner_radius)
    tl_center_x = rect_left + corner_radius
    tl_center_y = rect_top + corner_radius
    
    # Top-right corner: center at (rect_right - corner_radius, rect_top + corner_radius)
    tr_center_x = rect_right - corner_radius
    tr_center_y = rect_top + corner_radius
    
    # Bottom-left corner: center at (rect_left + corner_radius, rect_bottom - corner_radius)
    bl_center_x = rect_left + corner_radius
    bl_center_y = rect_bottom - corner_radius
    
    # Bottom-right corner: center at (rect_right - corner_radius, rect_bottom - corner_radius)
    br_center_x = rect_right - corner_radius
    br_center_y = rect_bottom - corner_radius
    
    # Create coordinate grids for corner regions only (for efficiency)
    # Top-left corner region
    tl_x_start = rect_left
    tl_x_end = min(rect_left + corner_radius, rect_right)
    tl_y_start = rect_top
    tl_y_end = min(rect_top + corner_radius, rect_bottom)
    
    if tl_x_end > tl_x_start and tl_y_end > tl_y_start:
        y_coords, x_coords = np.ogrid[tl_y_start:tl_y_end, tl_x_start:tl_x_end]
        dist = np.sqrt((x_coords - tl_center_x)**2 + (y_coords - tl_center_y)**2)
        # Exclude points outside the corner circle (distance > corner_radius)
        outside_circle = dist > corner_radius
        mask[tl_y_start:tl_y_end, tl_x_start:tl_x_end][outside_circle] = 0
    
    # Top-right corner region
    tr_x_start = max(rect_right - corner_radius, rect_left)
    tr_x_end = rect_right
    tr_y_start = rect_top
    tr_y_end = min(rect_top + corner_radius, rect_bottom)
    
    if tr_x_end > tr_x_start and tr_y_end > tr_y_start:
        y_coords, x_coords = np.ogrid[tr_y_start:tr_y_end, tr_x_start:tr_x_end]
        dist = np.sqrt((x_coords - tr_center_x)**2 + (y_coords - tr_center_y)**2)
        outside_circle = dist > corner_radius
        mask[tr_y_start:tr_y_end, tr_x_start:tr_x_end][outside_circle] = 0
    
    # Bottom-left corner region
    bl_x_start = rect_left
    bl_x_end = min(rect_left + corner_radius, rect_right)
    bl_y_start = max(rect_bottom - corner_radius, rect_top)
    bl_y_end = rect_bottom
    
    if bl_x_end > bl_x_start and bl_y_end > bl_y_start:
        y_coords, x_coords = np.ogrid[bl_y_start:bl_y_end, bl_x_start:bl_x_end]
        dist = np.sqrt((x_coords - bl_center_x)**2 + (y_coords - bl_center_y)**2)
        outside_circle = dist > corner_radius
        mask[bl_y_start:bl_y_end, bl_x_start:bl_x_end][outside_circle] = 0
    
    # Bottom-right corner region
    br_x_start = max(rect_right - corner_radius, rect_left)
    br_x_end = rect_right
    br_y_start = max(rect_bottom - corner_radius, rect_top)
    br_y_end = rect_bottom
    
    if br_x_end > br_x_start and br_y_end > br_y_start:
        y_coords, x_coords = np.ogrid[br_y_start:br_y_end, br_x_start:br_x_end]
        dist = np.sqrt((x_coords - br_center_x)**2 + (y_coords - br_center_y)**2)
        outside_circle = dist > corner_radius
        mask[br_y_start:br_y_end, br_x_start:br_x_end][outside_circle] = 0
    
    return mask


def _get_bubble_type_and_patterns(img_width, img_height, file_name):
    """
    Determine which bubble type (Bubble1 or Bubble2) this file belongs to
    Returns (bubble_type, pattern) or (None, None)
    """
    df = _load_settings_df()
    if df is None:
        return None, None
    
    candidates = df
    resolution_key = f"{img_width};{img_height}"
    if "Display_Resolution" in candidates.columns:
        res_series = candidates["Display_Resolution"].astype(str)
        mask_res = res_series == resolution_key
        if mask_res.any():
            candidates = candidates[mask_res]
        else:
            return None, None
    
    fname = str(file_name)
    
    # Check for Bubble1 patterns
    if "Bubble1_PTN_Check" in candidates.columns:
        for _, row in candidates.iterrows():
            ptn_str = str(row.get("Bubble1_PTN_Check", ""))
            if ptn_str and ptn_str != "nan":
                patterns = [p.strip() for p in ptn_str.split(";") if p.strip()]
                for pattern in patterns:
                    if pattern in fname:
                        return "Bubble1", pattern
    
    # Check for Bubble2 patterns
    if "Bubble2_PTN_Check" in candidates.columns:
        for _, row in candidates.iterrows():
            ptn_str = str(row.get("Bubble2_PTN_Check", ""))
            if ptn_str and ptn_str != "nan":
                patterns = [p.strip() for p in ptn_str.split(";") if p.strip()]
                for pattern in patterns:
                    if pattern in fname:
                        return "Bubble2", pattern
    
    return None, None


def _get_region_params(img_width, img_height, bubble_type, region):
    """
    Get parameters for a specific region
    region: 'left', 'hiaa', 'center', 'right'
    Returns dict with sigma, r, threshold, pos_range, and optional hiaa_circle
    """
    df = _load_settings_df()
    if df is None:
        return {}
    
    resolution_key = f"{img_width};{img_height}"
    candidates = df
    
    if "Display_Resolution" in candidates.columns:
        res_series = candidates["Display_Resolution"].astype(str)
        mask_res = res_series == resolution_key
        if mask_res.any():
            candidates = candidates[mask_res]
        else:
            return {}
    
    if candidates.empty:
        return {}
    
    row = candidates.iloc[0]
    
    # Define column names for each region and bubble type
    region_columns = {
        "left": f"{bubble_type}_Left_Para_(sigma,r,th,pos)",
        "hiaa": f"{bubble_type}_Hiaa_Para_(sigma,r,th,pos)",
        "center": f"{bubble_type}_Center_Para_(sigma,r,th,pos)",
        "right": f"{bubble_type}_Right_Para_(sigma,r,th,pos)"
    }
    
    param_col = region_columns.get(region)
    if not param_col or param_col not in row:
        return {}
    
    param_str = str(row[param_col])
    if param_str == "nan" or not param_str:
        return {}
    
    # Parse parameters: sigma;r;threshold;pos_range
    parts = param_str.split(";")
    if len(parts) < 4:
        return {}
    
    try:
        sigma = float(parts[0])
        r = int(round(float(parts[1])))
        threshold_scale = float(parts[2])
        pos_range_str = parts[3].strip()
        
        # Parse position range
        if "-" in pos_range_str:
            start_pos, end_pos = pos_range_str.split("-")
            start_pos = int(start_pos)
            end_pos = int(end_pos)
        else:
            start_pos = int(pos_range_str)
            end_pos = None
        
        params = {
            "sigma": sigma,
            "r": r,
            "threshold_scale": threshold_scale,
            "start_pos": start_pos,
            "end_pos": end_pos
        }
        
        # Get hiaa circle parameters if region is hiaa
        if region == "hiaa":
            hiaa_circle_col = f"{bubble_type}_Hiaa_Udir"
            if hiaa_circle_col in row and str(row[hiaa_circle_col]) != "nan":
                circle_str = str(row[hiaa_circle_col])
                circle_parts = circle_str.split(";")
                if len(circle_parts) == 3:
                    params["hiaa_circle"] = {
                        "x": int(circle_parts[0]),
                        "y": int(circle_parts[1]),
                        "radius": int(circle_parts[2])
                    }
        
        return params
    except Exception:
        return {}


def _get_hole_params(img_width, img_height, bubble_type):
    """
    Get hole rectangle parameters for hiaa region
    Returns list of rectangle coordinates: [(x1, y1, x2, y2), ...]
    """
    df = _load_settings_df()
    if df is None:
        return []
    
    resolution_key = f"{img_width};{img_height}"
    candidates = df
    
    if "Display_Resolution" in candidates.columns:
        res_series = candidates["Display_Resolution"].astype(str)
        mask_res = res_series == resolution_key
        if mask_res.any():
            candidates = candidates[mask_res]
        else:
            return []
    
    if candidates.empty:
        return []
    
    row = candidates.iloc[0]
    
    # Determine which column to use based on bubble type
    hole_col = f"{bubble_type}_Hiaa_Hole"
    if hole_col not in row or str(row[hole_col]) == "nan" or not row[hole_col]:
        return []
    
    hole_str = str(row[hole_col])
    holes = []
    
    # Parse format: "x1;y1-x2;y2" for single rectangle
    # Or multiple rectangles separated by space
    hole_parts = hole_str.split()
    for part in hole_parts:
        if "-" in part:
            # Format: "x1;y1-x2;y2"
            try:
                start_end = part.split("-")
                if len(start_end) == 2:
                    start_part = start_end[0]
                    end_part = start_end[1]
                    
                    if ";" in start_part and ";" in end_part:
                        x1, y1 = map(int, start_part.split(";"))
                        x2, y2 = map(int, end_part.split(";"))
                        holes.append((x1, y1, x2, y2))
            except Exception:
                continue
    
    return holes


def _apply_circular_mask(mask, circle_params, img_shape):
    """
    Apply circular mask to exclude area from detection
    """
    h, w = img_shape[:2]
    if not circle_params:
        return mask
    
    center_x = circle_params["x"]
    center_y = circle_params["y"]
    radius = circle_params["radius"]
    
    # Create a circular mask
    Y, X = np.ogrid[:h, :w]
    dist_from_center = np.sqrt((X - center_x)**2 + (Y - center_y)**2)
    circle_mask = dist_from_center <= radius
    
    # Set the circular area to 0 (exclude from detection)
    if mask.dtype == np.uint8:
        mask[circle_mask] = 0
    else:
        mask[circle_mask] = 0
    
    return mask


def _apply_hole_mask(mask, hole_params, roi_offset_x=0, roi_offset_y=0):
    """
    Apply hole mask to exclude rectangle areas from detection
    hole_params: list of (x1, y1, x2, y2) rectangles in original image coordinates
    roi_offset_x, roi_offset_y: offset of ROI within original image
    """
    if not hole_params:
        return mask
    
    for (x1, y1, x2, y2) in hole_params:
        # Adjust coordinates to ROI if needed
        adj_x1 = max(0, x1 - roi_offset_x)
        adj_y1 = max(0, y1 - roi_offset_y)
        adj_x2 = min(mask.shape[1], x2 - roi_offset_x)
        adj_y2 = min(mask.shape[0], y2 - roi_offset_y)
        
        if adj_x2 > adj_x1 and adj_y2 > adj_y1:
            # Set rectangle area to 0 (exclude from detection)
            mask[adj_y1:adj_y2, adj_x1:adj_x2] = 0
    
    return mask


def detect_bubbles_in_region(image_path, region_params, img_roi, roi_offset_x=0, roi_offset_y=0, 
                            circle_params=None, hole_params=None, apply_corner_mask=False, 
                            corner_radius=280, border_skip=70):
    """
    Detect bubbles in a specific region
    """
    # read image
    img = cv2.imread(image_path, cv2.IMREAD_UNCHANGED | cv2.IMREAD_ANYDEPTH)
    
    if img is None:
        raise ValueError(f"Cannot read image: {image_path}")
    
    # Convert to grayscale if needed
    if len(img.shape) == 3:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # Extract region of interest
    roi = img[roi_offset_y:roi_offset_y+img_roi.shape[0], roi_offset_x:roi_offset_x+img_roi.shape[1]]
    
    # Apply Gaussian blur
    sigma = region_params.get("sigma")
    if sigma is None:
        raise ValueError("Missing sigma parameter for region")
    
    kernel_size = int(2 * np.ceil(2 * sigma) + 1)
    roi_blurred = cv2.GaussianBlur(roi, (kernel_size, kernel_size), sigma)
    
    # Apply variance filter
    r = region_params.get("r")
    if r is None:
        raise ValueError("Missing r parameter for region")
    
    var_img = local_variance_filter(roi_blurred, r=r)
    
    # Automatic threshold based on mean
    threshold_scale = region_params.get("threshold_scale")
    if threshold_scale is None:
        raise ValueError("Missing threshold_scale parameter for region")
    
    thresh_val = np.mean(var_img) * threshold_scale
    
    # Binary mask
    _, mask = cv2.threshold(var_img, thresh_val, 65535, cv2.THRESH_BINARY)
    
    # Convert to uint8 for morphology
    mask_uint8 = mask.astype(np.uint8)
    
    # Morphology to remove noise
    mask_uint8 = cv2.morphologyEx(mask_uint8, cv2.MORPH_OPEN, np.ones((5,5), np.uint8))
    
    # Apply circular mask if provided (for hiaa region)
    if circle_params:
        mask_uint8 = _apply_circular_mask(mask_uint8, circle_params, roi.shape)
    
    # Apply hole mask if provided (for hiaa region)
    if hole_params:
        mask_uint8 = _apply_hole_mask(mask_uint8, hole_params, roi_offset_x, roi_offset_y)
    
    # Apply rounded rectangle corner mask - exclude pixels outside the corner circles
    if apply_corner_mask:
        # Create rounded rectangle mask for the full image
        full_rounded_mask = create_rounded_rectangle_mask(img.shape, corner_radius, border_skip)
        
        # Crop mask to ROI
        roi_rounded_mask = full_rounded_mask[roi_offset_y:roi_offset_y+img_roi.shape[0], 
                                            roi_offset_x:roi_offset_x+img_roi.shape[1]]
        
        # Apply mask: only keep pixels where roi_rounded_mask is 1
        mask_uint8 = mask_uint8 * roi_rounded_mask
    
    # Find contours
    result = cv2.findContours(mask_uint8, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    # Supports both OpenCV 3.x and 4.x
    if len(result) == 3:
        # OpenCV 3.x: (image, contours, hierarchy)
        _, contours, _ = result
    elif len(result) == 2:
        # OpenCV 4.x: (contours, hierarchy)
        contours, _ = result
    else:
        contours = result[0] if result else []
    
    # Adjust contours coordinates to original image
    adjusted_contours = []
    for cnt in contours:
        adjusted_cnt = cnt + np.array([roi_offset_x, roi_offset_y])
        adjusted_contours.append(adjusted_cnt)
    
    return adjusted_contours, mask_uint8, var_img


def detect_bubbles(image_path, file_name=None, img_width=None, img_height=None):
    """
    Main bubble detection function that processes different regions
    """
    # Determine bubble type
    bubble_type, pattern = _get_bubble_type_and_patterns(img_width, img_height, file_name)
    if bubble_type is None:
        return None, None, None, pattern, None, None, None
    
    # Read image
    img = cv2.imread(image_path, cv2.IMREAD_UNCHANGED | cv2.IMREAD_ANYDEPTH)
    if img is None:
        raise ValueError(f"Cannot read image: {image_path}")
    
    if len(img.shape) == 3:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    h, w = img.shape
    
    # Define border to skip (60 pixels on all sides)
    border_skip = 70
    corner_radius = 280  # Corner radius in pixels - adjust based on actual corner curvature
    
    # Define region boundaries after skipping border
    left_boundary = border_skip
    right_boundary = w - border_skip
    top_boundary = border_skip
    bottom_boundary = h - border_skip
    
    # Initialize combined results
    all_contours = []
    combined_mask = np.zeros((h, w), dtype=np.uint8)
    combined_var_img = np.zeros((h, w), dtype=np.float32)
    
    # Process each region
    regions = ['left', 'hiaa', 'center', 'right']
    region_params_dict = {}
    
    for region in regions:
        params = _get_region_params(w, h, bubble_type, region)
        if params:
            region_params_dict[region] = params
    
    # Determine which regions need corner mask application
    # Apply to all regions that might extend to corners
    corner_mask_regions = ['left', 'right', 'center', 'hiaa']
    
    # Process left region
    if 'left' in region_params_dict:
        params = region_params_dict['left']
        start_x = left_boundary
        end_x = min(params['start_pos'], right_boundary)
        roi_width = end_x - start_x
        roi_height = bottom_boundary - top_boundary
        
        if roi_width > 0 and roi_height > 0:
            roi = img[top_boundary:bottom_boundary, start_x:end_x]
            apply_corner = 'left' in corner_mask_regions
            contours, mask, var_img = detect_bubbles_in_region(
                image_path, params, roi, start_x, top_boundary,
                apply_corner_mask=apply_corner, corner_radius=corner_radius, border_skip=border_skip
            )
            all_contours.extend(contours)
            combined_mask[top_boundary:bottom_boundary, start_x:end_x] = np.maximum(
                combined_mask[top_boundary:bottom_boundary, start_x:end_x], mask
            )
            combined_var_img[top_boundary:bottom_boundary, start_x:end_x] = np.maximum(
                combined_var_img[top_boundary:bottom_boundary, start_x:end_x], var_img
            )
    
    # Process right region
    if 'right' in region_params_dict:
        params = region_params_dict['right']
        start_x = max(params['start_pos'], left_boundary)
        end_x = right_boundary
        roi_width = end_x - start_x
        roi_height = bottom_boundary - top_boundary
        
        if roi_width > 0 and roi_height > 0:
            roi = img[top_boundary:bottom_boundary, start_x:end_x]
            apply_corner = 'right' in corner_mask_regions
            contours, mask, var_img = detect_bubbles_in_region(
                image_path, params, roi, start_x, top_boundary,
                apply_corner_mask=apply_corner, corner_radius=corner_radius, border_skip=border_skip
            )
            all_contours.extend(contours)
            combined_mask[top_boundary:bottom_boundary, start_x:end_x] = np.maximum(
                combined_mask[top_boundary:bottom_boundary, start_x:end_x], mask
            )
            combined_var_img[top_boundary:bottom_boundary, start_x:end_x] = np.maximum(
                combined_var_img[top_boundary:bottom_boundary, start_x:end_x], var_img
            )
    
    # Process center region
    if 'center' in region_params_dict:
        params = region_params_dict['center']
        start_x = max(params['start_pos'], left_boundary)
        end_x = min(params['end_pos'] if params['end_pos'] else right_boundary, right_boundary)
        roi_width = end_x - start_x
        roi_height = bottom_boundary - top_boundary
        
        if roi_width > 0 and roi_height > 0:
            roi = img[top_boundary:bottom_boundary, start_x:end_x]
            # Center region also needs corner mask to exclude rounded corners
            apply_corner = 'center' in corner_mask_regions
            contours, mask, var_img = detect_bubbles_in_region(
                image_path, params, roi, start_x, top_boundary,
                apply_corner_mask=apply_corner, corner_radius=corner_radius, border_skip=border_skip
            )
            all_contours.extend(contours)
            combined_mask[top_boundary:bottom_boundary, start_x:end_x] = np.maximum(
                combined_mask[top_boundary:bottom_boundary, start_x:end_x], mask
            )
            combined_var_img[top_boundary:bottom_boundary, start_x:end_x] = np.maximum(
                combined_var_img[top_boundary:bottom_boundary, start_x:end_x], var_img
            )
    
    # Process hiaa region
    if 'hiaa' in region_params_dict:
        params = region_params_dict['hiaa']
        start_x = max(params['start_pos'], left_boundary)
        end_x = min(params['end_pos'] if params['end_pos'] else right_boundary, right_boundary)
        roi_width = end_x - start_x
        roi_height = bottom_boundary - top_boundary
        
        if roi_width > 0 and roi_height > 0:
            roi = img[top_boundary:bottom_boundary, start_x:end_x]
            circle_params = params.get('hiaa_circle')
            # Adjust circle coordinates relative to ROI
            if circle_params:
                circle_params_adjusted = {
                    'x': circle_params['x'] - start_x,
                    'y': circle_params['y'] - top_boundary,
                    'radius': circle_params['radius']
                }
            else:
                circle_params_adjusted = None
            
            # Get hole parameters for hiaa region
            hole_params = _get_hole_params(w, h, bubble_type)
            
            # Hiaa region also needs corner mask to exclude rounded corners
            apply_corner = 'hiaa' in corner_mask_regions
            contours, mask, var_img = detect_bubbles_in_region(
                image_path, params, roi, start_x, top_boundary, 
                circle_params_adjusted, hole_params,
                apply_corner_mask=apply_corner, corner_radius=corner_radius, border_skip=border_skip
            )
            all_contours.extend(contours)
            combined_mask[top_boundary:bottom_boundary, start_x:end_x] = np.maximum(
                combined_mask[top_boundary:bottom_boundary, start_x:end_x], mask
            )
            combined_var_img[top_boundary:bottom_boundary, start_x:end_x] = np.maximum(
                combined_var_img[top_boundary:bottom_boundary, start_x:end_x], var_img
            )
    
    # Draw results
    result_img = cv2.normalize(img, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    result_img = cv2.cvtColor(result_img, cv2.COLOR_GRAY2BGR)
    
    for cnt in all_contours:
        x, y, w_cnt, h_cnt = cv2.boundingRect(cnt)
        cv2.rectangle(result_img, (x, y), (x + w_cnt, y + h_cnt), (0, 0, 255), 2)
    
    # Calculate statistics for the entire image
    max_variance = np.max(combined_var_img) if combined_var_img.size > 0 else 0
    mean_variance = np.mean(combined_var_img) if combined_var_img.size > 0 else 0
    
    # Get parameters used for detection
    params_used = {}
    if region_params_dict:
        # Use first region's params as reference
        first_region = next(iter(region_params_dict.values()))
        params_used = {
            "r": first_region.get("r", 0),
            "threshold_scale": first_region.get("threshold_scale", 0),
            "sigma": first_region.get("sigma", 0)
        }
    
    return result_img, combined_mask, all_contours, pattern, params_used, max_variance, mean_variance


def extract_pattern(file_name, img_width=None, img_height=None):
    """Returns the Bubble pattern if the filename contains it; otherwise, None."""
    if img_width is None or img_height is None:
        return None
    _, pattern = _get_bubble_type_and_patterns(img_width, img_height, file_name)
    return pattern


def are_centers_close(bbox1, bbox2, tolerance=10):
    x1, y1, w1, h1 = bbox1
    x2, y2, w2, h2 = bbox2

    center_x1 = x1 + w1 / 2
    center_y1 = y1 + h1 / 2
    center_x2 = x2 + w2 / 2
    center_y2 = y2 + h2 / 2

    # Calculate Euclidean distance between centers
    distance = np.sqrt((center_x1 - center_x2)**2 + (center_y1 - center_y2)**2)

    # Check for bounding box overlap
    left1, top1, right1, bottom1 = x1, y1, x1 + w1, y1 + h1
    left2, top2, right2, bottom2 = x2, y2, x2 + w2, y2 + h2

    # Check for overlap
    overlap_x = max(0, min(right1, right2) - max(left1, left2))
    overlap_y = max(0, min(bottom1, bottom2) - max(top1, top2))
    has_overlap = (overlap_x > 0 and overlap_y > 0)

    # Return True if centers are close enough OR there is significant overlap
    return distance <= tolerance or has_overlap


def check_for_common_bubbles(bubble_checker_thread, folder_path, file_names_in_group, pattern, 
                             mask_images_dir, mark_bubbles_dir, crop_bubbles_dir):
    all_bubble_data = []
    base_folder_name = os.path.basename(folder_path)
    profile_data_list = []

    if not file_names_in_group:
        bubble_checker_thread.update_log.emit(f"Warning: No files in group for pattern {pattern}")
        return False, None, profile_data_list

    for file_name in file_names_in_group:
        file_path = os.path.join(folder_path, file_name)

        # Get image dimensions
        img = cv2.imread(file_path, cv2.IMREAD_UNCHANGED | cv2.IMREAD_ANYDEPTH)
        if img is None:
            bubble_checker_thread.update_log.emit(f"Warning: Cannot read image {file_name}")
            continue

        if len(img.shape) == 3:
            img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        img_height, img_width = img.shape[:2]
        
        # Detect bubbles using region-based approach
        result_img, mask, contours, detected_pattern, params_used, max_variance, mean_variance = detect_bubbles(
            file_path, file_name, img_width, img_height
        )
        
        if result_img is None:
            bubble_checker_thread.update_log.emit(f"Skip {file_name}: no valid bubble detection parameters found")
            continue
        
        # Save mask image
        mask_img_path = os.path.join(mask_images_dir, f"{base_folder_name}_{file_name.replace('.tif', '_mask.png')}")
        cv2.imwrite(mask_img_path, mask)
        
        bboxes = [cv2.boundingRect(cnt) for cnt in contours]
        
        # Calculate statistics
        num_defects = len(bboxes)
        
        # Format defect positions (bounding boxes) for CSV
        defect_positions = ""
        if bboxes:
            # Format as: (x,y,w,h); (x,y,w,h); ...
            bbox_strings = []
            for bbox in bboxes:
                x, y, w, h = bbox
                bbox_strings.append(f"({x},{y},{w},{h})")
            defect_positions = "; ".join(bbox_strings)
        
        # Calculate threshold used
        threshold_used = 0
        if params_used.get("threshold_scale") and hasattr(img, 'shape'):
            # Estimate threshold used (this is an approximation)
            threshold_used = np.mean(img) * params_used.get("threshold_scale", 0) if img.size > 0 else 0
        
        # Save profile information for CSV
        profile_data_list.append({
            "Folder": base_folder_name,
            "File Name": file_name,
            "Pattern": pattern if pattern else "Unknown",
            "Resolution": f"{img_width}x{img_height}",
            "Status": "Bubble Found" if num_defects > 0 else "OK",
            "R Parameter": params_used.get("r", 0),
            "Threshold Scale": params_used.get("threshold_scale", 0),
            "Threshold Used": threshold_used,
            "Number of Defects": num_defects,
            "Max Variance": max_variance,
            "Mean Variance": mean_variance,
            "Defect Positions": defect_positions
        })
        
        # Store original image for cropping later
        original_img = cv2.imread(file_path, cv2.IMREAD_UNCHANGED | cv2.IMREAD_ANYDEPTH)
        if original_img is not None:
            original_img_norm = cv2.normalize(original_img, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
            if len(original_img_norm.shape) == 3:
                original_img_norm = cv2.cvtColor(original_img_norm, cv2.COLOR_BGR2GRAY)
        else:
            original_img_norm = np.zeros((100, 100), dtype=np.uint8)

        all_bubble_data.append({
            "file_name": file_name,
            "original_img": original_img_norm,
            "result_img": result_img,
            "mask_img": mask,
            "bboxes": bboxes,
            "max_variance": max_variance,
            "mean_variance": mean_variance
        })

    if len(all_bubble_data) < 3:
        return False, None, profile_data_list

    common_bubbles_found_instances = []
    processed_bbox1_indices = set()

    # Search for common bubbles
    for i, data1 in enumerate(all_bubble_data):
        for bbox1_idx, bbox1 in enumerate(data1["bboxes"]):
            bbox1_key = (i, bbox1_idx, bbox1[0], bbox1[1], bbox1[2], bbox1[3])
            if bbox1_key in processed_bbox1_indices:
                continue

            common_bubble_count = 1
            matching_images_data = [data1]
            candidate_common_bboxes = [bbox1]
            matched_bbox2_keys = set()

            for j, data2 in enumerate(all_bubble_data):
                if i == j:
                    continue
                for bbox2_idx, bbox2 in enumerate(data2["bboxes"]):
                    bbox2_key = (j, bbox2_idx, bbox2[0], bbox2[1], bbox2[2], bbox2[3])
                    
                    if are_centers_close(bbox1, bbox2, tolerance=10):
                        common_bubble_count += 1
                        matching_images_data.append(data2)
                        candidate_common_bboxes.append(bbox2)
                        processed_bbox1_indices.add(bbox1_key)
                        matched_bbox2_keys.add(bbox2_key)
                        break
            
            if common_bubble_count >= 3:
                processed_bbox1_indices.update(matched_bbox2_keys)

                # Calculate common center
                all_centers_x_current_cluster = [b[0] + b[2] / 2 for b in candidate_common_bboxes]
                all_centers_y_current_cluster = [b[1] + b[3] / 2 for b in candidate_common_bboxes]

                avg_center_x_current_cluster = int(np.mean(all_centers_x_current_cluster))
                avg_center_y_current_cluster = int(np.mean(all_centers_y_current_cluster))

                # Define bounding box for this common bubble instance
                x_common_instance = max(0, avg_center_x_current_cluster - 100)
                y_common_instance = max(0, avg_center_y_current_cluster - 100)
                w_common_instance = 200
                h_common_instance = 200

                # Determine the sharpest image based on mask area
                best_img_idx_for_instance = None
                best_mask_area_for_instance = -1
                for j, data2 in enumerate(all_bubble_data):
                    mask_img_j = data2["mask_img"]
                    for bbox2 in data2["bboxes"]:
                        if are_centers_close(bbox1, bbox2, tolerance=10):
                            x2, y2, w2, h2 = bbox2
                            sub_mask = mask_img_j[y2:y2+h2, x2:x2+w2]
                            mask_area = int(np.count_nonzero(sub_mask))
                            if mask_area > best_mask_area_for_instance:
                                best_mask_area_for_instance = mask_area
                                best_img_idx_for_instance = j

                common_bubbles_found_instances.append({
                    "bbox": (x_common_instance, y_common_instance, w_common_instance, h_common_instance),
                    "center": (avg_center_x_current_cluster, avg_center_y_current_cluster),
                    "best_img_idx": best_img_idx_for_instance,
                    "best_mask_area": best_mask_area_for_instance
                })

    # Merge nearby bubbles
    final_aggregated_common_bubbles = []
    merge_tolerance = 10

    for instance in common_bubbles_found_instances:
        current_bbox = instance["bbox"]
        merged = False
        for i, merged_bbox in enumerate(final_aggregated_common_bubbles):
            if are_centers_close(current_bbox, merged_bbox, tolerance=merge_tolerance):
                mx1, my1, mw1, mh1 = merged_bbox
                ix1, iy1, iw1, ih1 = current_bbox

                new_x1 = min(mx1, ix1)
                new_y1 = min(my1, iy1)
                new_x2 = max(mx1 + mw1, ix1 + iw1)
                new_y2 = max(my1 + mh1, iy1 + ih1)

                final_aggregated_common_bubbles[i] = (new_x1, new_y1, new_x2 - new_x1, new_y2 - new_y1)
                merged = True
                break
        if not merged:
            final_aggregated_common_bubbles.append(current_bbox)

    if final_aggregated_common_bubbles:
        # Select base image
        selected_img_idx = 0
        selected_area = -1
        for instance in common_bubbles_found_instances:
            if instance.get("best_mask_area", -1) > selected_area and instance.get("best_img_idx") is not None:
                selected_area = instance["best_mask_area"]
                selected_img_idx = instance["best_img_idx"]

        base_original_img = all_bubble_data[selected_img_idx]["original_img"]
        img_height, img_width = base_original_img.shape[:2]

        # Create result image marking all common bubbles
        result_with_all_common_bubbles = cv2.cvtColor(base_original_img, cv2.COLOR_GRAY2BGR)
        
        for idx, (x, y, w, h) in enumerate(final_aggregated_common_bubbles):
            cv2.rectangle(result_with_all_common_bubbles, (x, y), (x + w, y + h), (0, 0, 255), 2)
            text = str(idx + 1)
            font = cv2.FONT_HERSHEY_SIMPLEX
            font_scale = 1
            font_thickness = 2
            text_size = cv2.getTextSize(text, font, font_scale, font_thickness)[0]
            text_x = max(0, x - 5 - text_size[0])
            text_y = max(text_size[1], y - 5)
            cv2.putText(result_with_all_common_bubbles, text, (text_x, text_y), font, font_scale, (0, 0, 255), font_thickness, cv2.LINE_AA)

        # Save aggregated result image
        aggregated_result_img_path = os.path.join(mark_bubbles_dir, f"{base_folder_name}_{pattern}_all_common_bubbles_result.png")
        cv2.imwrite(aggregated_result_img_path, result_with_all_common_bubbles)

        # Create individual cropped images
        individual_cropped_image_paths = []
        for idx, (x, y, w, h) in enumerate(final_aggregated_common_bubbles):
            padding_individual_crop = 100
            center_x = x + w // 2
            center_y = y + h // 2

            crop_x_start = max(0, center_x - padding_individual_crop)
            crop_y_start = max(0, center_y - padding_individual_crop)
            crop_x_end = min(img_width, center_x + padding_individual_crop)
            crop_y_end = min(img_height, center_y + padding_individual_crop)

            cropped_individual_img = base_original_img[crop_y_start:crop_y_end, crop_x_start:crop_x_end]
            
            individual_cropped_img_path = os.path.join(crop_bubbles_dir, f"{base_folder_name}_{pattern}_common_bubble_{idx+1}_cropped.png")
            cv2.imwrite(individual_cropped_img_path, cropped_individual_img)
            individual_cropped_image_paths.append(individual_cropped_img_path)

        bubble_checker_thread.update_log.emit(f"Found {len(final_aggregated_common_bubbles)} aggregated common bubbles for pattern {pattern} in folder {os.path.basename(folder_path)}")
        
        report_entries = []
        for cropped_path in individual_cropped_image_paths:
            report_entries.append({
                "result_img_path": aggregated_result_img_path,
                "cropped_img_path": cropped_path,
            })
        return True, report_entries, profile_data_list
    else:
        return False, None, profile_data_list


def generate_excel_report(bubble_checker_thread, output_dir, reports, all_profile_data):
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Bubble Report"
    
    output_base = bubble_checker_thread.summary_output_folder if hasattr(bubble_checker_thread, 'summary_output_folder') and bubble_checker_thread.summary_output_folder else os.path.dirname(output_dir)
    summary_path = os.path.join(output_base, "Analysis_Report.xlsx")
    if os.path.exists(summary_path):
        summary_wb = _load_wb(summary_path)
    else:
        summary_wb = Workbook()
        summary_wb.active.title = "Summary"
    if "Bubble Report" in summary_wb.sheetnames:
        summary_ws = summary_wb["Bubble Report"]
        summary_wb.remove(summary_ws)
        summary_ws = summary_wb.create_sheet("Bubble Report")
    else:
        summary_ws = summary_wb.create_sheet("Bubble Report")

    max_cropped_images = 0
    for report_entry in reports:
        if "Cropped_Images" in report_entry and report_entry["Cropped_Images"] is not None:
            max_cropped_images = max(max_cropped_images, len(report_entry["Cropped_Images"]))

    headers = ["Folder", "PTN", "Status", "Original Image with Mark"]
    for i in range(max_cropped_images):
        headers.append(f"Cropped Image {i+1}")
    sheet.append(headers)
    summary_ws.append(headers)

    header_fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
    header_font = Font(bold=True)
    border_style = Border(left=Side(style="thin"), right=Side(style="thin"), top=Side(style="thin"), bottom=Side(style="thin"))

    for col in range(1, len(headers) + 1):
        cell = sheet.cell(row=1, column=col)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = border_style
        scell = summary_ws.cell(row=1, column=col)
        scell.fill = header_fill
        scell.font = header_font
        scell.alignment = Alignment(horizontal="center", vertical="center")
        scell.border = border_style

    sheet.column_dimensions['A'].width = 25
    sheet.column_dimensions['B'].width = 20
    sheet.column_dimensions['C'].width = 20
    sheet.column_dimensions['D'].width = 45
    summary_ws.column_dimensions['A'].width = 25
    summary_ws.column_dimensions['B'].width = 20
    summary_ws.column_dimensions['C'].width = 20
    summary_ws.column_dimensions['D'].width = 45

    scale_factor = 0.25
    colors = ["D9EAD3", "C9DAF8"]
    current_color_index = 0
    prev_folder = None

    def calc_status_height(text):
        clean_text = (text or "").strip()
        if not clean_text:
            return 20
        approx_chars_per_line = 28
        lines = max(1, math.ceil(len(clean_text) / approx_chars_per_line))
        return lines * 18 + 4

    def adjust_status_cells(main_row, summary_row, status_text):
        desired_height = calc_status_height(status_text)
        for target_ws, row in ((sheet, main_row), (summary_ws, summary_row)):
            cell = target_ws.cell(row=row, column=3)
            cell.alignment = Alignment(horizontal="center", vertical="center", wrapText=True)
            current_height = target_ws.row_dimensions[row].height if target_ws.row_dimensions[row].height is not None else 0
            if desired_height > current_height:
                target_ws.row_dimensions[row].height = desired_height

    reports_with_errors = []
    reports_without_errors = []
    
    for report_entry in reports:
        status = report_entry.get("Status", "")
        if status == "Bubble Found":
            reports_with_errors.append(report_entry)
        else:
            reports_without_errors.append(report_entry)
    
    sorted_reports = reports_with_errors + reports_without_errors
    
    for row_idx, report_entry in enumerate(sorted_reports, start=2):
        folder = report_entry.get("Folder", "-")
        ptn = report_entry.get("Pattern", "-")
        status = report_entry.get("Status", "Bubble Found")
        result_img_path = report_entry.get("Result_Image")
        cropped_images_paths = report_entry.get("Cropped_Images")

        if folder != prev_folder:
            current_color_index = (current_color_index + 1) % 2
            prev_folder = folder
        row_fill = PatternFill(start_color=colors[current_color_index], end_color=colors[current_color_index], fill_type="solid")

        row_data = [folder, ptn, status]
        sheet.append(row_data)
        current_excel_row = sheet.max_row
        summary_ws.append(row_data)
        current_summary_row = summary_ws.max_row

        for col in range(1, len(row_data) + 1):
            cell = sheet.cell(row=current_excel_row, column=col)
            cell.alignment = Alignment(horizontal="center", vertical="center")
            cell.fill = row_fill
            cell.border = border_style
            scell = summary_ws.cell(row=current_summary_row, column=col)
            scell.alignment = Alignment(horizontal="center", vertical="center")
            scell.fill = row_fill
            scell.border = border_style

        adjust_status_cells(current_excel_row, current_summary_row, status)

        if result_img_path and os.path.exists(result_img_path):
            with Image.open(result_img_path) as img_result_pil:
                w, h = img_result_pil.size
            scaled_w = int(w * bubble_checker_thread.IMAGE_SCALE_FACTOR)
            scaled_h = int(h * bubble_checker_thread.IMAGE_SCALE_FACTOR)

            img_result = ExcelImage(result_img_path)
            img_result.width = scaled_w
            img_result.height = scaled_h
            sheet.add_image(img_result, f'D{current_excel_row}')
            img_result2 = ExcelImage(result_img_path)
            img_result2.width = scaled_w
            img_result2.height = scaled_h
            summary_ws.add_image(img_result2, f'D{current_summary_row}')

            current_row_height = sheet.row_dimensions[current_excel_row].height if sheet.row_dimensions[current_excel_row].height is not None else 0
            new_row_height = int(scaled_h * 0.75) + 2
            sheet.row_dimensions[current_excel_row].height = max(current_row_height, new_row_height)
            s_current_row_height = summary_ws.row_dimensions[current_summary_row].height if summary_ws.row_dimensions[current_summary_row].height is not None else 0
            s_new_row_height = int(scaled_h * 0.75) + 2
            summary_ws.row_dimensions[current_summary_row].height = max(s_current_row_height, s_new_row_height)
            
            current_col_width = sheet.column_dimensions['D'].width if sheet.column_dimensions['D'].width is not None else 0
            new_col_width = int(scaled_w / 7) + 2
            sheet.column_dimensions['D'].width = max(current_col_width, new_col_width)
            s_current_col_width = summary_ws.column_dimensions['D'].width if summary_ws.column_dimensions['D'].width is not None else 0
            s_new_col_width = int(scaled_w / 7) + 2
            summary_ws.column_dimensions['D'].width = max(s_current_col_width, s_new_col_width)

        if cropped_images_paths:
            for i, cropped_path in enumerate(cropped_images_paths):
                current_col_idx = 4 + i
                current_col_letter = get_column_letter(current_col_idx + 1)

                if cropped_path and os.path.exists(cropped_path):
                    with Image.open(cropped_path) as img_cropped_pil:
                        crop_width, crop_height = img_cropped_pil.size
                    
                    img_cropped = ExcelImage(cropped_path)
                    max_crop_size = 200
                    crop_ratio = min(max_crop_size / crop_width, max_crop_size / crop_height)
                    img_cropped.width = int(crop_width * crop_ratio)
                    img_cropped.height = int(crop_height * crop_ratio)
                    
                    sheet.add_image(img_cropped, f'{current_col_letter}{current_excel_row}')
                    img_cropped2 = ExcelImage(cropped_path)
                    img_cropped2.width = int(crop_width * crop_ratio)
                    img_cropped2.height = int(crop_height * crop_ratio)
                    summary_ws.add_image(img_cropped2, f'{current_col_letter}{current_summary_row}')

                    current_row_height = sheet.row_dimensions[current_excel_row].height if sheet.row_dimensions[current_excel_row].height is not None else 0
                    new_row_height = int(img_cropped.height * 0.75) + 2
                    sheet.row_dimensions[current_excel_row].height = max(current_row_height, new_row_height)
                    s_current_row_height = summary_ws.row_dimensions[current_summary_row].height if summary_ws.row_dimensions[current_summary_row].height is not None else 0
                    s_new_row_height = int(img_cropped.height * 0.75) + 2
                    summary_ws.row_dimensions[current_summary_row].height = max(s_current_row_height, s_new_row_height)

                    current_col_width = sheet.column_dimensions[current_col_letter].width if sheet.column_dimensions[current_col_letter].width is not None else 0
                    new_col_width = int(img_cropped.width / 7) + 2
                    sheet.column_dimensions[current_col_letter].width = max(current_col_width, new_col_width)
                    s_current_col_width = summary_ws.column_dimensions[current_col_letter].width if summary_ws.column_dimensions[current_col_letter].width is not None else 0
                    s_new_col_width = int(img_cropped.width / 7) + 2
                    summary_ws.column_dimensions[current_col_letter].width = max(s_current_col_width, s_new_col_width)

    excel_file_path = os.path.join(output_dir, "Bubble_Detection_Report.xlsx")
    workbook.save(excel_file_path)
    summary_wb.save(summary_path)
    
    # Create CSV file with all profile details including Max Variance and Defect Positions
    if all_profile_data:
        csv_file_path = os.path.join(output_dir, "Bubble_Profile_Details.csv")
        df = pd.DataFrame(all_profile_data)
        
        # Arrange columns for easier readability - include all required columns
        column_order = [
            "Folder", "File Name", "Pattern", "Resolution", "Status",
            "R Parameter", "Threshold Scale", "Threshold Used",
            "Number of Defects", "Max Variance", "Mean Variance", "Defect Positions"
        ]
        # Only retain the columns present in the DataFrame
        available_columns = [col for col in column_order if col in df.columns]
        df = df[available_columns]
        
        # Sort by Folder and File Name
        df = df.sort_values(by=["Folder", "File Name"])
        
        # Save CSV file
        df.to_csv(csv_file_path, index=False, encoding='utf-8-sig')
        bubble_checker_thread.update_log.emit(f"Profile details CSV saved: {csv_file_path}")
        bubble_checker_thread.update_log.emit(f"Total records in CSV: {len(df)}")
    
    try:
        bubble_checker_thread.update_log.emit(f"Summary updated: {summary_path} -> 'Bubble Report'")
    except Exception:
        pass


# BubbleCheckerThread class
class BubbleCheckerThread(QThread):
    update_progress = pyqtSignal(int)
    update_log = pyqtSignal(str)
    finished = pyqtSignal(list)

    ANALYSIS_RESULTS_FOLDER = "Bubble_Analysis_Results"
    IMAGE_SCALE_FACTOR = 0.18

    def __init__(self, root_folder, summary_output_folder=None):
        super().__init__()
        self.root_folder = root_folder
        self.summary_output_folder = summary_output_folder
        self.analysis_output_folder = os.path.join(self.root_folder, self.ANALYSIS_RESULTS_FOLDER)
        self.mask_images_dir = os.path.join(self.analysis_output_folder, "mask_images")
        self.mark_bubbles_dir = os.path.join(self.analysis_output_folder, "mark_bubbles")
        self.crop_bubbles_dir = os.path.join(self.analysis_output_folder, "crop_bubbles")
        
        os.makedirs(self.analysis_output_folder, exist_ok=True)
        os.makedirs(self.mask_images_dir, exist_ok=True)
        os.makedirs(self.mark_bubbles_dir, exist_ok=True)
        os.makedirs(self.crop_bubbles_dir, exist_ok=True)
        self.temp_files_to_delete = []
        self.all_profile_data = []

    def _prepare_folder_for_analysis(self, folder_path, folder_name):
        initial_image_paths = [os.path.join(folder_path, fname) 
                               for fname in os.listdir(folder_path) 
                               if fname.lower().endswith('.tif') and '_ori.tif' not in fname.lower()]

        if initial_image_paths:
            self.update_log.emit(f"Found {len(initial_image_paths)} TIFF images directly in {folder_name}.")
            return initial_image_paths

        self.update_log.emit(f"No TIFF images found directly in {folder_name}. Searching subfolders and copying...")
        copied_image_paths = []
        for root, _, files in os.walk(folder_path):
            if root == folder_path:
                continue
            
            filtered_files = [f for f in files if f.lower().endswith('.tif') and '_ori.tif' not in f.lower()]
            
            if filtered_files:
                parent_subfolder_name = os.path.basename(root)
                self.update_log.emit(f"  Found {len(filtered_files)} TIFF images in subfolder: {parent_subfolder_name}")

                for file in filtered_files:
                    original_path = os.path.join(root, file)
                    new_file_name = f"{parent_subfolder_name}_{file}"
                    destination_path = os.path.join(folder_path, new_file_name)
                    
                    shutil.copy2(original_path, destination_path)
                    copied_image_paths.append(destination_path)
                    self.temp_files_to_delete.append(destination_path)
                    self.update_log.emit(f"Copied '{os.path.basename(original_path)}' to '{new_file_name}' in {folder_name} for analysis.")

        return copied_image_paths

    def run(self):
        try:
            grouped_reports = []
            excluded_folders = ["Hiaa_Analysis_Results", "Bubble_Analysis_Results", "Hotpixel_Analysis_Results", "Dust_Analysis_Results",
                               "LShape_Analysis_Results", "CCD_Analysis_Results", "Top_Edge_Analysis_Results"]
            
            folders = [f for f in os.listdir(self.root_folder) 
                      if os.path.isdir(os.path.join(self.root_folder, f)) 
                      and f not in excluded_folders]
            total_folders = len(folders)

            if total_folders == 0:
                self.finished.emit([])
                return

            for idx, folder_name in enumerate(folders):
                folder_path = os.path.join(self.root_folder, folder_name)
                
                self.update_progress.emit(int((idx + 1) / total_folders * 100))
                self.update_log.emit(f"Checking folder: {folder_name}...")

                image_paths_for_analysis = self._prepare_folder_for_analysis(folder_path, folder_name)
                
                if not image_paths_for_analysis:
                    self.update_log.emit(f"No relevant TIFF images found in folder: {folder_name} for analysis.")
                    grouped_reports.append({
                        "Folder": folder_name,
                        "Pattern": "-",
                        "Status": "No valid TIFF images available for checking",
                        "Result_Image": None,
                        "Cropped_Images": []
                    })
                    continue

                # Group files by pattern
                grouped_files_by_position = {}
                folder_img_w = None
                folder_img_h = None
                
                for img_path in image_paths_for_analysis:
                    file_name = os.path.basename(img_path)
                    if file_name.lower().endswith(".tif"):
                        # Get dimensions for resolution filtering
                        img_temp = cv2.imread(img_path, cv2.IMREAD_UNCHANGED | cv2.IMREAD_ANYDEPTH)
                        if img_temp is not None:
                            if folder_img_w is None:
                                folder_img_h, folder_img_w = img_temp.shape[:2]
                        
                        bubble_type, pattern = _get_bubble_type_and_patterns(folder_img_w, folder_img_h, file_name)
                        if pattern:
                            if pattern not in grouped_files_by_position:
                                grouped_files_by_position[pattern] = []
                            grouped_files_by_position[pattern].append(file_name)

                if not grouped_files_by_position:
                    grouped_reports.append({
                        "Folder": folder_name,
                        "Pattern": "-",
                        "Status": "No valid pattern found (requires Bubble1_PTN_Check or Bubble2_PTN_Check match in settings.csv)",
                        "Result_Image": None,
                        "Cropped_Images": []
                    })
                    continue

                for pattern, file_names_in_group in grouped_files_by_position.items():
                    if not file_names_in_group:
                        grouped_reports.append({
                            "Folder": folder_name,
                            "Pattern": pattern,
                            "Status": "No files in pattern group",
                            "Result_Image": None,
                            "Cropped_Images": []
                        })
                        continue
                    try:
                        bubble_found_in_group, report_entries, profile_data_list = check_for_common_bubbles(
                            self,
                            folder_path, file_names_in_group, pattern,
                            self.mask_images_dir, self.mark_bubbles_dir, self.crop_bubbles_dir
                        )
                        
                        self.all_profile_data.extend(profile_data_list)
                        
                        if bubble_found_in_group:
                            cropped_list = []
                            if report_entries:
                                for entry in report_entries:
                                    if entry and entry.get("cropped_img_path"):
                                        cropped_list.append(entry["cropped_img_path"])
                            
                            result_image = report_entries[0]["result_img_path"] if report_entries and report_entries[0] else None
                            grouped_reports.append({
                                "Folder": folder_name,
                                "Pattern": pattern,
                                "Status": "Bubble Found",
                                "Result_Image": result_image,
                                "Cropped_Images": cropped_list
                            })
                        else:
                            grouped_reports.append({
                                "Folder": folder_name,
                                "Pattern": pattern,
                                "Status": "No bubble detected",
                                "Result_Image": None,
                                "Cropped_Images": []
                            })
                            
                    except Exception as e:
                        self.update_log.emit(f"Error processing pattern {pattern} in folder {folder_name}: {str(e)}")
                        grouped_reports.append({
                            "Folder": folder_name,
                            "Pattern": pattern,
                            "Status": f"Error: {str(e)[:50]}...",
                            "Result_Image": None,
                            "Cropped_Images": []
                        })
            
            if grouped_reports:
                generate_excel_report(self, self.analysis_output_folder, grouped_reports, self.all_profile_data)
                self.update_log.emit("Analysis complete! Excel report and CSV file generated.")
                
                bubble_folders = list(set(report['Folder'] for report in grouped_reports if report.get("Status") == "Bubble Found"))
                self.finished.emit(bubble_folders)
            else:
                if self.all_profile_data:
                    csv_file_path = os.path.join(self.analysis_output_folder, "Bubble_Profile_Details.csv")
                    df = pd.DataFrame(self.all_profile_data)
                    
                    column_order = [
                        "Folder", "File Name", "Pattern", "Resolution", "Status",
                        "R Parameter", "Threshold Scale", "Threshold Used",
                        "Number of Defects", "Max Variance", "Mean Variance", "Defect Positions"
                    ]
                    available_columns = [col for col in column_order if col in df.columns]
                    df = df[available_columns]
                    df = df.sort_values(by=["Folder", "File Name"])
                    df.to_csv(csv_file_path, index=False, encoding='utf-8-sig')
                    self.update_log.emit(f"Profile details CSV saved: {csv_file_path}")
                    self.update_log.emit(f"Total records in CSV: {len(df)}")
                
                self.update_log.emit("Analysis complete! No folders processed, but CSV file generated.")
                self.finished.emit([])

        except Exception as e:
            self.update_log.emit(f"Error: {type(e).__name__} - {str(e)}")
            self.finished.emit([])
        finally:
            if self.temp_files_to_delete:
                self.update_log.emit("Cleaning up temporary files...")
                for temp_file in self.temp_files_to_delete:
                    if os.path.exists(temp_file):
                        try:
                            os.remove(temp_file)
                            self.update_log.emit(f"Deleted temporary file: {os.path.basename(temp_file)}")
                        except Exception as e:
                            self.update_log.emit(f"Error deleting temporary file {os.path.basename(temp_file)}: {str(e)}")
                self.temp_files_to_delete.clear()