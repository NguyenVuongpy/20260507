import os
import sys
import pandas as pd
from datetime import datetime
import shutil
import time
import subprocess
import traceback
import threading
import rc.icons
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGraphicsDropShadowEffect,
    QLabel, QPushButton, QProgressBar, QTextEdit, QFrame, QMessageBox, QGraphicsBlurEffect,
    QGroupBox, QGridLayout
)
from PyQt6.QtCore import Qt, QTimer, pyqtSignal, QObject, QThread
from PyQt6.QtGui import QFont, QTextCursor, QIcon

# Import combined_detector
try:
    import combined_detector
except ImportError:
    combined_detector = None

def get_script_dir():
    """Get the directory where the script or executable is located"""
    if getattr(sys, 'frozen', False):
        # Running as compiled executable
        return os.path.dirname(sys.executable)
    else:
        # Running as script
        return os.path.dirname(os.path.realpath(__file__))

script_dir = get_script_dir()

# Create logs directory if it doesn't exist
logs_dir = os.path.join(script_dir, 'logs')
if not os.path.exists(logs_dir):
    os.makedirs(logs_dir)

def get_application_path():
    """Get the path to the current application (script or executable)"""
    if getattr(sys, 'frozen', False):
        # Running as compiled executable
        return sys.executable
    else:
        # Running as script
        return os.path.abspath(__file__)

class LogSignals(QObject):
    """Signals for thread-safe logging"""
    log_signal = pyqtSignal(str, str)
    stats_signal = pyqtSignal(dict)
    action_signal = pyqtSignal(str)
    progress_signal = pyqtSignal(bool)
    detector_signal = pyqtSignal()
    timer_signal = pyqtSignal(int)

class CopyWorker(QThread):
    """Worker thread for copy process"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent = parent
        self.signals = LogSignals()
        self.is_running = True
    
    def run(self):
        """Run the copy process"""
        try:
            # Read restart time from CSV file
            restart_minutes = self.parent.read_initialization_phase()
            
            # Create log file path
            self.parent.log_file_path = os.path.join(logs_dir, f'copy_log_{datetime.now().strftime("%Y%m%d_%H%M%S")}.txt')
            
            # Write header to log file
            with open(self.parent.log_file_path, 'w', encoding='utf-8') as f:
                f.write(f"Copy process started at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write("="*80 + "\n")
                f.write(f"Author: nguyenvanvuong1\n")
                f.write("="*80 + "\n")
                if restart_minutes > 0:
                    f.write(f"Auto-restart scheduled in: {restart_minutes} minutes\n")
                    f.write("="*80 + "\n")
            
            self.signals.log_signal.emit("="*80, 'header')
            self.signals.log_signal.emit("STARTING COPY PROCESS", 'header')
            self.signals.log_signal.emit(f"Script directory: {script_dir}", 'info')
            self.signals.log_signal.emit(f"Log file: {self.parent.log_file_path}", 'info')
            self.signals.log_signal.emit(f"Author: nguyenvanvuong1", 'info')
            
            # Display auto-restart info if available
            if restart_minutes > 0:
                self.signals.log_signal.emit(f"Auto-restart scheduled in: {restart_minutes} minutes (from initialization phase)", 'warning')
                # Start countdown timer - send signal for main thread to handle
                self.signals.timer_signal.emit(restart_minutes)
            else:
                self.signals.log_signal.emit("Auto-restart not scheduled (initialization phase = 0 or not set)", 'info')
            
            self.signals.log_signal.emit("="*80, 'header')
            
            # Run the copy process
            self.parent.copy_logs_impl(self)
            
            # Process completed successfully - but don't set process_running = False here
            self.signals.progress_signal.emit(False)  # Hide progress bar
            self.signals.action_signal.emit("Process completed")
            self.signals.log_signal.emit("✅ Process completed successfully!", 'success')
            
            # Show detector
            self.signals.detector_signal.emit()
            
        except Exception as e:
            error_msg = f"Error in copy process: {str(e)}"
            self.signals.log_signal.emit(error_msg, 'error')
            self.signals.log_signal.emit(traceback.format_exc(), 'error')
            self.signals.progress_signal.emit(False)
            self.signals.action_signal.emit("Process completed with errors")
            self.signals.log_signal.emit("⚠️ Process completed with errors. Check the log for details.", 'warning')
    
    def stop(self):
        """Stop the worker thread"""
        self.is_running = False

class LogWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Copy Logs Tool - Process Monitor")
        self.resize(1000, 800)
        self.setWindowIcon(QIcon(":/icons/app_icon.png"))        
        
        # Process state
        self.process_running = False
        self.log_file_path = None
        self.total_files_copied = 0
        self.machines_processed = 0
        self.restart_minutes = 0
        self.restart_time_remaining = 0
        self.restart_timer = None
        self.worker = None
        self.detector_window = None
        self.is_detector_open = False
        self.blur_effect = None  # Store blur effect reference
        self.timer_check_counter = 0  # Counter to check timer
        
        # Setup UI
        self.setup_ui()
        # Auto-start process
        QTimer.singleShot(100, self.start_process)
    
    def setup_ui(self):
        """Setup the user interface"""
        # Central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        self.main_layout = QVBoxLayout(central_widget)
        self.main_layout.setSpacing(10)
        self.main_layout.setContentsMargins(15, 15, 15, 15)
        
        # Title frame with author info
        title_layout = QHBoxLayout()
        
        title_label = QLabel("Automatically copies and analyzes PUC images program")
        title_label.setFont(QFont('Arial', 18, QFont.Weight.Bold))
        title_layout.addWidget(title_label)
        
        title_layout.addStretch()
        
        author_label = QLabel("nguyenvanvuong1")
        author_label.setFont(QFont('Arial', 10, QFont.Weight.Normal))
        author_label.setStyleSheet("color: gray; font-style: italic;")
        title_layout.addWidget(author_label)
        
        self.main_layout.addLayout(title_layout)
        
        # Status group
        status_group = QGroupBox("Process Status")
        status_group.setFont(QFont('Arial', 10, QFont.Weight.Bold))
        status_layout = QVBoxLayout(status_group)
        
        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 0)  # Indeterminate mode
        self.progress_bar.setTextVisible(False)
        self.progress_bar.hide()
        status_layout.addWidget(self.progress_bar)
        
        # Current action
        self.current_action_label = QLabel("Initializing...")
        self.current_action_label.setFont(QFont('Arial', 10))
        status_layout.addWidget(self.current_action_label)
        
        # Timer frame
        timer_frame = QFrame()
        timer_frame.setFrameStyle(QFrame.Shape.StyledPanel)
        timer_frame.setStyleSheet("QFrame { background-color: #f5f5f5; border-radius: 5px; padding: 5px; }")
        timer_layout = QHBoxLayout(timer_frame)
        timer_layout.setSpacing(10)
        
        timer_icon = QLabel("⏱️")
        timer_icon.setFont(QFont('Arial', 14))
        timer_layout.addWidget(timer_icon)
        
        timer_text = QLabel("Auto-restart timer:")
        timer_text.setFont(QFont('Arial', 10))
        timer_layout.addWidget(timer_text)
        
        self.restart_timer_label = QLabel("Reading configuration...")
        self.restart_timer_label.setFont(QFont('Arial', 12, QFont.Weight.Bold))
        timer_layout.addWidget(self.restart_timer_label)
        
        timer_layout.addStretch()
        status_layout.addWidget(timer_frame)
        
        # Statistics grid
        stats_layout = QGridLayout()
        stats_layout.setVerticalSpacing(5)
        stats_layout.setHorizontalSpacing(20)
        
        # Files copied
        files_label = QLabel("Files copied:")
        files_label.setFont(QFont('Arial', 9, QFont.Weight.Bold))
        stats_layout.addWidget(files_label, 0, 0)
        
        self.files_copied_label = QLabel("0")
        self.files_copied_label.setFont(QFont('Arial', 9))
        stats_layout.addWidget(self.files_copied_label, 0, 1)
        
        # Machines processed
        machines_label = QLabel("Machines processed:")
        machines_label.setFont(QFont('Arial', 9, QFont.Weight.Bold))
        stats_layout.addWidget(machines_label, 0, 2)
        
        self.machines_processed_label = QLabel("0")
        self.machines_processed_label.setFont(QFont('Arial', 9))
        stats_layout.addWidget(self.machines_processed_label, 0, 3)
        
        # Current machine
        current_machine_label = QLabel("Current machine:")
        current_machine_label.setFont(QFont('Arial', 9, QFont.Weight.Bold))
        stats_layout.addWidget(current_machine_label, 0, 4)
        
        self.current_machine_label = QLabel("-")
        self.current_machine_label.setFont(QFont('Arial', 9))
        stats_layout.addWidget(self.current_machine_label, 0, 5)
        
        stats_layout.setColumnStretch(5, 1)
        status_layout.addLayout(stats_layout)
        
        self.main_layout.addWidget(status_group)
        
        # Log display
        log_group = QGroupBox("Log Output")
        log_group.setFont(QFont('Arial', 10, QFont.Weight.Bold))
        log_layout = QVBoxLayout(log_group)
        
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setFont(QFont('Consolas', 9))
        self.log_text.setLineWrapMode(QTextEdit.LineWrapMode.NoWrap)
        log_layout.addWidget(self.log_text)
        
        self.main_layout.addWidget(log_group, 1)  # Give it stretch factor
        
        # Status bar
        self.status_bar_label = QLabel("Ready")
        self.status_bar_label.setStyleSheet("color: gray; padding: 5px;")
        self.main_layout.addWidget(self.status_bar_label)
    
    def apply_blur_effect(self, blur=True):
        """Apply blur effect to main window"""
        if blur and not self.is_detector_open:
            self.is_detector_open = True
            # Create and apply blur effect
            self.blur_effect = QGraphicsBlurEffect(self.centralWidget())
            self.blur_effect.setBlurRadius(15)
            self.centralWidget().setGraphicsEffect(self.blur_effect)
            self.log("🔮 Main window blurred - detector opened", 'info')
        elif not blur and self.is_detector_open:
            self.is_detector_open = False
            # Remove blur effect
            self.centralWidget().setGraphicsEffect(None)
            self.blur_effect = None
    
    def log(self, message, level='info'):
        """Add message to log display with timestamp and color"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        log_message = f"[{timestamp}] {message}"
        
        # Set color based on level
        color_map = {
            'info': 'black',
            'success': 'green',
            'warning': 'orange',
            'error': 'red',
            'header': 'blue'
        }
        color = color_map.get(level, 'black')
        
        # Make header bold
        font_weight = 'bold' if level == 'header' else 'normal'
        
        # Insert HTML
        self.log_text.append(
            f'<span style="color: {color}; font-weight: {font_weight};">{log_message}</span>'
        )
        
        # Scroll to bottom
        cursor = self.log_text.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)
        self.log_text.setTextCursor(cursor)
        
        # Process events to keep UI responsive
        QApplication.processEvents()
        
        # Also write to file
        self.write_log_to_file(message, level)
    
    def write_log_to_file(self, message, level='info'):
        """Write message to log file"""
        if self.log_file_path:
            try:
                timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                log_message = f"[{timestamp}] {message}\n"
                with open(self.log_file_path, 'a', encoding='utf-8') as f:
                    f.write(log_message)
            except Exception as e:
                print(f"Error writing to log file: {e}")
    
    def write_log(self, message, level='info'):
        """Write message to both log file and UI (called from worker)"""
        # This is now handled by log() method
        pass
    
    def update_stats(self, stats_dict):
        """Update statistics display"""
        if 'files_copied' in stats_dict:
            self.total_files_copied = stats_dict['files_copied']
            self.files_copied_label.setText(str(stats_dict['files_copied']))
        
        if 'machines_processed' in stats_dict:
            self.machines_processed = stats_dict['machines_processed']
            self.machines_processed_label.setText(str(stats_dict['machines_processed']))
        
        if 'current_machine' in stats_dict:
            self.current_machine_label.setText(stats_dict['current_machine'])
    
    def set_action(self, action):
        """Update current action label"""
        self.current_action_label.setText(f"▶ {action}")
        self.status_bar_label.setText(action)
    
    def update_restart_timer_display(self):
        """Update restart timer display - real-time countdown"""
        if self.restart_time_remaining > 0:
            minutes = self.restart_time_remaining // 60
            seconds = self.restart_time_remaining % 60
            
            # Format time string
            time_str = f"{minutes:02d}:{seconds:02d}"
            self.restart_timer_label.setText(time_str)
            
            # Change color based on remaining time
            if self.restart_time_remaining < 60:  # Less than 1 minute
                self.restart_timer_label.setStyleSheet("color: red; font-weight: bold; font-size: 14px;")
                self.status_bar_label.setText(f"⚠️ Restart soon: {time_str}")
            elif self.restart_time_remaining < 300:  # Less than 5 minutes
                self.restart_timer_label.setStyleSheet("color: orange; font-weight: bold; font-size: 14px;")
            else:
                self.restart_timer_label.setStyleSheet("color: blue; font-weight: bold; font-size: 14px;")
            
        else:
            self.restart_timer_label.setText("00:00")
            self.restart_timer_label.setStyleSheet("color: red; font-weight: bold; font-size: 14px;")
            self.status_bar_label.setText("🔄 Restarting...")
    
    def start_restart_timer(self, minutes):
        """Start countdown timer for auto-restart"""
        if minutes <= 0:
            return
        
        self.restart_minutes = minutes
        self.restart_time_remaining = minutes * 60
        self.timer_check_counter = 0
        
        # Stop old timer if exists
        if self.restart_timer:
            self.restart_timer.stop()
            self.restart_timer.deleteLater()
        
        # Create new timer for updating every second
        self.restart_timer = QTimer()
        self.restart_timer.timeout.connect(self.update_restart_timer)
        self.restart_timer.setTimerType(Qt.TimerType.PreciseTimer)
        self.restart_timer.start(1000)  # Update every second
        
        # Update display immediately
        self.update_restart_timer_display()
        self.log(f"⏱️ Auto-restart timer started: {minutes} minutes (countdown: {minutes:02d}:00)", 'info')
        
        # Log timer status
        self.log(f"⏱️ Timer object created: {self.restart_timer is not None}", 'info')
        self.log(f"⏱️ Timer active: {self.restart_timer.isActive()}", 'info')
    
    def update_restart_timer(self):
        """Update restart timer countdown - runs every second"""
        try:
            # Don't check process_running anymore, timer always runs until countdown reaches zero
            self.restart_time_remaining -= 1
            if self.restart_time_remaining <= 0:
                self.log("⏱️ Timer reached zero, performing auto-restart", 'warning')
                self.restart_timer.stop()
                self.update_restart_timer_display()
                self.perform_auto_restart()
            else:
                self.update_restart_timer_display()
                
        except Exception as e:
            self.log(f"⏱️ Error in timer update: {str(e)}", 'error')
    
    def perform_auto_restart(self):
        """Perform auto-restart of the application"""
        self.log("\n" + "="*60, 'header')
        self.log("AUTO-RESTART INITIATED", 'header')
        self.log(f"Restarting after {self.restart_minutes} minutes", 'header')
        self.log("="*60, 'header')
        
        # Close detector window if open
        if self.detector_window:
            try:
                self.detector_window.close()
            except:
                pass
        
        # Stop worker
        if self.worker and self.worker.isRunning():
            self.worker.stop()
            self.worker.wait()
        
        # Restart application
        self.restart_application()
    
    def restart_application(self):
        """Restart the application"""
        try:
            # Get the path to the current application
            app_path = get_application_path()
            
            # Prepare restart command based on whether it's frozen or not
            if getattr(sys, 'frozen', False):
                # Running as compiled executable
                restart_command = [app_path]
                self.log(f"🔄 Restarting executable: {app_path}", 'info')
            else:
                # Running as Python script
                python_exe = sys.executable
                restart_command = [python_exe, app_path]
                self.log(f"🔄 Restarting script with Python: {python_exe} {app_path}", 'info')
            
            # Start new process
            subprocess.Popen(restart_command, cwd=script_dir)
            
            # Exit current process
            QApplication.quit()
            
        except Exception as e:
            error_msg = f"Error during restart: {str(e)}"
            self.log(f"❌ {error_msg}", 'error')
            QMessageBox.critical(self, "Restart Error", error_msg)
    
    def start_process(self):
        """Start the copy process"""
        if self.process_running:
            return
        
        # Show progress bar
        self.progress_bar.show()
        
        # Clear stats
        self.update_stats({
            'files_copied': 0,
            'machines_processed': 0,
            'current_machine': '-'
        })
        self.set_action("Starting process...")
        
        # Create and start worker thread
        self.worker = CopyWorker(self)
        
        # Connect signals
        self.worker.signals.log_signal.connect(self.log)
        self.worker.signals.stats_signal.connect(self.update_stats)
        self.worker.signals.action_signal.connect(self.set_action)
        self.worker.signals.progress_signal.connect(self.on_progress_changed)
        self.worker.signals.detector_signal.connect(self.show_detector)
        self.worker.signals.timer_signal.connect(self.start_restart_timer)
        
        # Start worker
        self.process_running = True
        self.worker.start()
    
    def on_progress_changed(self, running):
        """Handle progress bar state change"""
        if running:
            self.progress_bar.show()
        else:
            self.progress_bar.hide()
            # Don't set process_running = False here because timer still needs to run
    
    def closeEvent(self, event):
        """Handle window close event"""
        # Don't ask if process is running since timer is still running
        # if self.process_running:
        #     reply = QMessageBox.question(
        #         self, 'Confirm',
        #         "A process is still running. Are you sure you want to exit?",
        #         QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        #     )
        #     if reply == QMessageBox.StandardButton.No:
        #         event.ignore()
        #         return
        
        # Close detector window if open
        if self.detector_window:
            try:
                self.detector_window.close()
            except:
                pass
        
        # Stop worker
        if self.worker and self.worker.isRunning():
            self.worker.stop()
            self.worker.wait()
        
        # Stop restart timer
        if self.restart_timer:
            self.restart_timer.stop()
            self.restart_timer.deleteLater()
        
        event.accept()
    
    def read_initialization_phase(self):
        """Read restart time from initialization phase column in CSV file"""
        copy_setting_path = os.path.join(script_dir, 'copy_setting.csv')
        restart_minutes = 0
        
        if os.path.exists(copy_setting_path):
            try:
                df = pd.read_csv(copy_setting_path)
                if 'initialization phase' in df.columns:
                    # Get first non-null value
                    phase_values = df['initialization phase'].dropna()
                    if not phase_values.empty:
                        restart_minutes = int(float(phase_values.iloc[0]))
                        self.log(f"📋 Read initialization phase: {restart_minutes} minutes from CSV", 'info')
                        
                        # Display message on timer label
                        if restart_minutes > 0:
                            self.restart_timer_label.setText(f"{restart_minutes:02d}:00")
                            self.restart_timer_label.setStyleSheet("color: blue; font-weight: bold; font-size: 14px;")
                        else:
                            self.restart_timer_label.setText("Not activated")
                            self.restart_timer_label.setStyleSheet("color: gray; font-style: italic;")
                    else:
                        self.log("📋 initialization phase column is empty in CSV", 'info')
                        self.restart_timer_label.setText("No data")
                        self.restart_timer_label.setStyleSheet("color: gray; font-style: italic;")
                else:
                    self.log("📋 No initialization phase column found in CSV", 'warning')
                    self.restart_timer_label.setText("No configuration column")
                    self.restart_timer_label.setStyleSheet("color: gray; font-style: italic;")
            except Exception as e:
                self.log(f"⚠️ Error reading initialization phase from CSV: {str(e)}", 'warning')
                self.restart_timer_label.setText("Error reading config")
                self.restart_timer_label.setStyleSheet("color: red; font-style: italic;")
        else:
            self.log(f"⚠️ copy_setting.csv not found at {copy_setting_path}", 'warning')
            self.restart_timer_label.setText("CSV file not found")
            self.restart_timer_label.setStyleSheet("color: red; font-style: italic;")
        
        return restart_minutes
    
    def copy_logs_impl(self, worker):
        """Main function to copy logs using settings from copy_setting.csv"""
        worker.signals.log_signal.emit(f"Processing date: {datetime.now().strftime('%Y-%m-%d')}", 'info')
        
        # Read copy_setting.csv
        copy_setting_path = os.path.join(script_dir, 'copy_setting.csv')
        if not os.path.exists(copy_setting_path):
            worker.signals.log_signal.emit(f"copy_setting.csv not found at {copy_setting_path}", 'error')
            return
        
        settings_df = pd.read_csv(copy_setting_path, index_col=None, sep=',', header=0)
        settings_df = settings_df.dropna(subset=['Line'])
        worker.signals.log_signal.emit(f"Found {len(settings_df)} line(s) in copy_setting.csv", 'info')
        
        ip_df = pd.read_csv(copy_setting_path, index_col=None, sep=',', header=0)
        worker.signals.log_signal.emit(f"Loaded copy_setting.csv with {len(ip_df)} rows", 'info')
        
        # Clear destination
        worker.signals.log_signal.emit("Clearing PUC destination directory before copy...", 'warning')
        self.clear_destination_directories(worker)
        
        # Statistics tracking
        all_machines = []
        successful_machines = []
        machines_without_data = []
        inaccessible_machines = []
        error_machines = []
        
        total_copied_files = 0
        machines_processed_count = 0
        
        # Process each line
        for idx, setting_row in settings_df.iterrows():
            if not worker.is_running:
                break
                
            line_name = setting_row['Line']
            mono_folder = setting_row['mono_folders']
            color_folder = setting_row['color_folders']
            folder_quantity = int(setting_row['folder_quantity'])
            cred_string = setting_row['credentials']
            
            credentials = self.parse_credentials(cred_string)
            
            worker.signals.log_signal.emit(f"\n{'='*60}", 'header')
            worker.signals.log_signal.emit(f"Processing line: {line_name}", 'header')
            worker.signals.log_signal.emit(f"  Mono folder: {mono_folder}", 'info')
            worker.signals.log_signal.emit(f"  Color folder: {color_folder}", 'info')
            worker.signals.log_signal.emit(f"  Folder quantity: {folder_quantity}", 'info')
            worker.signals.log_signal.emit(f"  Found {len(credentials)} credential(s) to try", 'info')
            
            # Log all credentials found (without showing passwords)
            for idx, cred in enumerate(credentials, 1):
                worker.signals.log_signal.emit(f"    Credential {idx}: {cred['username']}", 'info')
            
            line_number = self.extract_line_number(line_name)
            puc_type = line_name.split()[-1] if ' ' in line_name else line_name
            
            if 'PUC1' in puc_type:
                program_folder_name = mono_folder
            elif 'PUC2' in puc_type:
                program_folder_name = color_folder
            else:
                worker.signals.log_signal.emit(f"  Unknown PUC type: {puc_type}, skipping this line", 'warning')
                continue
            
            filtered_df, name_col, ip_col = self.filter_machines_by_line(ip_df, line_number, puc_type)
            
            if filtered_df.empty:
                worker.signals.log_signal.emit(f"  No machines found for line {line_number} with type {puc_type}", 'warning')
                continue
            
            worker.signals.log_signal.emit(f"  Found {len(filtered_df)} machine(s) for this line:", 'info')
            for _, row in filtered_df.iterrows():
                machine_info = f"{row[name_col]} ({row[ip_col]})"
                worker.signals.log_signal.emit(f"    - {machine_info}", 'info')
                all_machines.append(machine_info)
            
            # Process each machine
            for _, ip_row in filtered_df.iterrows():
                if not worker.is_running:
                    break
                    
                machine_name = ip_row[name_col]
                machine_ip = str(ip_row[ip_col])
                machine_info = f"{machine_name} ({machine_ip})"
                
                machines_processed_count += 1
                worker.signals.stats_signal.emit({
                    'files_copied': total_copied_files,
                    'machines_processed': machines_processed_count,
                    'current_machine': machine_name
                })
                worker.signals.action_signal.emit(f"Processing {machine_name}")
                
                worker.signals.log_signal.emit(f"\n  {'-'*40}", 'header')
                worker.signals.log_signal.emit(f"  Processing machine: {machine_name}", 'header')
                worker.signals.log_signal.emit(f"  IP Address: {machine_ip}", 'info')
                
                # Authenticate - try all credentials
                authenticated = False
                auth_error = ""
                
                for cred in credentials:
                    worker.signals.log_signal.emit(f"    Trying authentication with user: {cred['username']}", 'info')
                    
                    if self.authenticate_share(machine_ip, cred['username'], cred['password']):
                        authenticated = True
                        worker.signals.log_signal.emit(f"    ✅ Authentication successful with user: {cred['username']}", 'success')
                        break
                    else:
                        worker.signals.log_signal.emit(f"    Authentication failed with user: {cred['username']}", 'warning')
                        auth_error = f"Authentication failed with all credentials"
                
                if not authenticated:
                    worker.signals.log_signal.emit(f"    ❌ {auth_error}", 'error')
                    inaccessible_machines.append(machine_info)
                    continue
                
                files_found = False
                machine_file_count = 0
                
                # Generate date strings
                current_date = datetime.now()
                month_str = current_date.strftime('%m')
                day_str = current_date.strftime('%d')
                date_yyyymmdd = current_date.strftime('%Y%m%d')
                
                # Try possible paths
                possible_paths = [
                    f'\\\\{machine_ip}\\d\\POCB\\HEX\\{program_folder_name}\\{month_str}\\{day_str}',
                    f'\\\\{machine_ip}\\e\\POCB\\HEX\\{program_folder_name}\\{month_str}\\{day_str}',
                    f'\\\\{machine_ip}\\d\\POCB\\HEX\\{date_yyyymmdd}\\{program_folder_name}',
                    f'\\\\{machine_ip}\\e\\POCB\\HEX\\{date_yyyymmdd}\\{program_folder_name}'
                ]
                
                src_dir = None
                for path in possible_paths:
                    if os.path.exists(path):
                        src_dir = path
                        worker.signals.log_signal.emit(f"    Found source directory: {src_dir}", 'success')
                        break
                
                if not src_dir:
                    worker.signals.log_signal.emit(f"    Source directory not found for {current_date.strftime('%Y-%m-%d')}", 'warning')
                    machines_without_data.append(machine_info)
                    continue
                
                dest_dir = os.path.join(script_dir, 'PUC Crop Images', machine_name)
                
                try:
                    if os.path.exists(src_dir):
                        # Get subfolders
                        subfolders = []
                        for f in os.listdir(src_dir):
                            folder_path = os.path.join(src_dir, f)
                            if os.path.isdir(folder_path):
                                try:
                                    mtime = os.path.getmtime(folder_path)
                                    subfolders.append((f, mtime))
                                except:
                                    subfolders.append((f, time.time()))
                        
                        subfolders.sort(key=lambda x: x[1], reverse=True)
                        sorted_folder_names = [f[0] for f in subfolders][:folder_quantity]
                        
                        worker.signals.log_signal.emit(f"    Found {len(subfolders)} total folders, copying from newest {folder_quantity} folders", 'info')
                        
                        for folder in sorted_folder_names:
                            folder_path = os.path.join(src_dir, folder)
                            tif_files = [f for f in os.listdir(folder_path) 
                                        if f.endswith('.tif') and not f.endswith('_ori.tif')]
                            
                            if tif_files:
                                files_found = True
                                if not os.path.exists(dest_dir):
                                    os.makedirs(dest_dir)
                                    worker.signals.log_signal.emit(f"    Created destination directory: {dest_dir}", 'info')
                                
                                folder_file_count = 0
                                for filename in tif_files:
                                    src_file = os.path.join(folder_path, filename)
                                    
                                    folder_name = folder.split('_')[0]
                                    parts = filename.split('_')
                                    step_info = '_'.join(parts[:2])
                                    color_info = parts[2] if len(parts) > 2 else ""
                                    
                                    if color_info:
                                        new_filename = f"{folder_name}_{step_info}_{color_info}.tif"
                                    else:
                                        new_filename = f"{folder_name}_{step_info}.tif"
                                    
                                    dest_file = os.path.join(dest_dir, new_filename)
                                    
                                    shutil.copy2(src_file, dest_file)
                                    folder_file_count += 1
                                    machine_file_count += 1
                                    total_copied_files += 1
                                    
                                    if total_copied_files % 10 == 0:
                                        worker.signals.stats_signal.emit({'files_copied': total_copied_files})
                                
                                worker.signals.log_signal.emit(f"      ✅ Copied {folder_file_count} file(s) from folder: {folder}", 'success')
                            else:
                                worker.signals.log_signal.emit(f"    No .tif files found in folder: {folder}", 'warning')
                        
                        if files_found:
                            successful_machines.append(f"{machine_info} - {machine_file_count} files")
                            worker.signals.log_signal.emit(f"    ✅ Successfully copied {machine_file_count} files from {machine_name}", 'success')
                        else:
                            machines_without_data.append(machine_info)
                            worker.signals.log_signal.emit(f"    ⚠️ No data found on {machine_name}", 'warning')
                                
                except Exception as e:
                    error_msg = f"Error accessing {machine_name}: {str(e)}"
                    worker.signals.log_signal.emit(f"    ❌ {error_msg}", 'error')
                    error_machines.append(f"{machine_info} - Error: {str(e)}")
        
        # Summary
        worker.signals.log_signal.emit("\n" + "="*80, 'header')
        worker.signals.log_signal.emit("COPY PROCESS COMPLETED", 'header')
        worker.signals.log_signal.emit(f"Total files copied: {total_copied_files}", 'success')
        worker.signals.log_signal.emit(f"Log file saved to: {self.log_file_path}", 'info')
        worker.signals.log_signal.emit("="*80, 'header')
        
        worker.signals.stats_signal.emit({
            'files_copied': total_copied_files,
            'machines_processed': machines_processed_count
        })
        
        # Write summary
        summary = []
        summary.append("=" * 60)
        summary.append("COPY PROCESS SUMMARY")
        summary.append("=" * 60)
        
        if successful_machines:
            summary.append(f"\n✅ MACHINES WITH DATA ({len(successful_machines)} machines):")
            for machine in successful_machines:
                summary.append(f"  • {machine}")
        else:
            summary.append("\n✅ No machines with data found")
        
        if machines_without_data:
            summary.append(f"\n⚠️ MACHINES ACCESSED BUT NO DATA ({len(machines_without_data)} machines):")
            for machine in machines_without_data:
                summary.append(f"  • {machine}")
        
        if inaccessible_machines:
            summary.append(f"\n❌ INACCESSIBLE MACHINES ({len(inaccessible_machines)} machines):")
            for machine in inaccessible_machines:
                summary.append(f"  • {machine}")
        
        if error_machines:
            summary.append(f"\n🔴 MACHINES WITH ERRORS ({len(error_machines)} machines):")
            for machine in error_machines:
                summary.append(f"  • {machine}")
        
        summary.append("\n" + "=" * 60)
        summary.append(f"TOTAL MACHINES PROCESSED: {len(all_machines)}")
        summary.append(f"  • With data: {len(successful_machines)}")
        summary.append(f"  • Without data: {len(machines_without_data)}")
        summary.append(f"  • Inaccessible: {len(inaccessible_machines)}")
        summary.append(f"  • Errors: {len(error_machines)}")
        summary.append(f"TOTAL FILES COPIED: {total_copied_files}")
        summary.append("=" * 60)
        
        for line in summary:
            worker.signals.log_signal.emit(line, 'info')
    
    def clear_destination_directories(self, worker=None):
        """Delete all data in the destination folder before copying."""
        directory = os.path.join(script_dir, 'PUC Crop Images')
        
        if os.path.exists(directory):
            try:
                deleted_count = 0
                deleted_folders = 0
                
                for item in os.listdir(directory):
                    item_path = os.path.join(directory, item)
                    if os.path.isfile(item_path):
                        os.remove(item_path)
                        deleted_count += 1
                    elif os.path.isdir(item_path):
                        shutil.rmtree(item_path)
                        deleted_folders += 1
                
                log_message = f"Cleared directory: {directory} - Deleted {deleted_count} files and {deleted_folders} folders"
                if worker:
                    worker.signals.log_signal.emit(log_message, 'warning')
                else:
                    self.log(log_message, 'warning')
                    
            except Exception as e:
                error_message = f"Error clearing directory {directory}: {str(e)}"
                if worker:
                    worker.signals.log_signal.emit(error_message, 'error')
                else:
                    self.log(error_message, 'error')
    
    def authenticate_share(self, ip, username, password):
        """Authenticate access to the shared drive"""
        try:
            command = f'net use \\\\{ip} /user:{username} {password}'
            result = subprocess.run(command, shell=True, capture_output=True, text=True)
            return result.returncode == 0
        except Exception as e:
            return False
    
    def parse_credentials(self, cred_string):
        """Parse credentials from string with format: user:pass;user2:pass2"""
        credentials = []
        
        # Convert to string and strip whitespace
        cred_string = str(cred_string).strip()
        
        # Handle NaN or empty values
        if not cred_string or cred_string == 'nan' or cred_string == 'None':
            return credentials
        
        # Split by semicolon to get individual credential pairs
        cred_pairs = cred_string.split(';')
        
        for pair in cred_pairs:
            pair = pair.strip()
            if ':' in pair:
                # Split only at the first colon to handle passwords that might contain colons
                username, password = pair.split(':', 1)
                credentials.append({
                    'username': username.strip(),
                    'password': password.strip()
                })
        
        return credentials
    
    def extract_line_number(self, line_name):
        """Extract line number from line name"""
        return line_name.split()[0] if ' ' in line_name else line_name
    
    def filter_machines_by_line(self, ip_df, line_number, puc_type):
        """Filter machines based on line number and PUC type"""
        if puc_type == 'PUC1':
            name_col = 'PUC1 Name'
            ip_col = 'PUC1 IP'
        else:
            name_col = 'PUC2 Name'
            ip_col = 'PUC2 IP'
        
        filtered_df = ip_df.dropna(subset=[name_col])
        mask = filtered_df[name_col].astype(str).str.startswith(str(line_number))
        filtered_df = filtered_df[mask]
        
        return filtered_df, name_col, ip_col
    
    def show_detector(self):
        """Show the combined_detector UI with blur effect"""
        if combined_detector is None:
            self.log("⚠️ combined_detector module not found", 'warning')
            return
        
        try:
            self.log("\n" + "="*60, 'header')
            self.log("OPENING PUC CROP IMAGE ANALYSIS TOOL", 'header')
            self.log("="*60, 'header')
            
            # Apply blur effect to main window
            self.apply_blur_effect(True)
            
            # Check if MainWindow exists
            if hasattr(combined_detector, 'MainWindow'):
                # Create and show the detector window
                self.detector_window = combined_detector.MainWindow()
                self.detector_window.setWindowTitle("PUC Crop Image Analysis Tool")
                self.detector_window.resize(700, 750)
                
                # Store original closeEvent
                original_close_event = self.detector_window.closeEvent
                
                def wrapped_close_event(event):
                    # Remove blur effect first
                    self.apply_blur_effect(False)
                    # Call original close event if exists
                    if original_close_event:
                        original_close_event(event)
                    else:
                        event.accept()
                    self.detector_window = None
                
                self.detector_window.closeEvent = wrapped_close_event
                
                # Set window modality to NonModal to not block main window
                self.detector_window.setWindowModality(Qt.WindowModality.NonModal)
                
                # Show the window
                self.detector_window.show()
                self.detector_window.raise_()  # Bring to front
                self.detector_window.activateWindow()  # Activate window
                self.log("✅ PUC Crop Image Analysis Tool opened successfully", 'success')
                
                # Check timer status
                if self.restart_timer:
                    self.log(f"⏱️ Timer active after opening detector: {self.restart_timer.isActive()}", 'info')
                    self.log(f"⏱️ Time remaining: {self.restart_time_remaining} seconds", 'info')
                else:
                    self.log("⏱️ No timer active", 'warning')
                
            elif hasattr(combined_detector, 'main'):
                # Run main function
                self.log("Running detector main() function...", 'info')
                combined_detector.main()
                # Remove blur when main returns
                self.apply_blur_effect(False)
                
            else:
                self.log("⚠️ Could not find MainWindow or main() in combined_detector", 'warning')
                self.apply_blur_effect(False)
                
        except Exception as e:
            self.log(f"❌ Error opening detector: {str(e)}", 'error')
            self.log(traceback.format_exc(), 'error')
            self.apply_blur_effect(False)
    
    def on_detector_closed(self, event):
        """Handle detector window close event"""
        # Remove blur effect
        self.apply_blur_effect(False)
        # Call original close event if exists
        if hasattr(combined_detector.MainWindow, 'closeEvent'):
            try:
                combined_detector.MainWindow.closeEvent(self.detector_window, event)
            except:
                event.accept()
        else:
            event.accept()
        
        self.detector_window = None

def main():
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    window = LogWindow()
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()